# Domain 02 - Context & RAG Control Code Pack

Source document:
`DOMAIN 02 - CONTEXT & RAG CONTROL - FINAL PUBLIC FORMAT D1 STYLE WITH INDEX AND EXPANDED SUBDOMAIN GUIDES - NITPICKS FIXED.docx`

This package preserves the code examples outside Word so indentation, quoting, YAML structure and JSON samples are not dependent on DOCX rendering.

Contents:
- `python/` - Python reference implementations and lab snippets.
- `json/` - evidence logs and payload examples.
- `yaml/` - Docker Compose and YAML snippets.
- `bash/` - shell commands for labs and quick start.
- `docker/` - Dockerfile examples.
- `text/` - pseudo-code, flow text, XML-style examples and non-executable snippets.
- `DOMAIN02_ALL_EXTRACTED_CODE_BLOCKS.md` - all extracted blocks in document order.
- `manifest.json` - block index, section, language, file path and SHA-256.

Important:
- The e-book remains the human-readable blueprint.
- This ZIP is the safer source for rebuilding/lab work because Word can wrap or visually break code.
- Some snippets are reference controls, not complete production packages. Review dependencies and integrate with your platform before execution.

Extraction summary:
- Total blocks extracted: 106
- Python files: 76
- JSON files: 25
- YAML files: 0
- Bash files: 1
- Docker files: 1
- Text/XML/pseudocode files: 3


## Python normalization layer

The `python/` folder contains raw extraction from the DOCX code blocks. Because DOCX rendering can damage indentation, a best-effort normalized copy is also included in:

- `python_normalized_best_effort/`
- `python_normalized_compile_report.json`

Normalization result:
- Python raw blocks extracted: 76
- Best-effort normalized Python files that compile syntactically: 37/76

Use `python_normalized_best_effort/` first for lab reconstruction, but review each file before production. The raw extracted blocks remain available for traceability.
