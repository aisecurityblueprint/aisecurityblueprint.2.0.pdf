class TopKGovernance:
    """
    Governs the Top-K selection of retrieval results.
    Prevents K parameter manipulation to include low-relevance documents.
    """
    def __init__(self):
        self.default_k = 10
        self.max_k = 20
        self.min_k = 3
        self.k_tiers = {
            "public": 20,
            "internal": 15,
            "confidential": 10,
            "restricted": 5,
        }

    def validate_k(self, requested_k: int, sensitivity: str = "internal") -> dict:
        max_allowed = self.k_tiers.get(sensitivity, self.default_k)
        if requested_k > self.max_k:
            return {"action": "clamp", "reason": f"k_exceeds_global_max: {requested_k} > {self.max_k}",
                "original_k": requested_k, "adjusted_k": self.max_k}
                if requested_k > max_allowed:
                    return {"action": "clamp", "reason": f"k_exceeds_sensitivity_max: {requested_k} > {max_allowed} ({sensitivity})",
                        "original_k": requested_k, "adjusted_k": max_allowed}
                        if requested_k < self.min_k:
                            return {"action": "clamp", "reason": f"k_below_min: {requested_k} < {self.min_k}",
                                "original_k": requested_k, "adjusted_k": self.min_k}
                                return {"action": "accept", "k": requested_k}
