class ProvenanceTracker:
    """
    Tracks complete provenance of each document in context.
    Implements chain of custody for RAG data.
    """
    def __init__(self):
        self.provenance_chain = {}
        self.provenance_log = []

    def record_ingestion(self, doc: dict, ingestion_metadata: dict) -> str:
        provenance_id = hashlib.sha256(
            f"{doc.get('doc_id')}:{datetime.now(timezone.utc).isoformat()}:{json.dumps(ingestion_metadata, sort_keys=True)}".encode()
        ).hexdigest()[:16]
        provenance_entry = {
            "provenance_id": provenance_id,
            "doc_id": doc.get("doc_id"),
            "event": "ingestion",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": doc.get("source"),
            "source_url": doc.get("source_url"),
            "ingested_by": ingestion_metadata.get("ingested_by", "system"),
            "ingestion_pipeline": ingestion_metadata.get("pipeline", "default"),
            "original_hash": doc.get("content_hash"),
            "file_type": doc.get("file_type"),
            "file_size_bytes": doc.get("file_size_bytes"),
            "metadata": {
                "author": doc.get("author"),
                "created_date": doc.get("created_date"),
                "modified_date": doc.get("modified_date"),
                "version": doc.get("version"),
                "tags": doc.get("tags", []),
                "classification": doc.get("classification", "internal"),
                "sensitivity_tier": doc.get("sensitivity_tier", 1),
                "owner_department": doc.get("owner_department"),
                "legal_hold": doc.get("legal_hold", False),
                "retention_policy": doc.get("retention_policy"),
            }
        }
        self.provenance_chain[provenance_id] = provenance_entry
        self.provenance_log.append(provenance_entry)
        return provenance_id

    def record_retrieval(self, provenance_id: str, retrieval_metadata: dict) -> dict:
        if provenance_id not in self.provenance_chain:
            return {"error": "provenance_id_not_found"}
            retrieval_entry = {
                "provenance_id": provenance_id,
                "event": "retrieval",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "retrieved_by": retrieval_metadata.get("user_id"),
                "session_id": retrieval_metadata.get("session_id"),
                "query_id": retrieval_metadata.get("query_id"),
                "relevance_score": retrieval_metadata.get("relevance_score"),
                "rank_position": retrieval_metadata.get("rank_position"),
                "context_position": retrieval_metadata.get("context_position"),
                "tenant_id": retrieval_metadata.get("tenant_id"),
            }
            self.provenance_log.append(retrieval_entry)
            return {"provenance_id": provenance_id, "retrieval_event": retrieval_entry}

    def record_modification(self, provenance_id: str, modification: dict) -> dict:
        if provenance_id not in self.provenance_chain:
            return {"error": "provenance_id_not_found"}
            modification_entry = {
                "provenance_id": provenance_id,
                "event": "modification",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "modified_by": modification.get("modified_by"),
                "change_type": modification.get("change_type"),
                "previous_hash": self.provenance_chain[provenance_id].get("original_hash"),
                "new_hash": modification.get("new_hash"),
                "change_description": modification.get("description"),
            }
            self.provenance_log.append(modification_entry)
            return {"provenance_id": provenance_id, "modification_event": modification_entry}

    def get_full_provenance(self, provenance_id: str) -> dict:
        if provenance_id not in self.provenance_chain:
            return {"error": "provenance_id_not_found"}
            chain = self.provenance_chain[provenance_id]
            events = [e for e in self.provenance_log if e.get("provenance_id") == provenance_id]
            return {
                "provenance_id": provenance_id,
                "doc_id": chain.get("doc_id"),
                "ingestion": chain,
                "events": events,
                "event_count": len(events),
                "last_event": events[-1] if events else chain,
                "chain_of_custody_intact": self._verify_chain_integrity(events)
            }

    def _verify_chain_integrity(self, events: list) -> bool:
        if len(events) < 2:
            return True
            for i in range(len(events) - 1):
                try:
                    t1 = parse_ts(events[i]["timestamp"])
                    t2 = parse_ts(events[i+1]["timestamp"])
                    if t2 < t1:
                        return False
                    except (ValueError, TypeError):
                        return False
                        return True

    def get_provenance_for_context(self, context_docs: list) -> dict:
        provenance_map = {}
        for doc in context_docs:
            provenance_id = doc.get("provenance_id")
            if provenance_id and provenance_id in self.provenance_chain:
                provenance_map[provenance_id] = {
                    "doc_id": doc.get("doc_id"),
                    "source": self.provenance_chain[provenance_id].get("source"),
                    "trust_tier": doc.get("trust_tier"),
                    "ingestion_date": self.provenance_chain[provenance_id].get("timestamp"),
                    "owner_department": self.provenance_chain[provenance_id].get("metadata", {}).get("owner_department"),
                    "classification": self.provenance_chain[provenance_id].get("metadata", {}).get("classification"),
                }
                return {
                    "context_docs_count": len(context_docs),
                    "docs_with_provenance": len(provenance_map),
                    "docs_without_provenance": len(context_docs) - len(provenance_map),
                    "provenance_map": provenance_map
                }
