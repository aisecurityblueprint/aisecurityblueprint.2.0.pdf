class RetrievalFilter:
    """
    Filters retrieval results before they enter context.
    Implements security, relevance, and freshness filters.
    """
    def __init__(self):
        self.min_relevance_score = 0.65
        self.max_results = 20
        self.max_results_per_source = 10
        self.staleness_threshold_days = 365

    def filter_results(self, results: list, user_context: dict) -> dict:
        filtered = []
        removed = []
        for i, doc in enumerate(results):
            removal_reason = None
            if doc.get("relevance_score", 0) < self.min_relevance_score:
                removal_reason = f"low_relevance: {doc.get('relevance_score', 0):.2f}"
            elif doc.get("sensitivity_tier", 0) > user_context.get("clearance_level", 0):
                removal_reason = f"clearance_insufficient: doc_tier={doc.get('sensitivity_tier')}, user_clearance={user_context.get('clearance_level')}"
            elif doc.get("classification") == "restricted":
                removal_reason = "classification_restricted"
            elif doc.get("sensitivity_tier", 0) >= 3 and doc.get("owner_department") != user_context.get("department"):
                removal_reason = f"cross_department: {doc.get('owner_department')}"
            elif self._is_stale(doc):
                removal_reason = f"stale_data: last_updated={doc.get('last_updated')}"
                if removal_reason:
                    removed.append({"index": i, "doc_id": doc.get("doc_id", "unknown"), "reason": removal_reason})
                else:
                    filtered.append(doc)
                    if len(filtered) > self.max_results:
                        filtered = filtered[:self.max_results]
                        source_counts = {}
                        final_results = []
                        for doc in filtered:
                            source = doc.get("source", "unknown")
                            source_counts[source] = source_counts.get(source, 0) + 1
                            if source_counts[source] <= self.max_results_per_source:
                                final_results.append(doc)
                                return {
                                    "action": "filtered",
                                    "original_count": len(results),
                                    "filtered_count": len(final_results),
                                    "removed_count": len(removed),
                                    "removed": removed,
                                    "results": final_results,
                                    "filter_stats": {"min_relevance": self.min_relevance_score, "max_results": self.max_results}
                                }

    def _is_stale(self, doc: dict) -> bool:
        last_updated = doc.get("last_updated")
        if not last_updated:
            return False
            try:
                days_old = (datetime.now(timezone.utc) - parse_ts(last_updated)).days
                return days_old > self.staleness_threshold_days
            except (ValueError, TypeError):
                return False
