class KnowledgeSegmenter:
    KNOWLEDGE_HIERARCHY = {
        "internal_policy": 10, "internal_procedure": 9, "internal_knowledge_base": 8,
        "verified_partner_data": 7, "regulatory_public": 6, "industry_standard": 5,
        "public_verified": 4, "public_unverified": 2, "web_content": 1, "unknown_external": 0,
    }

    def segment(self, docs: list) -> dict:
        segments = {}
        for doc in docs:
            knowledge_type = doc.get("knowledge_type", "unknown_external")
            level = self.KNOWLEDGE_HIERARCHY.get(knowledge_type, 0)
            segment = "internal" if level >= 8 else "external_verified" if level >= 4 else "external_unverified"
            doc["hierarchy_level"] = level
            segments.setdefault(segment, []).append(doc)
            for segment in segments:
                segments[segment].sort(key=lambda d: d.get("hierarchy_level", 0), reverse=True)
                return {"segments": segments, "internal_count": len(segments.get("internal", [])), "external_verified_count": len(segments.get("external_verified", [])), "external_unverified_count": len(segments.get("external_unverified", [])), "internal_ratio": len(segments.get("internal", [])) / max(len(docs), 1)}

    def detect_knowledge_conflict(self, internal_docs: list, external_docs: list) -> list:
        conflicts = []
        for ext_doc in external_docs:
            ext_content = ext_doc.get("content", "").lower()
            for int_doc in internal_docs:
                int_content = int_doc.get("content", "").lower()
                score = self._compute_conflict_score(int_content, ext_content)
                if score > 0.5:
                    conflicts.append({"internal_doc": int_doc.get("doc_id"), "external_doc": ext_doc.get("doc_id"), "conflict_score": score, "resolution": "internal_wins", "action": "flag_external_as_unreliable"})
                    return conflicts

    def _compute_conflict_score(self, text1: str, text2: str) -> float:
        STOP = {"the", "is", "are", "a", "an", "of", "to", "in", "and", "que", "de", "da", "do", "para", "com", "una", "un", "el", "la", "los", "las"}
        w1 = set(text1.split()) - STOP
        w2 = set(text2.split()) - STOP
        if not w1 or not w2:
            return 0.0
            overlap = len(w1 & w2) / min(len(w1), len(w2))
            if overlap < 0.25:
                return 0.0
                opposed_pairs = [
                    (r"\bmust\b|\brequired\b|\bmandatory\b", r"\bmust\s+not\b|\bnot\s+required\b|\boptional\b|\bvoluntary\b"),
                    (r"\ballowed\b|\bpermitted\b", r"\bprohibited\b|\bforbidden\b|\bnot\s+(allowed|permitted)\b"),
                    (r"\balways\b", r"\bnever\b"),
                    (r"\bobrigat[oó]ri[oa]\b|\bdeve\b", r"\bopcional\b|\bn[aã]o\s+obrigat[oó]ri[oa]\b"),
                    (r"\bpermitido\b", r"\bproibido\b|\bn[aã]o\s+permitido\b"),
                    (r"\bobligatori[oa]\b|\bdebe\b", r"\bopcional\b|\bno\s+obligatori[oa]\b"),
                    (r"\bpermitido\b", r"\bprohibido\b|\bno\s+permitido\b"),
                ]
                opposed_hits = 0
                for pos, neg in opposed_pairs:
                    if (re.search(pos, text1) and re.search(neg, text2)) or (re.search(neg, text1) and re.search(pos, text2)):
                        opposed_hits += 1
                        if opposed_hits == 0:
                            return 0.0
                            return min(1.0, 0.4 + opposed_hits * 0.2 + overlap * 0.2)
