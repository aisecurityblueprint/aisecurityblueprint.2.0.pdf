class AuthoritativeSourceEnforcer:
    """
    Ensures authoritative sources have absolute precedence.
    No other source may contradict an authoritative source.
    """
    def __init__(self):
        self.authoritative_sources = set()
        self.authoritative_domains = set()
        self.authoritative_doc_ids = set()
        self.AUTHORITATIVE_SOURCE_TYPES = [
            "official_policy", "regulatory_filing", "internal_audit",
            "board_approved", "legal_reviewed",
        ]

    def register_authoritative_source(self, source_type: str, domain: str = None, doc_id: str = None):
        self.authoritative_sources.add(source_type)
        if domain:
            self.authoritative_domains.add(domain)
            if doc_id:
                self.authoritative_doc_ids.add(doc_id)

    def enforce(self, context_docs: list) -> dict:
        authoritative = []
        non_authoritative = []
        for doc in context_docs:
            source = doc.get("source", "unknown")
            doc_type = doc.get("doc_type", "unknown")
            doc_id = doc.get("doc_id", "unknown")
            if (source in self.authoritative_sources or
                doc_type in self.AUTHORITATIVE_SOURCE_TYPES or
                doc_id in self.authoritative_doc_ids):
                authoritative.append(doc)
            else:
                non_authoritative.append(doc)
                conflicts = []
                overridden = []
                for non_auth_doc in non_authoritative:
                for auth_doc in authoritative:
                if self._is_contradicting(non_auth_doc, auth_doc):
                conflicts.append({
                    "authoritative_doc": {"doc_id": auth_doc.get("doc_id"), "source": auth_doc.get("source"), "type": auth_doc.get("doc_type")},
                    "conflicting_doc": {"doc_id": non_auth_doc.get("doc_id"), "source": non_auth_doc.get("source"), "type": non_auth_doc.get("doc_type")}
                })
                overridden.append(non_auth_doc.get("doc_id"))
                clean_docs = [d for d in non_authoritative if d.get("doc_id") not in overridden]
                final_context = authoritative + clean_docs
                return {
                    "action": "enforced", "authoritative_count": len(authoritative),
                    "non_authoritative_count": len(non_authoritative), "conflicts_detected": len(conflicts),
                    "conflicts": conflicts, "overridden_docs": overridden, "overridden_count": len(overridden),
                    "final_context": final_context, "enforcement_timestamp": datetime.now(timezone.utc).isoformat()
                }

    def _is_contradicting(self, doc_a: dict, doc_b: dict) -> bool:
                content_a = doc_a.get("content", "").lower()
                content_b = doc_b.get("content", "").lower()
                contradiction_patterns = [
                    (r"\bmust\b", r"\bmust\s+not\b"), (r"\bshall\b", r"\bshall\s+not\b"),
                    (r"\brequired\b", r"\bnot\s+required\b|\boptional\b"),
                    (r"\bmandatory\b", r"\bnot\s+mandatory\b|\bvoluntary\b"),
                    (r"\bprohibited\b", r"\bpermitted\b|\ballowed\b"),
                    (r"\balways\b", r"\bnever\b"), (r"\ball\b", r"\bnone\b|\bno\b"),
                ]
                for pos_pattern, neg_pattern in contradiction_patterns:
                if re.search(pos_pattern, content_a) and re.search(neg_pattern, content_b):
                    return True
                if re.search(neg_pattern, content_a) and re.search(pos_pattern, content_b):
                    return True
                    return False

    def get_authoritative_summary(self, context_docs: list) -> dict:
                authoritative_in_context = []
                for doc in context_docs:
                if (doc.get("source") in self.authoritative_sources or doc.get("doc_type") in self.AUTHORITATIVE_SOURCE_TYPES):
                authoritative_in_context.append({
                    "doc_id": doc.get("doc_id"), "source": doc.get("source"),
                    "type": doc.get("doc_type"), "last_updated": doc.get("last_updated"),
                    "classification": doc.get("classification")
                })
                return {
                    "authoritative_in_context": len(authoritative_in_context), "total_in_context": len(context_docs),
                    "authoritative_ratio": len(authoritative_in_context) / max(len(context_docs), 1),
                    "sources": authoritative_in_context
                }
