class RetrievalDriftTester:
    """
    Tests if the retrieval system drifts over time.
    """
    def __init__(self):
        self.baseline_metrics = {}
        self.drift_thresholds = {
            "relevance_drop": 0.10, "latency_increase": 0.30,
            "safety_score_drop": 0.05, "source_diversity_drop": 0.15,
        }

    def establish_baseline(self, test_queries: list, rag_system) -> dict:
        metrics = {"avg_relevance": [], "avg_latency_ms": [], "safety_score": [], "source_diversity": [], "total_queries": len(test_queries)}
        for query in test_queries:
            result = rag_system.query(query)
            metrics["avg_relevance"].append(result.get("relevance_score", 0))
            metrics["avg_latency_ms"].append(result.get("latency_ms", 0))
            metrics["safety_score"].append(result.get("safety_score", 1.0))
            metrics["source_diversity"].append(len(set(d.get("source") for d in result.get("documents", []))))
            self.baseline_metrics = {
                "avg_relevance": sum(metrics["avg_relevance"]) / len(metrics["avg_relevance"]),
                "avg_latency_ms": sum(metrics["avg_latency_ms"]) / len(metrics["avg_latency_ms"]),
                "avg_safety_score": sum(metrics["safety_score"]) / len(metrics["safety_score"]),
                "avg_source_diversity": sum(metrics["source_diversity"]) / len(metrics["source_diversity"]),
                "established_at": datetime.now(timezone.utc).isoformat(), "query_count": len(test_queries)
            }
            return self.baseline_metrics

    def detect_drift(self, test_queries: list, rag_system) -> dict:
        if not self.baseline_metrics:
            return {"error": "baseline_not_established"}
            current_metrics = {"avg_relevance": [], "avg_latency_ms": [], "safety_score": [], "source_diversity": []}
            for query in test_queries:
                result = rag_system.query(query)
                current_metrics["avg_relevance"].append(result.get("relevance_score", 0))
                current_metrics["avg_latency_ms"].append(result.get("latency_ms", 0))
                current_metrics["safety_score"].append(result.get("safety_score", 1.0))
                current_metrics["source_diversity"].append(len(set(d.get("source") for d in result.get("documents", []))))
                current = {
                    "avg_relevance": sum(current_metrics["avg_relevance"]) / max(len(current_metrics["avg_relevance"]), 1),
                    "avg_latency_ms": sum(current_metrics["avg_latency_ms"]) / max(len(current_metrics["avg_latency_ms"]), 1),
                    "avg_safety_score": sum(current_metrics["safety_score"]) / max(len(current_metrics["safety_score"]), 1),
                    "avg_source_diversity": sum(current_metrics["source_diversity"]) / max(len(current_metrics["source_diversity"]), 1),
                }
                drift_detected = []
                relevance_change = (self.baseline_metrics["avg_relevance"] - current["avg_relevance"]) / max(self.baseline_metrics["avg_relevance"], 0.01)
                if relevance_change > self.drift_thresholds["relevance_drop"]:
                    drift_detected.append({"metric": "relevance", "baseline": self.baseline_metrics["avg_relevance"],
                        "current": current["avg_relevance"], "change": relevance_change, "direction": "degraded"})
                        latency_change = (current["avg_latency_ms"] - self.baseline_metrics["avg_latency_ms"]) / max(self.baseline_metrics["avg_latency_ms"], 1)
                        if latency_change > self.drift_thresholds["latency_increase"]:
                        drift_detected.append({"metric": "latency", "baseline": self.baseline_metrics["avg_latency_ms"],
                            "current": current["avg_latency_ms"], "change": latency_change, "direction": "increased"})
                            safety_change = (self.baseline_metrics["avg_safety_score"] - current["avg_safety_score"]) / max(self.baseline_metrics["avg_safety_score"], 0.01)
                            if safety_change > self.drift_thresholds["safety_score_drop"]:
                            drift_detected.append({"metric": "safety_score", "baseline": self.baseline_metrics["avg_safety_score"],
                                "current": current["avg_safety_score"], "change": safety_change, "direction": "degraded"})
                                diversity_change = (self.baseline_metrics["avg_source_diversity"] - current["avg_source_diversity"]) / max(self.baseline_metrics["avg_source_diversity"], 0.01)
                                if diversity_change > self.drift_thresholds["source_diversity_drop"]:
                                drift_detected.append({"metric": "source_diversity", "baseline": self.baseline_metrics["avg_source_diversity"],
                                    "current": current["avg_source_diversity"], "change": diversity_change, "direction": "degraded"})
                                    return {
                                        "drift_detected": len(drift_detected) > 0, "drift_count": len(drift_detected),
                                        "drift_details": drift_detected,
                                        "baseline_age_days": (datetime.now(timezone.utc) - parse_ts(self.baseline_metrics["established_at"])).days,
                                        "current_metrics": current, "baseline_metrics": self.baseline_metrics,
                                        "action": "alert" if len(drift_detected) >= 2 else "warning" if drift_detected else "ok"
                                    }
