class SensitivityInheritanceEngine:
    """
    Implements sensitivity inheritance — output inherits the maximum sensitivity
    of any source document that influenced it.
    """
    def __init__(self):
        self.sensitivity_levels = {
            1: {"label": "public", "restrictions": []},
            2: {"label": "internal", "restrictions": ["no_external_sharing"]},
            3: {"label": "confidential", "restrictions": ["no_external_sharing", "need_to_know"]},
            4: {"label": "restricted", "restrictions": ["no_external_sharing", "need_to_know", "audit_required"]},
            5: {"label": "secret", "restrictions": ["no_external_sharing", "need_to_know", "audit_required", "legal_review"]},
        }

    def compute_output_sensitivity(self, source_docs: list, output: str) -> dict:
        if not source_docs:
            return {"sensitivity_level": 1, "label": "public", "inheritance_source": "default"}
            source_sensitivities = []
            for doc in source_docs:
                level = doc.get("sensitivity_tier", 1)
                source_sensitivities.append({
                    "doc_id": doc.get("doc_id"), "level": level,
                    "label": self.sensitivity_levels.get(level, {}).get("label", "unknown"),
                    "classification": doc.get("classification", "public")
                })
                max_source_level = max(s["level"] for s in source_sensitivities)
                output_level = self._assess_output_sensitivity(output)
                inherited_level = max(max_source_level, output_level)
                restrictions = []
                for level in range(1, inherited_level + 1):
                    level_restrictions = self.sensitivity_levels.get(level, {}).get("restrictions", [])
                    restrictions.extend(level_restrictions)
                    restrictions = list(dict.fromkeys(restrictions))
                    return {
                        "inherited_sensitivity": inherited_level,
                        "label": self.sensitivity_levels.get(inherited_level, {}).get("label", "unknown"),
                        "max_source_sensitivity": max_source_level,
                        "output_assessed_sensitivity": output_level,
                        "inheritance_type": "amplified" if output_level > max_source_level else "direct",
                        "source_sensitivities": source_sensitivities,
                        "restrictions": restrictions, "restriction_count": len(restrictions),
                        "requires_legal_review": "legal_review" in restrictions,
                        "requires_audit": "audit_required" in restrictions
                    }

    def _assess_output_sensitivity(self, output: str) -> int:
        output_lower = output.lower()
        sensitivity_keywords = {
            5: ["secret", "top secret", "classified", "eyes only", "restricted access"],
            4: ["restricted", "sensitive", "proprietary", "trade secret", "internal use only"],
            3: ["confidential", "privileged", "non-public", "do not distribute"],
            2: ["internal", "company use", "not for external", "employee only"],
            1: ["public", "publicly available", "unrestricted"],
        }
        max_level = 1
        for level, keywords in sensitivity_keywords.items():
            if any(kw in output_lower for kw in keywords):
                max_level = max(max_level, level)
                if re.search(r'\b\d{3}-\d{2}-\d{4}\b', output): # SSN
                max_level = max(max_level, 4)
                if re.search(r'\b\d{16}\b', output): # Credit card
                max_level = max(max_level, 5)
                if re.search(r'(?i)(password|secret|token|api[_-]?key)\s*[:=]', output):
                    max_level = max(max_level, 5)
                    return max_level
