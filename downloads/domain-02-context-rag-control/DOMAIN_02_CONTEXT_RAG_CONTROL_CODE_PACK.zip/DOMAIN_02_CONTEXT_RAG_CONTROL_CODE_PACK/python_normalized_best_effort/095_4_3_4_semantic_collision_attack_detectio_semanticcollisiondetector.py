class SemanticCollisionDetector:
    """
    Detects semantic collision attacks — documents that collide with legitimate concepts
    to be retrieved in inappropriate contexts.
    """
    def __init__(self):
        self.collision_threshold = 0.85
        self.concept_boundaries = {}

    def define_concept_boundary(self, concept: str, legitimate_embeddings: list):
        if not legitimate_embeddings:
            return
            centroid = self._compute_centroid(legitimate_embeddings)
            max_distance = max(self._cosine_distance(e, centroid) for e in legitimate_embeddings)
            self.concept_boundaries[concept] = {
                "centroid": centroid, "max_legitimate_distance": max_distance,
                "sample_count": len(legitimate_embeddings), "defined_at": datetime.now(timezone.utc).isoformat()
            }

    def detect_collision(self, concept: str, candidate_embedding: list, candidate_metadata: dict) -> dict:
        if concept not in self.concept_boundaries:
            return {"collision_detected": False, "reason": "concept_not_defined"}
            boundary = self.concept_boundaries[concept]
            centroid = boundary["centroid"]
            max_legit = boundary["max_legitimate_distance"]
            distance = self._cosine_distance(candidate_embedding, centroid)
            collision = distance <= max_legit * 1.1
            return {
                "collision_detected": collision, "concept": concept,
                "distance_to_centroid": distance, "boundary_limit": max_legit,
                "within_boundary": distance <= max_legit, "metadata": candidate_metadata,
                "severity": "high" if collision and distance <= max_legit * 0.5 else "medium" if collision else "none"
            }

    def _compute_centroid(self, embeddings: list) -> list:
        if not embeddings:
            return []
            dim = len(embeddings[0])
            centroid = [0.0] * dim
            for e in embeddings:
                for j in range(dim):
                    centroid[j] += e[j]
                    return [c / len(embeddings) for c in centroid]

    def _cosine_distance(self, vec1: list, vec2: list) -> float:
        dot = sum(a*b for a,b in zip(vec1, vec2))
        norm1 = (sum(a*a for a in vec1))**0.5
        norm2 = (sum(b*b for b in vec2))**0.5
        if norm1 == 0 or norm2 == 0:
            return 1.0
            return 1.0 - (dot / (norm1 * norm2))
