class SourceRankingIntegrity:
    """
    Ensures source ordering is not manipulated.
    Authoritative sources always take precedence over non-authoritative ones.
    """
    SOURCE_RANKING = {
        "official_policy": 100,
        "internal_wiki": 90,
        "verified_partner": 80,
        "partner_feed": 60,
        "public_government": 50,
        "public_verified": 40,
        "public_unverified": 20,
        "web_crawl": 10,
        "unknown": 0,
    }

    def rank_sources(self, results: list) -> list:
        for result in results:
            source = result.get("source", "unknown")
            source_rank = self.SOURCE_RANKING.get(source, 0)
            relevance = result.get("relevance_score", 0)
            result["composite_score"] = (source_rank * 0.6 + relevance * 100 * 0.4)
            results.sort(key=lambda r: r.get("composite_score", 0), reverse=True)
            return results

    def detect_ranking_manipulation(self, original_order: list, ranked_order: list) -> dict:
        position_changes = []
        for i, doc in enumerate(ranked_order):
            original_position = next((j for j, d in enumerate(original_order) if d.get("doc_id") == doc.get("doc_id")), -1)
            if original_position >= 0:
                change = original_position - i
                position_changes.append({
                    "doc_id": doc.get("doc_id"),
                    "original_position": original_position,
                    "new_position": i,
                    "change": change,
                    "source": doc.get("source"),
                    "source_rank": self.SOURCE_RANKING.get(doc.get("source"), 0)
                })
                suspicious_changes = [pc for pc in position_changes if pc["source_rank"] < 40 and pc["change"] < -5]
                return {"action": "flag" if suspicious_changes else "ok",
                    "position_changes": position_changes,
                    "suspicious_changes": suspicious_changes,
                    "total_documents": len(ranked_order)}
