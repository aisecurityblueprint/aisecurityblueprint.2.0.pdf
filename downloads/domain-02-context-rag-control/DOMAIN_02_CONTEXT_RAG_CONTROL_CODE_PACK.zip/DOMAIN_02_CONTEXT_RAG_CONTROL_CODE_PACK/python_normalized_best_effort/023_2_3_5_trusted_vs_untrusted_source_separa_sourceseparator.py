class SourceSeparator:
    """
    Maintains strict separation between trusted and untrusted sources.
    Untrusted sources are never mixed with trusted without explicit demarcation.
    """
    def __init__(self):
        self.trusted_sources = set()
        self.untrusted_sources = set()
        self.blocked_sources = set()
        self.separation_log = []

    def register_source(self, source: str, trust_level: int):
        if trust_level >= 4:
            self.trusted_sources.add(source)
        elif trust_level >= 2:
            self.untrusted_sources.add(source)
        else:
            self.blocked_sources.add(source)

    def separate_context(self, docs: list) -> dict:
        trusted = []
        untrusted = []
        blocked = []
        for doc in docs:
            source = doc.get("source", "unknown")
            if source in self.blocked_sources:
                blocked.append(doc)
                continue
                if source in self.trusted_sources:
                    trusted.append(doc)
                else:
                    untrusted.append(doc)
                    context_parts = []
                    if trusted:
                        context_parts.append("=== TRUSTED SOURCES ===")
                        for doc in trusted:
                            context_parts.append(f"[TRUSTED | {doc.get('source')} | {doc.get('doc_id')}]\n{doc.get('content', '')}")
                            if untrusted:
                                context_parts.append("\n=== UNTRUSTED SOURCES (VERIFY BEFORE USE) ===")
                                for doc in untrusted:
                                    context_parts.append(f"[UNTRUSTED | {doc.get('source')} | {doc.get('doc_id')}]\n{doc.get('content', '')}")
                                    self.separation_log.append({
                                        "timestamp": datetime.now(timezone.utc).isoformat(),
                                        "trusted_count": len(trusted), "untrusted_count": len(untrusted), "blocked_count": len(blocked)
                                    })
                                    return {
                                        "context": "\n\n".join(context_parts),
                                        "trusted": trusted, "untrusted": untrusted, "blocked": blocked,
                                        "trusted_ratio": len(trusted) / max(len(trusted) + len(untrusted), 1)
                                    }
