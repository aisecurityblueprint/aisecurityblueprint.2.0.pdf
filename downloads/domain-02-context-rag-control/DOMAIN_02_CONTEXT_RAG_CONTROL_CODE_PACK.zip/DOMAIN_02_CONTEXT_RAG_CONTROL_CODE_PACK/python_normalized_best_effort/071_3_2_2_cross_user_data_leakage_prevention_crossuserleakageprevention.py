class CrossUserLeakagePrevention:
    """
    Prevents data leakage between users within the same tenant.
    """
    def __init__(self):
        self.user_data_access_log = []
        self.leakage_incidents = []

    def validate_user_data_boundary(self, requesting_user: str, data_owner: str,
        data_sensitivity: int, user_clearance: int) -> dict:
        if requesting_user == data_owner:
            return {"allowed": True, "reason": "same_user"}
        if user_clearance < data_sensitivity:
        self._log_leakage_attempt(requesting_user, data_owner, data_sensitivity, user_clearance)
        return {"allowed": False, "reason": "insufficient_clearance_for_cross_user_access",
            "required_clearance": data_sensitivity, "user_clearance": user_clearance}
            self.user_data_access_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(), "requesting_user": requesting_user,
                "data_owner": data_owner, "data_sensitivity": data_sensitivity,
                "user_clearance": user_clearance, "action": "authorized_cross_user_access"
            })
            return {"allowed": True, "reason": "authorized_cross_user_access", "warning": "Cross-user access logged for audit"}

    def _log_leakage_attempt(self, requesting_user: str, data_owner: str, data_sensitivity: int, user_clearance: int):
            self.leakage_incidents.append({
                "timestamp": datetime.now(timezone.utc).isoformat(), "type": "cross_user_leakage_attempt",
                "requesting_user": requesting_user, "data_owner": data_owner,
                "data_sensitivity": data_sensitivity, "user_clearance": user_clearance, "action": "blocked"
            })

    def get_leakage_report(self) -> dict:
            recent = [i for i in self.leakage_incidents if (datetime.now(timezone.utc) - parse_ts(i["timestamp"])).days < 7]
            return {
                "total_incidents": len(self.leakage_incidents), "recent_incidents": len(recent),
                "unique_users_involved": len(set(i["requesting_user"] for i in self.leakage_incidents)),
                "alert_threshold_exceeded": len(recent) > 5
            }
