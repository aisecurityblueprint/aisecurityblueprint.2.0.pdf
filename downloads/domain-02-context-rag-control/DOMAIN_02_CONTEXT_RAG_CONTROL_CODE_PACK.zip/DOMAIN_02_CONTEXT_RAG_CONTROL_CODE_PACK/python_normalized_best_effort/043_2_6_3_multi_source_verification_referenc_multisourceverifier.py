class MultiSourceVerifier:
    """
    Verifies information across multiple independent sources.
    Implements two-source verification for critical facts.
    """
    def __init__(self):
        self.min_independent_sources = 2
        self.verification_threshold = 0.70
        self.independent_source_types = [
            "internal_policy", "regulatory_filing", "verified_partner", "government_public",
        ]

    def verify(self, fact: str, sources: list) -> dict:
        independent_sources = [
            s for s in sources
            if s.get("doc_type") in self.independent_source_types or s.get("source") in self.independent_source_types
        ]
        if len(independent_sources) < self.min_independent_sources:
            return {"verified": False, "reason": f"insufficient_independent_sources: {len(independent_sources)} < {self.min_independent_sources}", "confidence": 0.3}
            supporting = 0
            contradicting = 0
            source_results = []
            for source in independent_sources:
                content = source.get("content", "").lower()
                if self._source_supports_fact(fact, content):
                    supporting += 1
                    source_results.append({"source": source.get("source"), "doc_id": source.get("doc_id"), "verdict": "supporting"})
                elif self._source_contradicts_fact(fact, content):
                    contradicting += 1
                    source_results.append({"source": source.get("source"), "doc_id": source.get("doc_id"), "verdict": "contradicting"})
                else:
                    source_results.append({"source": source.get("source"), "doc_id": source.get("doc_id"), "verdict": "neutral"})
                    total = len(independent_sources)
                    agreement_ratio = supporting / total if total > 0 else 0
                    verified = (agreement_ratio >= self.verification_threshold and supporting >= self.min_independent_sources)
                    confidence = agreement_ratio if verified else agreement_ratio * 0.5
                    return {
                        "verified": verified, "fact_preview": fact[:150], "total_sources": total,
                        "supporting": supporting, "contradicting": contradicting, "agreement_ratio": agreement_ratio,
                        "confidence": confidence, "source_results": source_results,
                        "verification_level": "multi_source_verified" if verified else "single_source" if supporting == 1 else "unverified"
                    }

    def _source_supports_fact(self, fact: str, content: str) -> bool:
        fact_keywords = set(fact.lower().split()) - {"the", "is", "are", "a", "an", "in", "on", "at"}
        matches = sum(1 for kw in fact_keywords if kw in content)
        return matches / max(len(fact_keywords), 1) > 0.6

    def _source_contradicts_fact(self, fact: str, content: str) -> bool:
        fact_lower = fact.lower()
        if re.search(r'\bmust\b', fact_lower) and re.search(r'\bmust\s+not\b', content):
            return True
            if re.search(r'\bis\b', fact_lower) and re.search(r'\bis\s+not\b', content):
                return True
                if re.search(r'\brequired\b', fact_lower) and re.search(r'\bnot\s+required\b', content):
                    return True
                    return False
