class ContextTruncationStrategy:
    """
    Defines how to truncate context when the token limit is exceeded.
    System segments are never truncated.
    """
    TRUNCATION_PRIORITY = [
        "system", "rag_authoritative", "memory", "user", "rag_general", "tools",
    ]
    SEGMENT_PATTERN = re.compile(
        r"<(SYSTEM|RAG|USER|TOOL|MEMORY)((?:\s[^>]*)?)>(.*?)</\1>",
        re.DOTALL,
    )

    def truncate(self, context: str, max_tokens: int, tokenizer) -> str:
        segments = self._parse_segments(context)
        for seg in segments:
            seg["tokens"] = len(tokenizer.encode(seg["content"]))
            total_tokens = sum(s["tokens"] for s in segments)
            if total_tokens <= max_tokens:
                return context

                cut_order = sorted(
                    segments,
                    key=lambda s: self.TRUNCATION_PRIORITY.index(self._get_priority_key(s["type"])),
                    reverse=True,
                )
                tokens_to_remove = total_tokens - max_tokens
                for seg in cut_order:
                    if tokens_to_remove <= 0:
                        break
                        if seg["type"] == "system":
                            continue
                            if seg["tokens"] <= tokens_to_remove:
                                tokens_to_remove -= seg["tokens"]
                                seg["content"] = ""
                                seg["tokens"] = 0
                            else:
                                keep = seg["tokens"] - tokens_to_remove
                                seg["content"] = self._truncate_to_tokens(seg["content"], keep, tokenizer)
                                seg["tokens"] = keep
                                tokens_to_remove = 0
                                return self._reconstruct_context(segments)

    def _parse_segments(self, context: str) -> list:
        segments = []
        for match in self.SEGMENT_PATTERN.finditer(context):
            tag, attrs, content = match.group(1), match.group(2), match.group(3)
            seg_type = tag.lower()
            if tag == "RAG":
                seg_type = "rag_authoritative" if 'trust="high"' in attrs else "rag_general"
                segments.append({"tag": tag, "type": seg_type, "attrs": attrs, "content": content.strip()})
                return segments

    def _reconstruct_context(self, segments: list) -> str:
        parts = []
        for seg in segments:
            if seg["content"]:
                parts.append(f"<{seg['tag']}{seg['attrs']}>\n{seg['content']}\n</{seg['tag']}>")
                return "\n\n".join(parts)

    def _truncate_to_tokens(self, text: str, max_tokens: int, tokenizer) -> str:
        token_ids = tokenizer.encode(text)
        if len(token_ids) <= max_tokens:
            return text
            return tokenizer.decode(token_ids[:max_tokens]) + " [TRUNCATED]"

    def _get_priority_key(self, segment_type: str) -> str:
        if segment_type == "system": return "system"
        if "authoritative" in segment_type or "trusted" in segment_type: return "rag_authoritative"
        if segment_type == "memory": return "memory"
        if segment_type == "user": return "user"
        if "rag" in segment_type: return "rag_general"
        return "tools"
