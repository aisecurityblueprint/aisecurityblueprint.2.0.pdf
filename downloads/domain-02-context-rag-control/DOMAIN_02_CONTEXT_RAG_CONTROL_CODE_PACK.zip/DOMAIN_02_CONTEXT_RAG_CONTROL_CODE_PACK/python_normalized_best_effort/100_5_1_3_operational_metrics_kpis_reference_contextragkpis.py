class ContextRAGKPIs:
    """
    Defines and monitors operational KPIs for Context & RAG Control.
    """
    def __init__(self):
        self.kpi_definitions = {
            "security": {
                "injection_detection_rate": {"description": "RAG injection detection rate",
                    "target": ">= 95%", "unit": "percentage",
                    "calculation": "injections_detected / total_injections * 100"},
                    "false_positive_rate": {"description": "False positive rate", "target": "<= 5%", "unit": "percentage",
                        "calculation": "false_positives / total_detections * 100"},
                        "mean_time_to_detect": {"description": "Mean time to detect threat", "target": "<= 100ms", "unit": "milliseconds",
                            "calculation": "avg(detection_timestamp - injection_timestamp)"},
                            "block_rate": {"description": "Malicious content block rate", "target": ">= 99%", "unit": "percentage",
                                "calculation": "malicious_blocked / total_malicious * 100"},
                            },
                            "quality": {
                                "context_relevance": {"description": "Average retrieved context relevance", "target": ">= 0.80", "unit": "score (0-1)",
                                    "calculation": "avg(relevance_score)"},
                                    "source_diversity": {"description": "Source diversity in context", "target": ">= 3 sources", "unit": "count",
                                        "calculation": "avg(unique_sources_per_query)"},
                                        "freshness_score": {"description": "Data freshness score", "target": ">= 0.75", "unit": "score (0-1)",
                                            "calculation": "avg(freshness_score)"},
                                        },
                                        "performance": {
                                            "retrieval_latency_p95": {"description": "Retrieval latency at 95th percentile", "target": "<= 200ms", "unit": "milliseconds",
                                                "calculation": "percentile(latency, 95)"},
                                                "context_assembly_time": {"description": "Context assembly time", "target": "<= 50ms", "unit": "milliseconds",
                                                    "calculation": "avg(assembly_duration_ms)"},
                                                    "throughput": {"description": "Queries processed per second", "target": ">= 100 QPS", "unit": "queries_per_second",
                                                        "calculation": "total_queries / time_window_seconds"},
                                                    },
                                                    "governance": {
                                                        "compliance_score": {"description": "Policy compliance score", "target": ">= 95%", "unit": "percentage",
                                                            "calculation": "compliant_requests / total_requests * 100"},
                                                            "audit_completeness": {"description": "Audit log completeness", "target": ">= 99.9%", "unit": "percentage",
                                                                "calculation": "logged_events / total_events * 100"},
                                                                "incident_response_time": {"description": "Mean incident response time", "target": "<= 5 minutes", "unit": "minutes",
                                                                    "calculation": "avg(response_timestamp - detection_timestamp)"},
                                                                },
                                                            }
                                                            self.kpi_history = {category: {kpi: [] for kpi in kpis} for category, kpis in self.kpi_definitions.items()}

    def record_kpi(self, category: str, kpi_name: str, value: float):
                                                            if category in self.kpi_history and kpi_name in self.kpi_history[category]:
                                                            self.kpi_history[category][kpi_name].append({"value": value, "timestamp": datetime.now(timezone.utc).isoformat()})

    def get_kpi_dashboard(self) -> dict:
                                                            dashboard = {}
                                                            for category, kpis in self.kpi_definitions.items():
                                                            dashboard[category] = {}
                                                            for kpi_name, kpi_def in kpis.items():
                                                            recent_values = [entry["value"] for entry in self.kpi_history.get(category, {}).get(kpi_name, [])[-100:]]
                                                            if recent_values:
                                                            dashboard[category][kpi_name] = {
                                                                "current": recent_values[-1], "average": sum(recent_values) / len(recent_values),
                                                                "min": min(recent_values), "max": max(recent_values),
                                                                "target": kpi_def["target"], "unit": kpi_def["unit"],
                                                                "trend": "improving" if len(recent_values) >= 2 and recent_values[-1] > recent_values[0]
                                                                else "declining" if len(recent_values) >= 2 and recent_values[-1] < recent_values[0]
                                                                else "stable"
                                                            }
                                                        else:
                                                            dashboard[category][kpi_name] = {"current": None, "target": kpi_def["target"],
                                                                "unit": kpi_def["unit"], "status": "no_data"}
                                                                return {"dashboard": dashboard, "generated_at": datetime.now(timezone.utc).isoformat(),
                                                                    "data_points": sum(len(entries) for cat in self.kpi_history.values() for entries in cat.values())}
