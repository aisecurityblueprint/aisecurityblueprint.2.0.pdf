class RetrievalProvenanceLogger:
    """
    Logs provenance of each document retrieved into context.
    """
    def __init__(self):
        self.provenance_entries = {}
        self.query_to_docs_map = {}

    def log_retrieval(self, query_id: str, doc_id: str, retrieval_metadata: dict) -> str:
        entry_id = hashlib.sha256(f"{query_id}:{doc_id}:{datetime.now(timezone.utc).isoformat()}".encode()).hexdigest()[:16]
        entry = {
            "entry_id": entry_id, "query_id": query_id, "doc_id": doc_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "rank_position": retrieval_metadata.get("rank_position"),
            "relevance_score": retrieval_metadata.get("relevance_score"),
            "retrieval_method": retrieval_metadata.get("method", "semantic_search"),
            "source": retrieval_metadata.get("source"), "tenant_id": retrieval_metadata.get("tenant_id"),
            "user_id": retrieval_metadata.get("user_id"),
        }
        self.provenance_entries[entry_id] = entry
        if query_id not in self.query_to_docs_map:
            self.query_to_docs_map[query_id] = []
            self.query_to_docs_map[query_id].append(entry_id)
            return entry_id

    def get_query_provenance(self, query_id: str) -> dict:
        doc_entries = self.query_to_docs_map.get(query_id, [])
        documents = [self.provenance_entries[eid] for eid in doc_entries if eid in self.provenance_entries]
        documents.sort(key=lambda d: d.get("rank_position", 999))
        return {
            "query_id": query_id, "documents_retrieved": len(documents), "documents": documents,
            "sources_used": list(set(d["source"] for d in documents if d.get("source"))),
            "average_relevance": sum(d.get("relevance_score", 0) for d in documents) / max(len(documents), 1)
        }

    def get_document_usage(self, doc_id: str) -> dict:
        queries = [entry for entry in self.provenance_entries.values() if entry["doc_id"] == doc_id]
        return {
            "doc_id": doc_id, "times_retrieved": len(queries), "queries": queries[-20:],
            "first_retrieved": queries[0]["timestamp"] if queries else None,
            "last_retrieved": queries[-1]["timestamp"] if queries else None
        }
