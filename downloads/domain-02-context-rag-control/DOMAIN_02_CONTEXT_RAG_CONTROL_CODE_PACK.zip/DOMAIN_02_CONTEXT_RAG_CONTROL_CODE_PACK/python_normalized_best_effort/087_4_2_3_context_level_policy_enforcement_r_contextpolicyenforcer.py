class ContextPolicyEnforcer:
    """
    Applies context-level security policies.
    """
    def __init__(self):
        self.policies = {
            "min_trust_threshold": {"rule": "average_trust >= 2.5", "action_if_violated": "block",
                "description": "Average trust must be >= 2.5"},
                "max_untrusted_ratio": {"rule": "untrusted_ratio <= 0.30", "action_if_violated": "escalate",
                    "description": "Max 30% untrusted sources"},
                    "require_authoritative_for_critical": {"rule": "has_authoritative_source if context_contains(['financial', 'legal', 'security'])",
                        "action_if_violated": "block",
                        "description": "Critical contexts require authoritative source"},
                        "max_context_age": {"rule": "oldest_document_age_days <= 365", "action_if_violated": "flag",
                            "description": "Documents older than 1 year not allowed"},
                            "no_cross_tenant_data": {"rule": "cross_tenant_violations == 0", "action_if_violated": "block",
                                "description": "Zero cross-tenant violations"},
                            }

    def enforce(self, context_metadata: dict) -> dict:
                            violations = []
                            for policy_name, policy_config in self.policies.items():
                            rule = policy_config["rule"]
                            violated = self._evaluate_rule(rule, context_metadata)
                            if violated:
                            violations.append({
                                "policy": policy_name, "description": policy_config["description"],
                                "action": policy_config["action_if_violated"], "rule": rule
                            })
                            action_priority = {"block": 4, "escalate": 3, "flag": 2, "accept": 1}
                            final_action = "accept"
                            for violation in violations:
                            if action_priority.get(violation["action"], 0) > action_priority.get(final_action, 0):
                            final_action = violation["action"]
                            return {
                                "action": final_action, "policies_checked": len(self.policies),
                                "violations": violations, "violation_count": len(violations), "compliant": len(violations) == 0
                            }

    def _evaluate_rule(self, rule: str, context: dict) -> bool:
                            if "average_trust" in rule:
                            avg_trust = context.get("average_trust", 0)
                            threshold = float(rule.split(">=")[1].strip()) if ">=" in rule else 2.5
                            return avg_trust < threshold
                            if "untrusted_ratio" in rule:
                            untrusted_ratio = context.get("untrusted_ratio", 0)
                            threshold = float(rule.split("<=")[1].strip()) if "<=" in rule else 0.30
                            return untrusted_ratio > threshold
                            if "has_authoritative_source" in rule:
                            has_auth = context.get("has_authoritative_source", False)
                            context_topics = context.get("context_topics", [])
                            critical_topics = ["financial", "legal", "security"]
                            needs_auth = any(t in context_topics for t in critical_topics)
                            return needs_auth and not has_auth
                            if "oldest_document_age" in rule:
                            oldest_age = context.get("oldest_document_age_days", 0)
                            threshold = float(rule.split("<=")[1].strip()) if "<=" in rule else 365
                            return oldest_age > threshold
                            if "cross_tenant_violations" in rule:
                            violations = context.get("cross_tenant_violations", 0)
                            return violations > 0
                            return False
