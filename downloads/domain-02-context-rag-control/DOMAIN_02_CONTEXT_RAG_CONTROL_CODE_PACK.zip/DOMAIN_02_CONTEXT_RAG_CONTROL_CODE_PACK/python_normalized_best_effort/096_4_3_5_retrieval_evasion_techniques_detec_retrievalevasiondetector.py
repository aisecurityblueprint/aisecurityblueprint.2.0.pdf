class RetrievalEvasionDetector:
    """
    Detects retrieval evasion techniques — when adversaries manipulate documents
    to avoid security filters while still influencing the model.
    """
    def __init__(self):
        self.evasion_patterns = {
            "content_fragmentation": self._detect_fragmentation,
            "semantic_obfuscation": self._detect_obfuscation,
            "trust_level_manipulation": self._detect_trust_manipulation,
            "temporal_evasion": self._detect_temporal_evasion,
        }

    def detect_evasion(self, document: dict, retrieval_context: dict) -> dict:
        findings = []
        for pattern_name, detector_func in self.evasion_patterns.items():
            result = detector_func(document, retrieval_context)
            if result["evasion_detected"]:
                findings.append(result)
                return {
                    "evasion_detected": len(findings) > 0, "findings": findings,
                    "evasion_count": len(findings),
                    "action": "block" if len(findings) >= 2 else "quarantine" if findings else "accept"
                }

    def _detect_fragmentation(self, doc: dict, context: dict) -> dict:
        content = doc.get("content", "")
        if 10 < len(content) < 100:
            suspicious_keywords = ["ignore", "override", "bypass", "instead", "however"]
            matches = [kw for kw in suspicious_keywords if kw in content.lower()]
            if matches:
                return {"pattern": "content_fragmentation", "evasion_detected": True,
                    "content_length": len(content), "suspicious_keywords": matches, "severity": "medium"}
                    return {"evasion_detected": False}

    def _detect_obfuscation(self, doc: dict, context: dict) -> dict:
                    content = doc.get("content", "")
                    obfuscation_indicators = ["pursuant to", "in accordance with", "heretofore",
                        "notwithstanding", "whereas", "henceforth"]
                        matches = [ind for ind in obfuscation_indicators if ind in content.lower()]
                        if len(matches) >= 3:
                            return {"pattern": "semantic_obfuscation", "evasion_detected": True,
                                "indicators_found": matches, "severity": "low"}
                                return {"evasion_detected": False}

    def _detect_trust_manipulation(self, doc: dict, context: dict) -> dict:
                                source = doc.get("source", "")
                                content = doc.get("content", "")
                                if source in ["web_crawl", "public_unverified", "unknown"]:
                                authoritative_phrases = ["official policy", "per regulation", "as mandated by",
                                    "per directive", "according to section", "compliance requires"]
                                    matches = [p for p in authoritative_phrases if p in content.lower()]
                                    if matches:
                                        return {"pattern": "trust_level_manipulation", "evasion_detected": True,
                                            "source": source, "authoritative_phrases": matches, "severity": "high"}
                                            return {"evasion_detected": False}

    def _detect_temporal_evasion(self, doc: dict, context: dict) -> dict:
                                            last_updated = doc.get("last_updated", "")
                                            if last_updated:
                                            try:
                                            date = parse_ts(last_updated)
                                            if date > datetime.now(timezone.utc):
                                                return {"pattern": "temporal_evasion", "evasion_detected": True,
                                                    "type": "future_date", "date": last_updated, "severity": "high"}
                                                    days_old = (datetime.now(timezone.utc) - date).days
                                                    if days_old > 365 * 5:
                                                        return {"pattern": "temporal_evasion", "evasion_detected": True,
                                                            "type": "excessively_old", "days_old": days_old, "severity": "medium"}
                                                        except (ValueError, TypeError):
                                                            return {"pattern": "temporal_evasion", "evasion_detected": True, "type": "invalid_date", "severity": "medium"}
                                                            return {"evasion_detected": False}
