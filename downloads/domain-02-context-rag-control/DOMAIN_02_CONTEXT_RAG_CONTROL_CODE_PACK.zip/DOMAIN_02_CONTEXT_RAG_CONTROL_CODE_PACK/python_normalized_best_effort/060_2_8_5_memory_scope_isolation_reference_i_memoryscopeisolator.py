class MemoryScopeIsolator:
    """
    Ensures scope isolation between different memory types and between different users/tenants.
    """
    def __init__(self):
        self.scopes = {
            "user": {"isolation": "strict", "sharing": "none"},
            "session": {"isolation": "strict", "sharing": "none"},
            "tenant": {"isolation": "strict", "sharing": "within_tenant"},
            "global": {"isolation": "none", "sharing": "all"},
        }
        self.cross_scope_access_attempts = []

    def validate_access(self, user_id: str, tenant_id: str, memory_scope: str,
        memory_owner: str, memory_tenant: str) -> dict:
        if memory_scope == "user":
        if memory_owner != user_id:
        self._log_violation(user_id, memory_scope, memory_owner)
        return {"allowed": False, "reason": "cross_user_access_blocked"}
    elif memory_scope == "session":
        if memory_owner != user_id:
        self._log_violation(user_id, memory_scope, memory_owner)
        return {"allowed": False, "reason": "cross_session_access_blocked"}
    elif memory_scope == "tenant":
        if memory_tenant != tenant_id:
        self._log_violation(user_id, memory_scope, memory_tenant)
        return {"allowed": False, "reason": "cross_tenant_access_blocked"}
    elif memory_scope == "global":
        return {"allowed": True, "scope": "global"}
        return {"allowed": True}

    def _log_violation(self, user_id: str, scope: str, owner: str):
        self.cross_scope_access_attempts.append({
            "timestamp": datetime.now(timezone.utc).isoformat(), "user_id": user_id,
            "attempted_scope": scope, "memory_owner": owner, "action": "blocked"
        })

    def get_isolation_report(self) -> dict:
        recent_violations = [v for v in self.cross_scope_access_attempts
            if (datetime.now(timezone.utc) - parse_ts(v["timestamp"])).seconds < 3600]
            return {
                "total_violations": len(self.cross_scope_access_attempts),
                "recent_violations": len(recent_violations),
                "violations_by_scope": self._count_by_scope(),
                "alert": len(recent_violations) > 10
            }

    def _count_by_scope(self) -> dict:
            counts = {}
            for v in self.cross_scope_access_attempts:
            scope = v["attempted_scope"]
            counts[scope] = counts.get(scope, 0) + 1
            return counts
