class CrossChunkInjectionDetector:
    def __init__(self, window_size: int = 3, embedding_backend=None, normalizer=None):
        self.window_size = window_size
        self.embedding_backend = embedding_backend
        self.normalizer = normalizer or InputNormalizer()
        self.lexical_similarity_threshold = 0.75
        self.instruction_terms = {
            "ignore", "bypass", "override", "forget", "disregard", "instead", "replace", "change", "modify", "must", "should", "output", "respond", "always", "never", "from now on",
            "ignore", "ignora", "esqueça", "esqueca", "desconsidere", "burlar", "contornar", "substituir", "alterar", "modificar", "deve", "responda", "sempre", "nunca", "a partir de agora",
            "ignora", "olvida", "descarta", "elude", "evita", "sustituye", "cambia", "modifica", "debes", "responde", "siempre", "nunca", "a partir de ahora",
        }

    def detect_distributed_injection(self, chunks: list) -> dict:
        normalized_chunks = []
        for c in chunks:
            c2 = dict(c)
            c2["content"] = self.normalizer.normalize(c.get("content", ""))["normalized"]
            normalized_chunks.append(c2)
            chunks = normalized_chunks
            n = len(chunks)
            if n < 2:
                return {"detected": False, "reason": "insufficient_chunks"}
                findings = []
                for i in range(n - self.window_size + 1):
                    window = chunks[i:i+self.window_size]
                    window_text = " ".join(c.get("content", "") for c in window)
                    individual_scores = [self._score_instruction_density(c.get("content", "")) for c in window]
                    avg_individual = sum(individual_scores) / len(individual_scores)
                    combined_score = self._score_instruction_density(window_text)
                    if combined_score > avg_individual * 2.0 and combined_score > 0.4:
                        findings.append({"type": "distributed_instruction", "window_start": i, "window_end": i+self.window_size-1, "individual_scores": individual_scores, "avg_individual": avg_individual, "combined_score": combined_score, "amplification_factor": combined_score / max(avg_individual, 0.01)})
                        for i in range(n - 1):
                            sim = self._similarity(chunks[i].get("content", ""), chunks[i+1].get("content", ""))
                            if sim > self.lexical_similarity_threshold:
                                findings.append({"type": "lexical_continuity", "chunk_a_index": i, "chunk_b_index": i+1, "similarity": sim})
                                return {"detected": bool(findings), "findings": findings, "finding_count": len(findings), "highest_severity": "high" if any(f.get("type") == "distributed_instruction" and f.get("combined_score", 0) > 0.6 for f in findings) else "medium" if findings else "low"}

    def _score_instruction_density(self, text: str) -> float:
        text_lower = text.lower()
        words = text_lower.split()
        if not words:
            return 0.0
            hits = sum(1 for term in self.instruction_terms if term in text_lower)
            return min(1.0, hits / 20)

    def _similarity(self, text1: str, text2: str) -> float:
        if self.embedding_backend:
            return self.embedding_backend.cosine_similarity(self.embedding_backend.embed(text1), self.embedding_backend.embed(text2))
            words1, words2 = set(text1.lower().split()), set(text2.lower().split())
            if not words1 or not words2:
                return 0.0
                return len(words1 & words2) / len(words1 | words2)
