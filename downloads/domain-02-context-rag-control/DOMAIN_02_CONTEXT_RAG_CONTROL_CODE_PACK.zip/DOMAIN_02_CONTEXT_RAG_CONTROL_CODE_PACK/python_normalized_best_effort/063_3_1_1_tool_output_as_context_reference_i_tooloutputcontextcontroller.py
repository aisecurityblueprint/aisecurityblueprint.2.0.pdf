class ToolOutputContextController:
    """
    Controls how tool outputs are integrated into context.
    No tool output enters context without validation.
    """
    def __init__(self):
        self.tool_registry = {}
        self.tool_output_log = []
        self.max_tool_output_tokens = 12800 # 10% of context window
        self.token_estimator = TokenEstimator()

    def register_tool(self, tool_name: str, config: dict):
        self.tool_registry[tool_name] = {
            "name": tool_name, "trust_level": config.get("trust_level", "medium"),
            "allowed_output_types": config.get("allowed_output_types", ["json", "text"]),
            "max_output_tokens": config.get("max_output_tokens", 4000),
            "required_sanitization": config.get("required_sanitization", True),
            "allowed_domains": config.get("allowed_domains", []),
            "blocked_patterns": config.get("blocked_patterns", []),
            "schema_validation": config.get("schema_validation", True),
            "expected_schema": config.get("expected_schema"),
        }

    def validate_tool_output(self, tool_name: str, output: dict, tool_metadata: dict) -> dict:
        if tool_name not in self.tool_registry:
            return {"action": "block", "reason": f"unregistered_tool: {tool_name}"}
            tool_config = self.tool_registry[tool_name]
            validation_results = []
            output_type = output.get("type", "text")
            if output_type not in tool_config["allowed_output_types"]:
                return {"action": "block", "reason": f"disallowed_output_type: {output_type}"}
                if tool_config["schema_validation"] and tool_config.get("expected_schema"):
                    schema_valid = self._validate_schema(output, tool_config["expected_schema"])
                    validation_results.append({"check": "schema_validation", "passed": schema_valid})
                    if not schema_valid:
                        return {"action": "block", "reason": "schema_validation_failed", "validation_results": validation_results}
                        output_content = json.dumps(output) if isinstance(output, dict) else str(output)
                        output_tokens = self.token_estimator.count(output_content)
                        if output_tokens > tool_config["max_output_tokens"]:
                            return {"action": "truncate", "reason": "output_too_large",
                                "original_tokens": output_tokens, "max_tokens": tool_config["max_output_tokens"],
                                "truncated_output": self._truncate_output(output, tool_config["max_output_tokens"])}
                                if tool_config["required_sanitization"]:
                                sanitization_result = self._sanitize_output(output, tool_config)
                                validation_results.append(sanitization_result)
                                if sanitization_result["issues_found"]:
                                output = sanitization_result["sanitized_output"]
                                for pattern in tool_config["blocked_patterns"]:
                                if re.search(pattern, output_content, re.IGNORECASE):
                                    return {"action": "block", "reason": f"blocked_pattern_detected: {pattern}", "validation_results": validation_results}
                                if "url" in output_content.lower():
                                urls = re.findall(r'https?://[^\s<>"]+|www\.[^\s<>"]+', output_content)
                                for url in urls:
                                domain = urlparse(url).netloc
                                if tool_config["allowed_domains"] and domain not in tool_config["allowed_domains"]:
                                    return {"action": "block", "reason": f"disallowed_domain: {domain}", "validation_results": validation_results}
                                self.tool_output_log.append({
                                    "timestamp": datetime.now(timezone.utc).isoformat(), "tool_name": tool_name,
                                    "output_tokens": output_tokens, "trust_level": tool_config["trust_level"],
                                    "validation_passed": True, "validation_results": validation_results
                                })
                                return {"action": "accept", "tool_name": tool_name, "trust_level": tool_config["trust_level"],
                                    "output_tokens": output_tokens, "sanitized_output": output, "validation_results": validation_results}

    def _validate_schema(self, output: dict, expected_schema: dict) -> bool:
                                    if not isinstance(output, dict):
                                        return False
                                    for key, expected_type in expected_schema.items():
                                    if key not in output:
                                        return False
                                    if expected_type == "string" and not isinstance(output[key], str):
                                        return False
                                    if expected_type == "number" and not isinstance(output[key], (int, float)):
                                        return False
                                    if expected_type == "list" and not isinstance(output[key], list):
                                        return False
                                    if expected_type == "dict" and not isinstance(output[key], dict):
                                        return False
                                        return True

    def _sanitize_output(self, output: dict, tool_config: dict) -> dict:
                                    issues_found = []
                                    if isinstance(output, dict):
                                    sanitized = {}
                                    for key, value in output.items():
                                    if isinstance(value, str):
                                    sanitized_value, issues = self._sanitize_string(value)
                                    sanitized[key] = sanitized_value
                                    issues_found.extend(issues)
                                else:
                                    sanitized[key] = value
                                else:
                                    sanitized, issues_found = self._sanitize_string(str(output))
                                    return {"sanitized_output": sanitized, "issues_found": issues_found, "issue_count": len(issues_found)}

    def _sanitize_string(self, text: str) -> tuple:
                                    issues = []
                                    sanitized = text
                                    override_patterns = [
                                        (r"(?i)ignore\s+(all\s+)?(previous|system)\s+instructions", "instruction_override"),
                                        (r"(?i)execute\s+\w+\(\)", "function_call_injection"),
                                        (r"(?i)admin_reset|delete_all|drop_table", "destructive_command"),
                                    ]
                                    for pattern, issue_type in override_patterns:
                                    if re.search(pattern, sanitized):
                                    sanitized = re.sub(pattern, "[REMOVED]", sanitized)
                                    issues.append({"type": issue_type, "pattern": pattern})
                                    return sanitized, issues

    def _truncate_output(self, output: dict, max_tokens: int) -> dict:
                                    if isinstance(output, dict):
                                    output_str = json.dumps(output)
                                    words = output_str.split()
                                    if len(words) <= max_tokens:
                                        return output
                                    truncated_str = " ".join(words[:max_tokens]) + "... [TRUNCATED]"
                                    return {"truncated": True, "preview": truncated_str[:500]}
                                else:
                                    words = str(output).split()
                                    return " ".join(words[:max_tokens]) + "... [TRUNCATED]"
