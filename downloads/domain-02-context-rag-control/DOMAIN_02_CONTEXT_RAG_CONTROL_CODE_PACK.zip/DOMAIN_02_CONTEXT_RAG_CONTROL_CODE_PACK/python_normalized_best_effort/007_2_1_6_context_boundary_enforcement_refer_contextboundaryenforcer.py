class ContextBoundaryEnforcer:
    """
    Ensures context boundaries are respected. No source may exceed
    its dynamic budget or invade another source's segment.
    """
    def __init__(self, budget_manager: DynamicContextBudgetManager, segmenter: ContextSegmenter):
        self.budget = budget_manager
        self.segmenter = segmenter
        self.assembly_log = []

    def validate_and_assemble(self, sources: dict) -> dict:
        validation_results = []
        segments = []
        blocked_sources = []

        if "system" in sources:
            sys_content = sources["system"]["content"]
            allocation = self.budget.allocate("system", sys_content)
            if allocation["action"] == "reject":
                return {"action": "block", "reason": "system_budget_rejected", "details": allocation}
                segments.append(("system", allocation["content"], {}))
                validation_results.append({"source": "system", "action": allocation["action"], "tokens_allocated": allocation.get("allocated_tokens", 0)})

                if "rag" in sources:
                    for i, rag_item in enumerate(sources["rag"]):
                        rag_content = rag_item["content"]
                        rag_metadata = rag_item.get("metadata", {})
                        trust_level = rag_metadata.get("trust", "low")
                        if trust_level == "blocked":
                            blocked_sources.append({"type": "rag", "index": i, "reason": "trust_level_blocked"})
                            continue
                            allocation = self.budget.allocate("rag", rag_content)
                            if allocation["action"] == "reject":
                                validation_results.append({"source": f"rag[{i}]", "action": "reject", "reason": allocation["reason"]})
                                continue
                                source_type = "rag_trusted" if trust_level == "high" else "rag_untrusted"
                                segments.append((source_type, allocation["content"], rag_metadata))
                                validation_results.append({"source": f"rag[{i}]", "action": allocation["action"], "tokens_allocated": allocation.get("allocated_tokens", 0), "trust_level": trust_level})

                                if "user" in sources:
                                    user_content = sources["user"]["content"]
                                    allocation = self.budget.allocate("user", user_content)
                                    if allocation["action"] != "reject":
                                        segments.append(("user", allocation["content"], {}))
                                        validation_results.append({"source": "user", "action": allocation["action"], "tokens_allocated": allocation.get("allocated_tokens", 0)})

                                        if "tools" in sources:
                                            for i, tool_item in enumerate(sources["tools"]):
                                                tool_content = tool_item["content"]
                                                tool_metadata = tool_item.get("metadata", {})
                                                allocation = self.budget.allocate("tools", tool_content)
                                                if allocation["action"] == "reject":
                                                    validation_results.append({"source": f"tool[{i}]", "action": "reject", "reason": allocation["reason"]})
                                                    continue
                                                    segments.append(("tool", allocation["content"], tool_metadata))
                                                    validation_results.append({"source": f"tool[{i}]", "action": allocation["action"], "tokens_allocated": allocation.get("allocated_tokens", 0)})

                                                    assembled = self.segmenter.assemble_context(segments)
                                                    log_entry = {
                                                        "timestamp": datetime.now(timezone.utc).isoformat(),
                                                        "budget_status": self.budget.get_budget_status(),
                                                        "validation_results": validation_results,
                                                        "blocked_sources": blocked_sources,
                                                        "segment_count": assembled["segment_count"],
                                                        "total_tokens": assembled["total_tokens"],
                                                        "warnings": assembled["warnings"],
                                                    }
                                                    self.assembly_log.append(log_entry)
                                                    return {
                                                        "action": "assembled",
                                                        "context": assembled["context"],
                                                        "validation": validation_results,
                                                        "blocked": blocked_sources,
                                                        "warnings": assembled["warnings"],
                                                        "budget": self.budget.get_budget_status(),
                                                        "assembly_id": hashlib.sha256(json.dumps(log_entry, sort_keys=True).encode()).hexdigest(),
                                                    }
