class StructuredDataContextValidator:
    """
    Validates structured data (JSON, DB results) before context inclusion.
    """
    def __init__(self):
        self.max_rows = 100
        self.max_columns = 20
        self.max_nesting_depth = 5
        self.max_string_length = 10000

    def validate_structured_data(self, data: any, schema_info: dict = None) -> dict:
        validation_results = []
        if isinstance(data, list):
            validation_results.append(self._validate_list(data))
        elif isinstance(data, dict):
            validation_results.append(self._validate_dict(data))
        elif isinstance(data, str):
            validation_results.append(self._validate_string(data))
            validation_results.append(self._check_size(data))
            validation_results.append(self._check_nesting_depth(data))
            if schema_info:
                validation_results.append(self._check_against_schema(data, schema_info))
                failed = [r for r in validation_results if not r.get("passed", True)]
                return {"action": "block" if failed else "accept",
                    "validation_results": validation_results, "failed_checks": [r["check"] for r in failed],
                    "all_passed": len(failed) == 0}

    def _validate_list(self, data: list) -> dict:
                    if len(data) > self.max_rows:
                        return {"check": "row_limit", "passed": False, "rows": len(data),
                            "max_allowed": self.max_rows, "reason": f"too_many_rows: {len(data)} > {self.max_rows}"}
                            if data and isinstance(data[0], dict):
                            columns = len(data[0].keys())
                            if columns > self.max_columns:
                                return {"check": "column_limit", "passed": False, "columns": columns,
                                    "max_allowed": self.max_columns, "reason": f"too_many_columns: {columns} > {self.max_columns}"}
                                    return {"check": "list_validation", "passed": True}

    def _validate_dict(self, data: dict) -> dict:
                                    if len(data.keys()) > self.max_columns:
                                        return {"check": "dict_size", "passed": False, "keys": len(data.keys()),
                                            "max_allowed": self.max_columns, "reason": f"too_many_keys: {len(data.keys())} > {self.max_columns}"}
                                            return {"check": "dict_validation", "passed": True}

    def _validate_string(self, data: str) -> dict:
                                            if len(data) > self.max_string_length:
                                                return {"check": "string_length", "passed": False, "length": len(data),
                                                    "max_allowed": self.max_string_length, "reason": f"string_too_long: {len(data)} > {self.max_string_length}"}
                                                    return {"check": "string_validation", "passed": True}

    def _check_size(self, data: any) -> dict:
                                                    size_bytes = len(json.dumps(data).encode('utf-8')) if not isinstance(data, str) else len(data.encode('utf-8'))
                                                    max_bytes = 5 * 1024 * 1024
                                                    return {"check": "size_limit", "passed": size_bytes <= max_bytes, "size_bytes": size_bytes,
                                                        "max_allowed_bytes": max_bytes, "reason": "ok" if size_bytes <= max_bytes else f"data_too_large: {size_bytes} bytes"}

    def _check_nesting_depth(self, data: any, current_depth: int = 0) -> dict:
                                                        if current_depth > self.max_nesting_depth:
                                                            return {"check": "nesting_depth", "passed": False, "depth": current_depth,
                                                                "max_allowed": self.max_nesting_depth, "reason": f"max_nesting_depth_exceeded: {current_depth} > {self.max_nesting_depth}"}
                                                                if isinstance(data, dict):
                                                                max_child_depth = current_depth
                                                                for value in data.values():
                                                                child_check = self._check_nesting_depth(value, current_depth + 1)
                                                                if not child_check["passed"]:
                                                                    return child_check
                                                                max_child_depth = max(max_child_depth, child_check.get("depth", current_depth))
                                                                return {"check": "nesting_depth", "passed": True, "depth": max_child_depth}
                                                                if isinstance(data, list):
                                                                max_child_depth = current_depth
                                                                for item in data[:10]:
                                                                child_check = self._check_nesting_depth(item, current_depth + 1)
                                                                if not child_check["passed"]:
                                                                    return child_check
                                                                max_child_depth = max(max_child_depth, child_check.get("depth", current_depth))
                                                                return {"check": "nesting_depth", "passed": True, "depth": max_child_depth}
                                                                return {"check": "nesting_depth", "passed": True, "depth": current_depth}

    def _check_against_schema(self, data: any, schema_info: dict) -> dict:
                                                                # Simplified schema validation
                                                                return {"check": "schema_validation", "passed": True}
