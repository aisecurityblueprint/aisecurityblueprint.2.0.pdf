Policy layering note. Unsupported numeric projections, such as synthesized financial figures not found in any source document, are blocked earlier by the NumericClaimVerifier inside the hallucination boundary control (§2.6.6). Consequently, the append_disclaimer action of the no_future_projections_without_disclaimer policy only applies to forward-looking statements that are explicitly sourced or otherwise not flagged as hallucinations by the numeric verifier. In practice: a purely synthesized number with no source is blocked as high severity; a projected number explicitly attributed to a source document receives a disclaimer as medium severity. This layered design ensures that high-confidence hallucinations are never downgraded to a disclaimer, while still allowing disclaimers on legitimate forward-looking statements. The behavior is enforced by the max() decision flow in the DomainRiskIntegrator (§4.2.2) and by the hallucination-risk thresholds.

class OutputPolicyEnforcer:
    def __init__(self):
        self.email_domain_allowlist = set()
        self.policies = {
            "no_sensitive_data": {
                "patterns": [
                    r"\b\d{3}-\d{2}-\d{4}\b",
                    r"\b(?:\d[ -]?){15,16}\b",
                    r"(?i)(password|secret|token|api[_-]?key)\s*[:=]\s*\S+",
                ],
                "action": "redact", "severity": "critical",
            },
            "no_future_projections_without_disclaimer": {
                "patterns": [
                    r"(?i)(revenue|profit|growth|earnings|margin|sales|cost|headcount|valuation)\s+(will|is\s+projected\s+to|is\s+forecast(ed)?\s+to|is\s+estimated\s+to)\s+\w+",
                    r"(?i)(projected|forecasted|estimated)\s+(revenue|profit|growth|earnings|q[1-4]|fy\d{2})",
                ],
                "action": "append_disclaimer", "severity": "medium",
            },
        }

    def _redact_emails(self, text: str) -> tuple:
        redacted_count = 0
    def _sub(match):
        nonlocal redacted_count
        domain = match.group(0).rsplit("@", 1)[-1].lower()
        if domain in self.email_domain_allowlist:
            return match.group(0)
            redacted_count += 1
            return "[REDACTED_EMAIL]"
            pattern = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"
            return re.sub(pattern, _sub, text), redacted_count

    def enforce(self, output: str, context_metadata: dict) -> dict:
        violations, modified_output = [], output
        modified_output, redacted_emails = self._redact_emails(modified_output)
        if redacted_emails:
            violations.append({"policy": "email_redaction", "count": redacted_emails, "action": "redact_conditional"})
            for name, policy in self.policies.items():
                for pattern in policy["patterns"]:
                    if re.search(pattern, modified_output):
                        violations.append({"policy": name, "severity": policy["severity"], "action": policy["action"]})
                        if policy["action"] == "redact":
                            modified_output = re.sub(pattern, "[REDACTED]", modified_output)
                        elif policy["action"] == "append_disclaimer":
                            modified_output += "\n\nNote: Forward-looking estimates require explicit source attribution and should not be treated as verified facts."
                            return {"output": modified_output, "violations": violations, "action": "block" if any(v.get("severity") == "critical" for v in violations) else "flag" if violations else "allow"}
