class ToolTrustScorer:
    """
    Assigns and maintains trust scores for external tools.
    """
    def __init__(self):
        self.tool_scores = {}
        self.trust_history = []
        self.base_trust_scores = {
            "internal_api": 1.0, "verified_partner_api": 0.85, "internal_database": 0.95,
            "third_party_api": 0.60, "public_api": 0.40, "user_defined_tool": 0.50, "unknown_tool": 0.20,
        }

    def get_trust_score(self, tool_name: str, tool_type: str) -> dict:
        if tool_name in self.tool_scores:
            score = self.tool_scores[tool_name]
        else:
            score = self.base_trust_scores.get(tool_type, 0.30)
            self.tool_scores[tool_name] = score
            return {"tool_name": tool_name, "tool_type": tool_type, "trust_score": score,
                "trust_level": "high" if score >= 0.80 else "medium" if score >= 0.50 else "low"}

    def update_trust_score(self, tool_name: str, event: str, details: dict = None):
                if tool_name not in self.tool_scores:
                self.tool_scores[tool_name] = 0.50
                current_score = self.tool_scores[tool_name]
                adjustments = {
                    "successful_call": +0.01, "failed_call": -0.02, "timeout": -0.05,
                    "returned_error": -0.03, "schema_violation": -0.10, "injection_detected": -0.20,
                    "sensitive_data_returned": -0.15, "consistently_reliable": +0.05, "security_incident": -0.30,
                }
                adjustment = adjustments.get(event, 0.0)
                new_score = max(0.0, min(1.0, current_score + adjustment))
                self.tool_scores[tool_name] = new_score
                self.trust_history.append({
                    "timestamp": datetime.now(timezone.utc).isoformat(), "tool_name": tool_name,
                    "event": event, "previous_score": current_score, "adjustment": adjustment,
                    "new_score": new_score, "details": details or {}
                })

    def get_tool_trust_report(self) -> dict:
                tools_report = []
                for tool_name, score in self.tool_scores.items():
                recent_events = [e for e in self.trust_history[-50:] if e["tool_name"] == tool_name]
                tools_report.append({
                    "tool_name": tool_name, "current_score": score,
                    "trust_level": "high" if score >= 0.80 else "medium" if score >= 0.50 else "low",
                    "recent_events": len(recent_events), "trend": self._compute_trend(recent_events)
                })
                return {
                    "total_tools": len(tools_report),
                    "high_trust": sum(1 for t in tools_report if t["trust_level"] == "high"),
                    "medium_trust": sum(1 for t in tools_report if t["trust_level"] == "medium"),
                    "low_trust": sum(1 for t in tools_report if t["trust_level"] == "low"),
                    "tools": tools_report
                }

    def _compute_trend(self, events: list) -> str:
                if len(events) < 2:
                    return "stable"
                first_score = events[0]["new_score"]
                last_score = events[-1]["new_score"]
                diff = last_score - first_score
                if diff > 0.05:
                    return "improving"
                elif diff < -0.05:
                    return "declining"
                else:
                    return "stable"
