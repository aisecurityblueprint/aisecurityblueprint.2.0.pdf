class ConfidenceScorer:
    """
    Assigns confidence scores to statements in context.
    """
    def __init__(self):
        self.confidence_factors = {
            "source_authority": 0.35,
            "cross_verification": 0.25,
            "temporal_freshness": 0.15,
            "internal_consistency": 0.15,
            "numerical_precision": 0.10,
        }

    def score_context(self, context_docs: list, validation_results: dict) -> dict:
        scored_statements = []
        for doc in context_docs:
            content = doc.get("content", "")
            statements = self._extract_significant_statements(content)
            for statement in statements:
                score = self._compute_confidence(statement, doc, validation_results)
                scored_statements.append(score)
                if not scored_statements:
                    avg_confidence = 0.5
                else:
                    avg_confidence = sum(s["confidence"] for s in scored_statements) / len(scored_statements)
                    return {
                        "total_statements": len(scored_statements),
                        "average_confidence": avg_confidence,
                        "high_confidence_count": sum(1 for s in scored_statements if s["confidence"] >= 0.80),
                        "medium_confidence_count": sum(1 for s in scored_statements if 0.50 <= s["confidence"] < 0.80),
                        "low_confidence_count": sum(1 for s in scored_statements if s["confidence"] < 0.50),
                        "statements": scored_statements[:10],
                        "context_confidence_level": "high" if avg_confidence >= 0.80 else "medium" if avg_confidence >= 0.60 else "low"
                    }

    def _extract_significant_statements(self, content: str) -> list:
        sentences = re.split(r'[.!?]+', content)
        significant = []
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 30 and not sentence.startswith("http"):
                significant.append(sentence)
                return significant[:20]

    def _compute_confidence(self, statement: str, doc: dict, validation_results: dict) -> dict:
        factors = {}
        source = doc.get("source", "unknown")
        authority_scores = {
            "official_policy": 0.95, "regulatory_filing": 1.0, "internal_wiki": 0.75,
            "verified_partner": 0.70, "government_public": 0.65, "public_verified": 0.50,
            "public_unverified": 0.20, "web_crawl": 0.10
        }
        factors["source_authority"] = authority_scores.get(source, 0.15)
        factors["cross_verification"] = 0.5 # Placeholder
        last_updated = doc.get("last_updated")
        if last_updated:
            try:
                days_old = (datetime.now(timezone.utc) - parse_ts(last_updated)).days
                factors["temporal_freshness"] = max(0.1, 1.0 - days_old / 365)
            except (ValueError, TypeError):
                factors["temporal_freshness"] = 0.3
            else:
                factors["temporal_freshness"] = 0.2
                factors["internal_consistency"] = 0.7
                numbers = re.findall(r'\b\d+(?:\.\d+)?\b', statement)
                factors["numerical_precision"] = 0.8 if numbers else 0.5
                confidence = sum(factors[f] * w for f, w in self.confidence_factors.items())
                return {"statement": statement[:150], "confidence": confidence, "factors": factors, "source": source, "doc_id": doc.get("doc_id")}
