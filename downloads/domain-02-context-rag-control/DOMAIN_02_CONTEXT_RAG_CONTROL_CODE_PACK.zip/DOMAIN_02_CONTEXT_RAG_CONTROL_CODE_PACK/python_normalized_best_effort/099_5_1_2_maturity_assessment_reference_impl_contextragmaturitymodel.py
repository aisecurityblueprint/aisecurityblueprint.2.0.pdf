class ContextRAGMaturityModel:
    """
    Maturity model for Context & RAG Control.
    Assesses maturity across 15 dimensions.
    """
    def __init__(self):
        self.levels = {
            1: {"name": "Initial --- Basic Retrieval",
                "description": "Basic retrieval without security controls",
                "characteristics": {
                    "context_construction": "No token budget, no segmentation",
                    "retrieval_pipeline": "Direct query, no security filters",
                    "data_trust": "No source trust classification",
                    "injection_detection": "No RAG injection detection",
                    "context_integrity": "No consistency validation",
                    "ground_truth": "No truth anchoring",
                    "amplification_control": "No amplification control",
                    "memory_governance": "No memory validation or expiration",
                    "tool_integration": "No tool output validation",
                    "isolation": "No tenant isolation",
                    "observability": "No context logging",
                    "testing": "No RAG security tests",
                    "risk_scoring": "No context risk scoring",
                    "advanced_threats": "No advanced threat protection",
                    "continuous_validation": "No continuous validation",
                }},
                2: {"name": "Managed --- Controlled Retrieval",
                    "description": "Basic retrieval controls and source validation",
                    "characteristics": {
                        "context_construction": " token budget, no segmentation",
                        "retrieval_pipeline": "Basic clearance filters, Top-K",
                        "data_trust": "Binary trust (trusted/untrusted)",
                        "injection_detection": "Basic injection pattern detection",
                        "context_integrity": "Basic structure verification",
                        "ground_truth": "Manually defined authoritative sources",
                        "amplification_control": "Manual amplification alert",
                        "memory_governance": " TTL for persistent memory",
                        "tool_integration": "Schema validation for tools",
                        "isolation": "Manual tenant isolation",
                        "observability": "Basic retrieval logging",
                        "testing": "Manual injection tests",
                        "risk_scoring": "Simple rule-based risk score",
                        "advanced_threats": "Basic anomaly monitoring",
                        "continuous_validation": "Periodic manual review",
                    }},
                    3: {"name": "Defined --- Context-Aware Security",
                        "description": "Context-aware security with standardised controls",
                        "characteristics": {
                            "context_construction": "Per-source budget, XML segmentation, prioritisation",
                            "retrieval_pipeline": "Multi-criteria filters, query validation, source ranking",
                            "data_trust": "Multi-level trust with provenance",
                            "injection_detection": "Multi-vector detection (direct, indirect, cross-chunk)",
                            "context_integrity": "Cross-source validation, contradiction detection",
                            "ground_truth": "Fact validation layers, multi-source verification",
                            "amplification_control": "Automatic amplification detection",
                            "memory_governance": "Content validation, expiration policies",
                            "tool_integration": "Dynamic trust scoring for tools",
                            "isolation": "Context partitioning, cross-tenant detection",
                            "observability": "Provenance tracking, source attribution",
                            "testing": "Automated red team, programmatic injection tests",
                            "risk_scoring": "Multi-factor risk scoring model",
                            "advanced_threats": "Embedding poisoning, semantic collision detection",
                            "continuous_validation": "Automated drift detection",
                        }},
                        4: {"name": "Quantitatively Managed --- High Assurance RAG",
                            "description": "Quantitative metrics, ML detection, threat intelligence",
                            "characteristics": {
                                "context_construction": "Adaptive budget, ML-optimised composition",
                                "retrieval_pipeline": "ML-based relevance scoring, anomaly detection",
                                "data_trust": "Dynamic trust scoring with feedback loop",
                                "injection_detection": "ML-based injection detection, behavioural analysis",
                                "context_integrity": "ML-based contradiction detection, lexical analysis",
                                "ground_truth": "Automated fact verification, confidence scoring",
                                "amplification_control": "Predictive amplification risk modelling",
                                "memory_governance": "Adaptive TTL, behavioural poisoning detection",
                                "tool_integration": "Real-time trust scoring with threat intelligence",
                                "isolation": "Automated isolation testing, predictive leakage detection",
                                "observability": "Full forensic reconstruction, chain of custody",
                                "testing": "Continuous red teaming, adversarial training",
                                "risk_scoring": "ML-calibrated risk weights, ROC-validated thresholds",
                                "advanced_threats": "Proactive threat hunting, zero-day detection",
                                "continuous_validation": "Automated regression testing, metric dashboards",
                            }},
                            5: {"name": "Optimising --- Continuous Validation",
                                "description": "Continuous learning, automated fuzzing, real-time verification",
                                "characteristics": {
                                    "context_construction": "Self-optimising composition, real-time adaptation",
                                    "retrieval_pipeline": "Adversarial-hardened retrieval, formal verification",
                                    "data_trust": "Zero-trust data model, continuous re-verification",
                                    "injection_detection": "Adversarial-trained detectors, formal guarantees",
                                    "context_integrity": "Real-time semantic verification, formal consistency proofs",
                                    "ground_truth": "Automated knowledge verification, real-time fact checking",
                                    "amplification_control": "Real-time amplification prevention, formal bounds",
                                    "memory_governance": "Self-healing memory, cryptographic verification",
                                    "tool_integration": "Formally verified tool integration, proof-carrying outputs",
                                    "isolation": "Hardware-enforced isolation, formal non-interference proofs",
                                    "observability": "Real-time audit, immutable distributed ledger",
                                    "testing": "Continuous fuzzing, genetic adversarial generation",
                                    "risk_scoring": "Real-time Bayesian risk updating, causal inference",
                                    "advanced_threats": "Predictive defence, automated threat neutralisation",
                                    "continuous_validation": "Self-validating systems, automated compliance",
                                }},
                            }
                            self.dimensions = [
                                "context_construction", "retrieval_pipeline", "data_trust",
                                "injection_detection", "context_integrity", "ground_truth",
                                "amplification_control", "memory_governance", "tool_integration",
                                "isolation", "observability", "testing", "risk_scoring",
                                "advanced_threats", "continuous_validation"
                            ]

    def assess_maturity(self, assessment: dict) -> dict:
                            dimension_scores = {}
                            for dimension in self.dimensions:
                            level = assessment.get(dimension, 1)
                            dimension_scores[dimension] = {
                                "level": level, "level_name": self.levels[level]["name"],
                                "characteristic": self.levels[level]["characteristics"][dimension]
                            }
                            levels = [s["level"] for s in dimension_scores.values()]
                            overall_level = min(levels)
                            avg_level = sum(levels) / len(levels)
                            gaps = [
                                {"dimension": dim, "current_level": scores["level"],
                                    "target_level": overall_level + 1, "gap": (overall_level + 1) - scores["level"]}
                                    for dim, scores in dimension_scores.items() if scores["level"] <= overall_level
                                ]
                                return {
                                    "overall_maturity_level": overall_level,
                                    "overall_maturity_name": self.levels[overall_level]["name"],
                                    "average_level": avg_level, "dimension_scores": dimension_scores,
                                    "gaps": gaps, "gap_count": len(gaps),
                                    "recommendation": self._generate_recommendation(overall_level, gaps),
                                    "assessment_timestamp": datetime.now(timezone.utc).isoformat()
                                }

    def _generate_recommendation(self, current_level: int, gaps: list) -> str:
                                if current_level == 1:
                                    return "Prioritise basic controls: token budget, clearance filters, source classification"
                                elif current_level == 2:
                                    return f"Focus on {len(gaps)} dimensions with gap: implement segmentation, multi-vector detection, cross-source validation"
                                elif current_level == 3:
                                    return "Advance to ML-based detection, adaptive thresholds, and threat intelligence integration"
                                elif current_level == 4:
                                    return "Path to level 5: formal verification, continuous fuzzing, self-validating systems"
                                else:
                                    return "Maintain excellence with continuous validation and improvement of existing processes"

    def get_level_requirements(self, target_level: int) -> dict:
                                if target_level not in self.levels:
                                    return {"error": "invalid_level"}
                                    return {
                                        "target_level": target_level, "target_name": self.levels[target_level]["name"],
                                        "requirements": self.levels[target_level]["characteristics"],
                                        "prerequisites": [self.levels[l]["name"] for l in range(1, target_level)]
                                    }
