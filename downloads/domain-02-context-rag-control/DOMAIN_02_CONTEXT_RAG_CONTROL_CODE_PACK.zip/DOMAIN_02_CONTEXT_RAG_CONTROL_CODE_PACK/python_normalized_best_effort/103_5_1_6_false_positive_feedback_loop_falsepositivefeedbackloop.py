class FalsePositiveFeedbackLoop:
    def __init__(self):
        self.verdicts = []

    def record_verdict(self, event_id: str, detector: str, original_action: str, analyst_verdict: str, analyst_id: str, rule_pack_version: str) -> dict:
        entry = {"event_id": event_id, "detector": detector, "original_action": original_action, "verdict": analyst_verdict, "analyst_id": analyst_id, "rule_pack_version": rule_pack_version, "timestamp": datetime.now(timezone.utc).isoformat()}
        self.verdicts.append(entry)
        return entry

    def precision_report(self, window_days: int = 30) -> dict:
        cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)
        recent = [v for v in self.verdicts if parse_ts(v["timestamp"]) >= cutoff]
        by_detector = {}
        for v in recent:
            d = by_detector.setdefault(v["detector"], {"tp": 0, "fp": 0})
            if v["verdict"] == "true_positive": d["tp"] += 1
        elif v["verdict"] == "false_positive": d["fp"] += 1
        report = {}
        for detector, c in by_detector.items():
            total = c["tp"] + c["fp"]
            precision = c["tp"] / total if total else None
            report[detector] = {**c, "precision": precision, "recalibration_recommended": precision is not None and precision < 0.95}
            return {"window_days": window_days, "verdicts_reviewed": len(recent), "by_detector": report}
