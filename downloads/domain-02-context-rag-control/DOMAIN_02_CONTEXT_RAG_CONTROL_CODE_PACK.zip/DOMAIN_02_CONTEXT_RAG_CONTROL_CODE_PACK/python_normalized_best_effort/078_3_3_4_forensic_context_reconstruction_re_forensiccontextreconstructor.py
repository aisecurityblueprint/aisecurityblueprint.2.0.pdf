class ForensicContextReconstructor:
    """
    Reconstructs the exact context presented to the model for auditing and investigation.
    """
    def __init__(self):
        self.context_snapshots = {}

    def snapshot_context(self, context_id: str, context: str, metadata: dict) -> str:
        snapshot_id = hashlib.sha256(f"{context_id}:{datetime.now(timezone.utc).isoformat()}:{context[:100]}".encode()).hexdigest()[:16]
        self.context_snapshots[snapshot_id] = {
            "snapshot_id": snapshot_id, "context_id": context_id,
            "timestamp": datetime.now(timezone.utc).isoformat(), "context": context,
            "context_hash": hashlib.sha256(context.encode()).hexdigest(),
            "context_length": len(context), "context_tokens": TokenEstimator().count(context),
            "metadata": metadata, "chain_hash": self._compute_snapshot_chain(snapshot_id, context)
        }
        return snapshot_id

    def _compute_snapshot_chain(self, snapshot_id: str, context: str) -> str:
        prev_snapshots = list(self.context_snapshots.keys())
        prev_hash = self.context_snapshots[prev_snapshots[-1]]["chain_hash"] if prev_snapshots else "genesis"
        return hashlib.sha256(f"{prev_hash}:{snapshot_id}:{hashlib.sha256(context.encode()).hexdigest()}".encode()).hexdigest()

    def reconstruct_context(self, snapshot_id: str) -> dict:
        if snapshot_id not in self.context_snapshots:
            return {"error": "snapshot_not_found"}
            snapshot = self.context_snapshots[snapshot_id]
            current_hash = hashlib.sha256(snapshot["context"].encode()).hexdigest()
            integrity_verified = (current_hash == snapshot["context_hash"])
            return {
                "snapshot_id": snapshot_id, "context_id": snapshot["context_id"],
                "timestamp": snapshot["timestamp"], "context": snapshot["context"],
                "integrity_verified": integrity_verified, "context_length": snapshot["context_length"],
                "context_tokens": snapshot["context_tokens"], "metadata": snapshot["metadata"],
                "tampered": not integrity_verified
            }

    def diff_contexts(self, snapshot_id_a: str, snapshot_id_b: str) -> dict:
        ctx_a = self.context_snapshots.get(snapshot_id_a, {}).get("context", "")
        ctx_b = self.context_snapshots.get(snapshot_id_b, {}).get("context", "")
        if not ctx_a or not ctx_b:
            return {"error": "snapshot_not_found"}
            tokens_a = set(ctx_a.split())
            tokens_b = set(ctx_b.split())
            added = tokens_b - tokens_a
            removed = tokens_a - tokens_b
            common = tokens_a & tokens_b
            return {
                "snapshot_a": snapshot_id_a, "snapshot_b": snapshot_id_b,
                "tokens_a": len(tokens_a), "tokens_b": len(tokens_b),
                "tokens_added": len(added), "tokens_removed": len(removed),
                "tokens_common": len(common),
                "similarity": len(common) / max(len(tokens_a | tokens_b), 1),
                "significant_change": len(added) + len(removed) > len(common) * 0.3
            }
