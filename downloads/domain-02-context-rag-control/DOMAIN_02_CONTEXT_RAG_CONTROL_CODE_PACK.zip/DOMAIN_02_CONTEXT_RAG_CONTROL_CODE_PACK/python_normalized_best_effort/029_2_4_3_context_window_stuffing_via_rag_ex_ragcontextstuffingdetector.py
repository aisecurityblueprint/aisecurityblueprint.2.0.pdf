import math

class RAGContextStuffingDetector:
    def __init__(self, token_estimator=None):
        self.token_estimator = token_estimator or TokenEstimator()
        self.max_rag_tokens = 70400
        self.max_chunks = 20
        self.min_chunk_diversity = 0.3
        self.stuffing_patterns = {
            "repetition": r"(.{50,})\1{2,}",
            "low_entropy": r"^([\w\s]{0,20})\1{10,}$",
            "filler_text": r"(lorem ipsum|placeholder|sample text|test data|dummy content)",
        }

    def detect(self, rag_chunks: list) -> dict:
        findings = []
        if len(rag_chunks) > self.max_chunks:
            findings.append({"type": "excessive_chunks", "chunk_count": len(rag_chunks), "max_allowed": self.max_chunks, "severity": "high"})
            total_tokens = sum(self.token_estimator.count(c.get("content", "")) for c in rag_chunks)
            if total_tokens > self.max_rag_tokens:
                findings.append({"type": "excessive_tokens", "total_tokens": total_tokens, "max_allowed": self.max_rag_tokens, "utilization": total_tokens / self.max_rag_tokens, "severity": "high" if total_tokens > self.max_rag_tokens * 1.5 else "medium"})
                diversity = self._compute_diversity(rag_chunks)
                if diversity < self.min_chunk_diversity:
                    findings.append({"type": "low_diversity", "diversity_score": diversity, "threshold": self.min_chunk_diversity, "severity": "medium"})
                    for i, chunk in enumerate(rag_chunks):
                        content = chunk.get("content", "")
                        for name, pattern in self.stuffing_patterns.items():
                            if re.search(pattern, content, re.IGNORECASE):
                                findings.append({"type": f"stuffing_pattern_{name}", "chunk_index": i, "chunk_source": chunk.get("source", "unknown"), "severity": "high" if name == "low_entropy" else "medium"})
                                avg_entropy = self._compute_avg_entropy(rag_chunks)
                                if avg_entropy < 2.5:
                                    findings.append({"type": "low_entropy", "average_entropy": avg_entropy, "severity": "high"})
                                    return {"detected": len(findings) > 0, "findings": findings, "finding_count": len(findings), "total_chunks": len(rag_chunks), "total_tokens": total_tokens, "diversity_score": diversity, "average_entropy": avg_entropy, "action": "block" if any(f.get("severity") == "high" for f in findings) else "flag" if findings else "accept"}

    def _compute_diversity(self, chunks: list) -> float:
        if len(chunks) <= 1:
            return 1.0
            contents = [c.get("content", "") for c in chunks]
            unique_chars = set("".join(contents))
            total_chars = sum(len(c) for c in contents)
            char_diversity = len(unique_chars) / max(total_chars, 1)
            all_bigrams = []
            for content in contents:
                words = content.split()
                all_bigrams.extend(f"{words[i]}_{words[i+1]}" for i in range(len(words)-1))
                bigram_diversity = len(set(all_bigrams)) / max(len(all_bigrams), 1)
                return (char_diversity + bigram_diversity) / 2

    def _compute_avg_entropy(self, chunks: list) -> float:
        entropies = []
        for chunk in chunks:
            content = chunk.get("content", "")
            if not content:
                entropies.append(0.0)
                continue
                char_counts = {}
                for ch in content:
                    char_counts[ch] = char_counts.get(ch, 0) + 1
                    n = len(content)
                    entropy = -sum((count / n) * math.log2(count / n) for count in char_counts.values())
                    entropies.append(entropy)
                    return sum(entropies) / len(entropies) if entropies else 0.0
