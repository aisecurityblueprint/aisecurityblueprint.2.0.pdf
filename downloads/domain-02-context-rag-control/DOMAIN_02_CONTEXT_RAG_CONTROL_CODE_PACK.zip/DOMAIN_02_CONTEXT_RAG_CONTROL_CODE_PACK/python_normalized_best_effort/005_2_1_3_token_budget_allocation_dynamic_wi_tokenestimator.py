class TokenEstimator:
    """
    Single source of truth for token estimation across Domain 02 - Context & RAG Control.
    Preferred mode: a real tokenizer (tiktoken / HF AutoTokenizer).
    Fallback mode: word count multiplied by a conservative BPE factor.
    """
    BPE_FACTOR = 1.3

    def __init__(self, tokenizer=None):
        self.tokenizer = tokenizer

    def count(self, text: str) -> int:
        if not text:
            return 0
            if self.tokenizer is not None:
                return len(self.tokenizer.encode(text))
                return int(len(text.split()) * self.BPE_FACTOR) + 1

class DynamicContextBudgetManager:
    """
    Token allocation with guaranteed minimums and a flexible pool.

    SECURITY INVARIANTS:
        1. The system reserve is untouchable.
        2. Hard caps still exist per source to prevent stuffing.
        3. Flexible pool is granted in priority order.
        """
    def __init__(self, total_tokens: int = 128000, token_estimator=None):
        self.total = total_tokens
        self.estimator = token_estimator or TokenEstimator()
        self.policy = {
            "system": {"min": 0.08, "cap": 0.40},
            "rag": {"min": 0.20, "cap": 0.55},
            "user": {"min": 0.08, "cap": 0.25},
            "tools": {"min": 0.04, "cap": 0.20},
        }
        self.priority_order = ["system", "rag", "user", "tools"]
        self.min_tokens = {s: int(self.total * p["min"]) for s, p in self.policy.items()}
        self.cap_tokens = {s: int(self.total * p["cap"]) for s, p in self.policy.items()}
        self.consumed = {s: 0 for s in self.policy}

    def _reserved_for_others(self, source: str) -> int:
        return sum(
            max(self.min_tokens[s] - self.consumed[s], 0)
            for s in self.policy if s != source
        )

    def allocate(self, source: str, content: str) -> dict:
        if source not in self.policy:
            return {"action": "reject", "reason": f"unknown_source: {source}"}
            tokens = self.estimator.count(content)

            if self.consumed[source] + tokens > self.cap_tokens[source]:
                available_cap = self.cap_tokens[source] - self.consumed[source]
                if available_cap <= 0:
                    return {"action": "reject", "reason": f"hard_cap_exhausted: {source}"}
                    tokens = available_cap
                    content = self._truncate(content, tokens)
                    action = "truncate"
                else:
                    action = "accept"

                    free_pool = self.total - sum(self.consumed.values()) - self._reserved_for_others(source)
                    if tokens > free_pool:
                        if free_pool <= 0:
                            return {"action": "reject", "reason": f"pool_exhausted_minimums_protected: {source}"}
                            tokens = free_pool
                            content = self._truncate(content, tokens)
                            action = "truncate"

                            self.consumed[source] += tokens
                            return {"action": action, "allocated_tokens": tokens, "content": content}

    def _truncate(self, content: str, max_tokens: int) -> str:
        words = content.split()
        keep = max(int(max_tokens / TokenEstimator.BPE_FACTOR) - 1, 0)
        return " ".join(words[:keep]) + "... [TRUNCATED]"
    def get_budget_status(self) -> dict:
        used = sum(self.consumed.values())
        return {
            "total_tokens": self.total,
            "consumed": used,
            "remaining": self.total - used,
            "by_source": {
                s: {
                    "min_reserved": self.min_tokens[s],
                    "hard_cap": self.cap_tokens[s],
                    "consumed": self.consumed[s],
                    "utilization_vs_cap": self.consumed[s] / self.cap_tokens[s] if self.cap_tokens[s] else 0,
                }
                for s in self.policy
            },
        }
