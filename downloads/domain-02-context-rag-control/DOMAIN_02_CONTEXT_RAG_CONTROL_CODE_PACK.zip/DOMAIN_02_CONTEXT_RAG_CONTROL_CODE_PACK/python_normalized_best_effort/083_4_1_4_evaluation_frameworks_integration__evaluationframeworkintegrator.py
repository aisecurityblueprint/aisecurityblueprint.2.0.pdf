class EvaluationFrameworkIntegrator:
    """
    Integrates metrics from external RAG evaluation frameworks like Ragas, DeepEval, TruLens.
    """
    def __init__(self):
        self.supported_frameworks = {
            "ragas": ["faithfulness", "answer_relevancy", "context_precision", "context_recall", "context_relevancy"],
            "deepeval": ["faithfulness", "answer_relevancy", "contextual_relevancy", "contextual_precision", "contextual_recall"],
            "trulens": ["groundedness", "relevance", "context_relevance"],
        }
        self.evaluation_results = []

    def evaluate_with_framework(self, framework: str, metrics: list, rag_system, test_data: list) -> dict:
        if framework not in self.supported_frameworks:
            return {"error": f"unsupported_framework: {framework}"}
            available_metrics = self.supported_frameworks[framework]
            selected_metrics = [m for m in metrics if m in available_metrics]
            if not selected_metrics:
                return {"error": "no_valid_metrics_selected"}
                metric_scores = {metric: [] for metric in selected_metrics}
                for test_item in test_data:
                    query = test_item.get("query", "")
                    expected_answer = test_item.get("expected_answer", "")
                    context_docs = test_item.get("context_docs", [])
                    result = rag_system.query(query)
                    generated_answer = result.get("answer", "")
                    retrieved_docs = result.get("documents", [])
                    for metric in selected_metrics:
                        score = self._compute_metric(framework, metric, query, generated_answer,
                            expected_answer, context_docs, retrieved_docs)
                            metric_scores[metric].append(score)
                            aggregated = {}
                            for metric, scores in metric_scores.items():
                            if scores:
                            aggregated[metric] = {"mean": sum(scores) / len(scores), "min": min(scores), "max": max(scores), "count": len(scores)}
                            overall_score = sum(aggregated[m]["mean"] for m in aggregated) / max(len(aggregated), 1)
                            eval_result = {
                                "framework": framework, "metrics_evaluated": selected_metrics,
                                "test_items": len(test_data), "metric_scores": aggregated,
                                "overall_score": overall_score, "evaluation_timestamp": datetime.now(timezone.utc).isoformat()
                            }
                            self.evaluation_results.append(eval_result)
                            return eval_result

    def _compute_metric(self, framework: str, metric: str, query: str, generated: str,
        expected: str, context_docs: list, retrieved_docs: list) -> float:
        metric_computers = {
            "faithfulness": lambda: self._compute_faithfulness(generated, retrieved_docs),
            "answer_relevancy": lambda: self._compute_answer_relevancy(generated, query),
            "context_precision": lambda: self._compute_context_precision(retrieved_docs, expected),
            "context_recall": lambda: self._compute_context_recall(retrieved_docs, context_docs),
            "context_relevancy": lambda: self._compute_context_relevancy(retrieved_docs, query),
            "groundedness": lambda: self._compute_groundedness(generated, retrieved_docs),
        }
        return metric_computers.get(metric, lambda: 0.5)()

    def _compute_faithfulness(self, generated: str, docs: list) -> float:
        all_doc_text = " ".join([d.get("content", "") for d in docs]).lower()
        gen_words = set(generated.lower().split())
        doc_words = set(all_doc_text.split())
        if not gen_words:
            return 0.0
            return len(gen_words & doc_words) / len(gen_words)

    def _compute_answer_relevancy(self, generated: str, query: str) -> float:
        query_words = set(query.lower().split())
        gen_words = set(generated.lower().split())
        if not query_words:
            return 0.0
            return len(query_words & gen_words) / len(query_words)

    def _compute_context_precision(self, retrieved: list, expected: str) -> float:
        expected_words = set(expected.lower().split())
        all_retrieved = " ".join([d.get("content", "") for d in retrieved]).lower()
        retrieved_words = set(all_retrieved.split())
        if not retrieved_words:
            return 0.0
            return len(expected_words & retrieved_words) / len(retrieved_words)

    def _compute_context_recall(self, retrieved: list, context_docs: list) -> float:
        all_context = " ".join([d.get("content", "") for d in context_docs]).lower()
        all_retrieved = " ".join([d.get("content", "") for d in retrieved]).lower()
        context_words = set(all_context.split())
        retrieved_words = set(all_retrieved.split())
        if not context_words:
            return 0.0
            return len(context_words & retrieved_words) / len(context_words)

    def _compute_context_relevancy(self, retrieved: list, query: str) -> float:
        query_words = set(query.lower().split())
        all_retrieved = " ".join([d.get("content", "") for d in retrieved]).lower()
        retrieved_words = set(all_retrieved.split())
        if not retrieved_words:
            return 0.0
            return len(query_words & retrieved_words) / len(retrieved_words)

    def _compute_groundedness(self, generated: str, docs: list) -> float:
        return self._compute_faithfulness(generated, docs)
