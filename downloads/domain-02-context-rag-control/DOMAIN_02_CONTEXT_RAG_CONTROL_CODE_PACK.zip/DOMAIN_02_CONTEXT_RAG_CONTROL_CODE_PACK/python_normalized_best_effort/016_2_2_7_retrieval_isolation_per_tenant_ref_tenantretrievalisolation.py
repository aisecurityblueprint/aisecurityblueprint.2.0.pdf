class TenantRetrievalIsolation:
    """
    Ensures each tenant only accesses its own documents.
    Implements Vector DB level isolation.
    """
    def __init__(self):
        self.tenant_namespaces = {}
        self.cross_tenant_access_log = []

    def build_tenant_filter(self, tenant_id: str) -> dict:
        return {
            "must": [{"term": {"tenant_id": tenant_id}}, {"term": {"status": "active"}}],
            "must_not": [{"term": {"classification": "restricted"}}, {"exists": {"field": "deleted_at"}}]
        }

    def validate_tenant_access(self, doc: dict, tenant_id: str) -> bool:
        doc_tenant = doc.get("tenant_id")
        if doc_tenant != tenant_id:
            self.cross_tenant_access_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "attempted_tenant": tenant_id,
                "document_tenant": doc_tenant,
                "doc_id": doc.get("doc_id", "unknown"),
                "action": "blocked"
            })
            return False
            return True

    def get_isolation_status(self) -> dict:
        return {
            "active_tenants": len(self.tenant_namespaces),
            "cross_tenant_attempts": len(self.cross_tenant_access_log),
            "recent_attempts": [a for a in self.cross_tenant_access_log
                if (datetime.now(timezone.utc) - parse_ts(a["timestamp"])).seconds < 3600]
            }
