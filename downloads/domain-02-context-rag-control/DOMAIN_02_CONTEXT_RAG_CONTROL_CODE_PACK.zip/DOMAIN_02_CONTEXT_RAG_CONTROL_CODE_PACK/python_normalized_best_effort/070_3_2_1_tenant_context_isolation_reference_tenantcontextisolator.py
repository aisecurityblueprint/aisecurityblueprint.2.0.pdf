class TenantContextIsolator:
    """
    Ensures strict isolation between contexts of different tenants.
    """
    def __init__(self):
        self.tenant_contexts = {}
        self.cross_tenant_access_log = []
        self.isolation_violations = []

    def create_tenant_context(self, tenant_id: str, user_id: str, session_id: str) -> dict:
        context_id = hashlib.sha256(f"{tenant_id}:{user_id}:{session_id}:{datetime.now(timezone.utc).isoformat()}".encode()).hexdigest()[:16]
        if tenant_id not in self.tenant_contexts:
            self.tenant_contexts[tenant_id] = {}
            self.tenant_contexts[tenant_id][context_id] = {
                "context_id": context_id, "tenant_id": tenant_id, "user_id": user_id,
                "session_id": session_id, "created_at": datetime.now(timezone.utc).isoformat(),
                "status": "active", "context_data": {}, "access_log": []
            }
            return {"context_id": context_id, "tenant_id": tenant_id, "status": "created"}

    def validate_context_access(self, context_id: str, tenant_id: str, user_id: str) -> dict:
        context = None
        context_tenant = None
        for tid, contexts in self.tenant_contexts.items():
            if context_id in contexts:
                context = contexts[context_id]
                context_tenant = tid
                break
                if not context:
                    return {"allowed": False, "reason": "context_not_found"}
                    if context_tenant != tenant_id:
                        self._log_cross_tenant_attempt(tenant_id, context_tenant, context_id, user_id)
                        return {"allowed": False, "reason": "cross_tenant_access_blocked",
                            "attempted_tenant": tenant_id, "actual_tenant": context_tenant}
                            if context.get("user_id") and context["user_id"] != user_id:
                                return {"allowed": False, "reason": "cross_user_access_blocked",
                                    "attempted_user": user_id, "context_user": context["user_id"]}
                                    context["access_log"].append({"timestamp": datetime.now(timezone.utc).isoformat(), "user_id": user_id, "action": "accessed"})
                                    return {"allowed": True, "context": context}

    def _log_cross_tenant_attempt(self, attempted_tenant: str, actual_tenant: str, context_id: str, user_id: str):
                                    violation = {
                                        "timestamp": datetime.now(timezone.utc).isoformat(), "attempted_tenant": attempted_tenant,
                                        "actual_tenant": actual_tenant, "context_id": context_id, "user_id": user_id, "action": "blocked"
                                    }
                                    self.cross_tenant_access_log.append(violation)
                                    self.isolation_violations.append(violation)

    def get_isolation_status(self, tenant_id: str = None) -> dict:
                                    if tenant_id:
                                    active_contexts = len(self.tenant_contexts.get(tenant_id, {}))
                                    violations = len([v for v in self.isolation_violations if v["attempted_tenant"] == tenant_id or v["actual_tenant"] == tenant_id])
                                    return {"tenant_id": tenant_id, "active_contexts": active_contexts, "violations": violations}
                                    return {
                                        "total_tenants": len(self.tenant_contexts),
                                        "total_active_contexts": sum(len(contexts) for contexts in self.tenant_contexts.values()),
                                        "total_violations": len(self.isolation_violations),
                                        "tenants": {tid: len(contexts) for tid, contexts in self.tenant_contexts.items()}
                                    }

    def destroy_tenant_context(self, context_id: str, tenant_id: str) -> dict:
                                    if tenant_id in self.tenant_contexts and context_id in self.tenant_contexts[tenant_id]:
                                    context = self.tenant_contexts[tenant_id][context_id]
                                    context["status"] = "destroyed"
                                    context["destroyed_at"] = datetime.now(timezone.utc).isoformat()
                                    del self.tenant_contexts[tenant_id][context_id]
                                    return {"action": "destroyed", "context_id": context_id, "tenant_id": tenant_id}
                                    return {"action": "not_found"}
