class EmbeddingPoisoningDetector:
    """
    Detects embedding poisoning — when an adversary manipulates
    embedding vectors to alter retrieval results.
    """
    def __init__(self):
        self.embedding_baselines = {}
        self.poisoning_indicators = {
            "vector_magnitude_anomaly": self._check_magnitude_anomaly,
            "cosine_distance_anomaly": self._check_cosine_anomaly,
            "cluster_isolation": self._check_cluster_isolation,
            "nearest_neighbor_shift": self._check_neighbor_shift,
        }

    def establish_baseline(self, collection_name: str, embeddings: list, metadata: list):
        magnitudes = [self._vector_magnitude(e) for e in embeddings]
        centroid = self._compute_centroid(embeddings)
        self.embedding_baselines[collection_name] = {
            "avg_magnitude": sum(magnitudes) / len(magnitudes),
            "std_magnitude": self._std(magnitudes), "centroid": centroid,
            "embedding_dim": len(embeddings[0]) if embeddings else 0,
            "sample_count": len(embeddings), "established_at": datetime.now(timezone.utc).isoformat()
        }

    def detect_poisoning(self, collection_name: str, new_embeddings: list, new_metadata: list) -> dict:
        if collection_name not in self.embedding_baselines:
            return {"error": "baseline_not_established"}
            baseline = self.embedding_baselines[collection_name]
            findings = []
            for i, (embedding, metadata_item) in enumerate(zip(new_embeddings, new_metadata)):
                embedding_findings = []
                for indicator_name, indicator_func in self.poisoning_indicators.items():
                    result = indicator_func(embedding, baseline)
                    if result["anomaly_detected"]:
                        embedding_findings.append(result)
                        if embedding_findings:
                            findings.append({"embedding_index": i, "metadata": metadata_item,
                                "findings": embedding_findings, "total_anomalies": len(embedding_findings)})
                                return {
                                    "poisoning_detected": len(findings) > 0, "total_embeddings_checked": len(new_embeddings),
                                    "suspicious_embeddings": len(findings), "suspicious_ratio": len(findings) / max(len(new_embeddings), 1),
                                    "findings": findings, "action": "block" if len(findings) > len(new_embeddings) * 0.1 else "quarantine" if findings else "accept"
                                }

    def _vector_magnitude(self, vector: list) -> float:
        return (sum(x*x for x in vector)) ** 0.5

    def _compute_centroid(self, embeddings: list) -> list:
                                if not embeddings:
                                    return []
                                dim = len(embeddings[0])
                                centroid = [0.0] * dim
                                for e in embeddings:
                                for j in range(dim):
                                centroid[j] += e[j]
                                return [c / len(embeddings) for c in centroid]

    def _std(self, values: list) -> float:
                                if len(values) < 2:
                                    return 0.0
                                mean = sum(values) / len(values)
                                variance = sum((v - mean)**2 for v in values) / len(values)
                                return variance ** 0.5

    def _check_magnitude_anomaly(self, embedding: list, baseline: dict) -> dict:
                                magnitude = self._vector_magnitude(embedding)
                                avg = baseline["avg_magnitude"]
                                std = baseline["std_magnitude"]
                                z_score = abs(magnitude - avg) / max(std, 0.001)
                                anomaly = z_score > 3.0
                                return {"indicator": "vector_magnitude_anomaly", "anomaly_detected": anomaly,
                                    "magnitude": magnitude, "baseline_avg": avg, "z_score": z_score,
                                    "severity": "high" if z_score > 5.0 else "medium" if anomaly else "none"}

    def _check_cosine_anomaly(self, embedding: list, baseline: dict) -> dict:
                                    centroid = baseline["centroid"]
                                    dot = sum(a*b for a,b in zip(embedding, centroid))
                                    norm_emb = self._vector_magnitude(embedding)
                                    norm_cent = self._vector_magnitude(centroid)
                                    if norm_emb == 0 or norm_cent == 0:
                                    cosine_sim = 0
                                else:
                                    cosine_sim = dot / (norm_emb * norm_cent)
                                    anomaly = cosine_sim < 0.7
                                    return {"indicator": "cosine_distance_anomaly", "anomaly_detected": anomaly,
                                        "cosine_similarity": cosine_sim,
                                        "severity": "high" if cosine_sim < 0.5 else "medium" if anomaly else "none"}

    def _check_cluster_isolation(self, embedding: list, baseline: dict) -> dict:
                                        # Simplified — in practice would use clustering algorithms
                                        return {"indicator": "cluster_isolation", "anomaly_detected": False, "severity": "none"}

    def _check_neighbor_shift(self, embedding: list, baseline: dict) -> dict:
        return {"indicator": "nearest_neighbor_shift", "anomaly_detected": False, "severity": "none"}
