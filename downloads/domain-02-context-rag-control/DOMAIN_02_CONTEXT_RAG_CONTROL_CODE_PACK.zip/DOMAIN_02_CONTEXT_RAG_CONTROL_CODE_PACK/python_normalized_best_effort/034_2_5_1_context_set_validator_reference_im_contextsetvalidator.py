class ContextSetValidator:
    """
    Validates the complete context set before presenting to the model.
    Checks structural integrity, cross-source consistency, and safety.
    """
    def __init__(self):
        self.validation_checks = [
            "structure", "source_consistency", "density",
            "contradiction", "completeness", "safety"
        ]

    def validate_context_set(self, context: str, segments: dict, metadata: dict) -> dict:
        results = {}
        results["structure"] = self._validate_structure(segments)
        results["source_consistency"] = self._validate_source_consistency(segments)
        results["density"] = self._validate_instruction_density(context, segments)
        results["contradiction"] = self._detect_contradictions(segments)
        results["completeness"] = self._validate_completeness(segments, metadata)
        results["safety"] = self._validate_context_safety(context)
        failed_checks = [k for k, v in results.items() if v.get("status") == "failed"]
        warning_checks = [k for k, v in results.items() if v.get("status") == "warning"]
        if failed_checks:
            action = "block"
        elif warning_checks:
            action = "flag"
        else:
            action = "accept"
            return {
                "action": action, "status": "failed" if failed_checks else "warning" if warning_checks else "passed",
                "checks": results, "failed_checks": failed_checks, "warning_checks": warning_checks,
                "validation_id": hashlib.sha256(f"{datetime.now(timezone.utc).isoformat()}:{context[:100]}".encode()).hexdigest()[:16]
            }

    def _validate_structure(self, segments: dict) -> dict:
        issues = []
        if "system" not in segments or not segments.get("system"):
            issues.append("missing_system_instructions")
            expected_order = ["system", "rag", "user", "tools"]
            actual_order = list(segments.keys())
            order_issues = []
            for expected in expected_order:
                if expected in actual_order:
                    expected_pos = expected_order.index(expected)
                    actual_pos = actual_order.index(expected)
                    if abs(expected_pos - actual_pos) > 1:
                        order_issues.append(f"{expected}_out_of_position")
                        if order_issues:
                            issues.extend(order_issues)
                            return {"status": "failed" if "missing_system_instructions" in issues else "warning" if issues else "passed", "issues": issues}

    def _validate_source_consistency(self, segments: dict) -> dict:
        issues = []
        sources = set()
        for segment_type, content in segments.items():
            if isinstance(content, list):
                for item in content:
                    if isinstance(item, dict) and "source" in item:
                        sources.add((segment_type, item["source"]))
                    elif isinstance(content, dict) and "source" in content:
                        sources.add((segment_type, content["source"]))
                        dangerous_combinations = [
                            ("internal_policy", "web_crawl"), ("official_policy", "public_unverified"),
                            ("regulatory_filing", "user_upload"),
                        ]
                        source_types = [s[1] for s in sources]
                        for trusted, untrusted in dangerous_combinations:
                            if trusted in source_types and untrusted in source_types:
                                issues.append(f"dangerous_combination: {trusted}+{untrusted}")
                                return {"status": "warning" if issues else "passed", "issues": issues, "total_sources": len(sources)}

    def _validate_instruction_density(self, context: str, segments: dict) -> dict:
        tokens = context.split()
        total_tokens = len(tokens)
        instruction_keywords = ["must", "shall", "required", "prohibited", "mandatory", "policy", "rule", "guideline", "restriction", "limitation"]
        instruction_count = sum(1 for t in tokens if t.lower() in instruction_keywords)
        density = instruction_count / max(total_tokens, 1)
        if density < 0.02:
            status = "warning"
            reason = "low_instruction_density"
        elif density > 0.15:
            status = "warning"
            reason = "high_instruction_density"
        else:
            status = "passed"
            reason = None
            return {"status": status, "reason": reason, "density": density, "total_tokens": total_tokens, "instruction_tokens": instruction_count}

    def _detect_contradictions(self, segments: dict) -> dict:
        contradictions = []
        statements = self._extract_statements(segments)
        for i, s1 in enumerate(statements):
            for j, s2 in enumerate(statements):
                if i >= j:
                    continue
                    if self._are_contradictory(s1["text"], s2["text"]):
                        contradictions.append({
                            "statement_a": s1["text"][:100], "statement_b": s2["text"][:100],
                            "source_a": s1["source"], "source_b": s2["source"], "confidence": 0.7
                        })
                        return {"status": "warning" if contradictions else "passed", "contradictions": contradictions, "contradiction_count": len(contradictions)}

    def _validate_completeness(self, segments: dict, metadata: dict) -> dict:
        issues = []
        expected_segments = metadata.get("expected_segments", ["system", "user"])
        for expected in expected_segments:
            if expected not in segments or not segments.get(expected):
                issues.append(f"missing_segment: {expected}")
                for segment_type in ["system"]:
                    if segment_type in segments:
                        content = segments[segment_type]
                        if isinstance(content, str) and len(content.strip()) < 10:
                            issues.append(f"empty_critical_segment: {segment_type}")
                            return {"status": "failed" if any("missing" in i for i in issues) else "warning" if issues else "passed", "issues": issues}

    def _validate_context_safety(self, context: str) -> dict:
        safety_issues = []
        ignore_patterns = [
            r"(?i)(ignore|disregard|forget)\s+(all\s+)?(previous|above|system)\s+(instructions|policies|rules)",
            r"(?i)(bypass|override)\s+(security|safety|policy|restriction)",
            r"(?i)(do\s+not\s+follow)\s+(any|the)\s+(instructions|rules|policies)",
        ]
        for pattern in ignore_patterns:
            if re.search(pattern, context):
                safety_issues.append({"type": "instruction_override", "pattern": pattern})
                sensitive_patterns = [
                    r'\b\d{3}-\d{2}-\d{4}\b', r'\b\d{16}\b',
                    r'(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*\S+',
                ]
                for pattern in sensitive_patterns:
                    matches = re.findall(pattern, context)
                    if matches:
                        safety_issues.append({"type": "sensitive_data", "pattern": pattern, "match_count": len(matches)})
                        return {"status": "failed" if safety_issues else "passed", "issues": safety_issues, "issue_count": len(safety_issues)}

    def _extract_statements(self, segments: dict) -> list:
        statements = []
        for segment_type, content in segments.items():
            if isinstance(content, str):
                sentences = re.split(r'[.!?]+', content)
                for sentence in sentences:
                    sentence = sentence.strip()
                    if len(sentence) > 20:
                        statements.append({"text": sentence, "source": segment_type})
                    elif isinstance(content, list):
                        for item in content:
                            if isinstance(item, dict) and "content" in item:
                                sentences = re.split(r'[.!?]+', item["content"])
                                for sentence in sentences:
                                    sentence = sentence.strip()
                                    if len(sentence) > 20:
                                        statements.append({"text": sentence, "source": f"{segment_type}:{item.get('source', 'unknown')}"})
                                        return statements

    def _are_contradictory(self, text1: str, text2: str) -> bool:
        negation_patterns = [
            (r"\bnot\b", r"\bis\b"), (r"\bnever\b", r"\balways\b"),
            (r"\bcannot\b", r"\bcan\b"), (r"\bprohibited\b", r"\ballowed\b"),
            (r"\brestricted\b", r"\bpermitted\b"),
        ]
        for neg_pattern, pos_pattern in negation_patterns:
            if re.search(neg_pattern, text1) and re.search(pos_pattern, text2):
                return True
                if re.search(neg_pattern, text2) and re.search(pos_pattern, text1):
                    return True
                    return False
