class RulePackManager:
 def __init__(self):
 self.packs = {}
 self.active_version = None

 def register_pack(self, version: str, rules: dict, changelog: str) -> dict:
 pack_hash = hashlib.sha256(json.dumps(rules, sort_keys=True).encode()).hexdigest()
 self.packs[version] = {"version": version, "rules": rules, "pack_hash": pack_hash, "changelog": changelog, "registered_at": datetime.now(timezone.utc).isoformat(), "status": "registered"}
 return {"version": version, "pack_hash": pack_hash}
 def activate(self, version: str, approved_by: str) -> dict:
 if version not in self.packs:
 return {"action": "reject", "reason": "unknown_version"}
 previous = self.active_version
 self.active_version = version
 self.packs[version]["status"] = "active"
 self.packs[version]["activated_by"] = approved_by
 self.packs[version]["activated_at"] = datetime.now(timezone.utc).isoformat()
 if previous and previous in self.packs:
 self.packs[previous]["status"] = "superseded"
 return {"action": "activated", "version": version, "previous_version": previous, "rollback_available": previous is not None}

 def rollback(self, approved_by: str) -> dict:
 superseded = [v for v, p in self.packs.items() if p["status"] == "superseded"]
 if not superseded:
 return {"action": "reject", "reason": "no_previous_version"}
 return self.activate(superseded[-1], approved_by)
