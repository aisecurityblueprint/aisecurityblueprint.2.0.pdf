class InstructionDensityAnalyzer:
    def __init__(self, normalizer=None):
        self.normalizer = normalizer or InputNormalizer()
        self.system_instruction_keywords = [
            "policy", "rule", "guideline", "restriction", "limitation", "prohibited", "required", "mandatory", "must", "shall", "authorized", "permitted", "allowed", "approved",
            "política", "politica", "regra", "restrição", "restricao", "limitação", "limitacao", "proibido", "obrigatório", "obrigatorio", "deve", "autorizado", "permitido", "aprovado",
            "política", "politica", "regla", "restricción", "restriccion", "limitación", "limitacion", "prohibido", "obligatorio", "debe", "autorizado", "permitido", "aprobado",
        ]
        self.manipulation_keywords = [
            "ignore", "override", "bypass", "circumvent", "disable", "forget", "disregard", "replace", "new instructions", "different rules",
            "ignore", "ignora", "sobrescrever", "burlar", "contornar", "desativar", "esqueça", "esqueca", "desconsidere", "substitua", "novas instruções", "novas instrucoes",
            "ignora", "olvida", "sobrescribe", "elude", "evita", "desactiva", "descarta", "sustituye", "nuevas instrucciones", "reglas diferentes",
        ]

    def analyze_density(self, context_segments: list) -> dict:
        results = []
        for seg in context_segments:
            raw = seg.get("content", "")
            text = self.normalizer.normalize(raw)["normalized"].lower()
            words = text.split()
            if not words:
                continue
            system_hits = sum(1 for kw in self.system_instruction_keywords if kw in text)
            manipulation_hits = sum(1 for kw in self.manipulation_keywords if kw in text)
            results.append({"segment_id": seg.get("id"), "source": seg.get("source"), "instruction_density": system_hits / max(len(words), 1), "manipulation_density": manipulation_hits / max(len(words), 1), "manipulation_hits": manipulation_hits})
        max_manipulation = max((r["manipulation_density"] for r in results), default=0.0)
        return {"segments_analyzed": len(results), "results": results, "max_manipulation_density": max_manipulation, "action": "flag" if max_manipulation > 0.03 else "accept"}
