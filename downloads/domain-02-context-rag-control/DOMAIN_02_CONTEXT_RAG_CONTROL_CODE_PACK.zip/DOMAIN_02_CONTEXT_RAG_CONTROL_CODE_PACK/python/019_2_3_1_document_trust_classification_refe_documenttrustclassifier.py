class DocumentTrustClassifier:
    """
    Classifies documents by trust level based on:
        - Source origin
        - Integrity verification
        - Data freshness
        - Usage history
        """
        TRUST_TIERS = {5: "authoritative", 4: "verified", 3: "trusted", 2: "neutral", 1: "untrusted", 0: "blocked"}
        SOURCE_TRUST_MAP = {
            "official_policy": 5, "internal_audit": 5, "regulatory_filing": 5,
            "internal_wiki": 4, "verified_partner": 3, "partner_feed": 3,
            "government_public": 2, "public_verified": 2,
            "public_unverified": 1, "web_crawl": 1, "user_upload": 0, "unknown": 0,
    }

    def classify(self, doc: dict) -> dict:
        source = doc.get("source", "unknown")
        base_trust = self.SOURCE_TRUST_MAP.get(source, 0)
        adjustments = []
        final_trust = base_trust
        if doc.get("signature_verified", False):
            final_trust = min(5, final_trust + 1)
            adjustments.append({"signal": "signature_verified", "effect": +1})
            if doc.get("hash_verified", False):
                adjustments.append({"signal": "hash_verified", "effect": 0})
                last_updated = doc.get("last_updated")
                if last_updated:
                    try:
                        days_old = (datetime.now(timezone.utc) - parse_ts(last_updated)).days
                        if days_old > 365:
                            final_trust = max(0, final_trust - 1)
                            adjustments.append({"signal": "stale_data", "effect": -1, "days_old": days_old})
                        elif days_old < 30:
                            adjustments.append({"signal": "fresh_data", "effect": 0, "days_old": days_old})
                        except (ValueError, TypeError):
                            adjustments.append({"signal": "invalid_last_updated", "effect": -1})
                            if doc.get("previous_incidents", 0) > 0:
                                final_trust = max(0, final_trust - doc["previous_incidents"])
                                adjustments.append({"signal": "incident_history", "effect": -doc["previous_incidents"]})
                                if doc.get("cross_verified", False):
                                    final_trust = min(5, final_trust + 1)
                                    adjustments.append({"signal": "cross_verified", "effect": +1})
                                    final_trust = max(0, min(5, final_trust))
                                    return {"doc_id": doc.get("doc_id", "unknown"), "source": source,
                                    "base_trust": base_trust, "final_trust": final_trust,
                                    "trust_label": self.TRUST_TIERS[final_trust], "adjustments": adjustments,
                                    "classification_timestamp": datetime.now(timezone.utc).isoformat()}

    def get_trust_threshold(self, user_clearance: int) -> int:
        if user_clearance <= 1:
            return 3
        elif user_clearance <= 3:
            return 2
        else:
            return 1
