class ContextAssemblyLogger:
    """
    Logs every context assembly event with full SHA-256 hash chaining.
    Short display identifiers may be derived from full hashes for correlation,
    but verification always uses the stored full digest. Truncated hashes are
    never used as chain-integrity evidence.
    """
    def __init__(self):
        self.assembly_logs = []
        self.log_retention_days = 90

    def log_assembly_event(self, event_type: str, event_data: dict) -> str:
        event_id = hashlib.sha256(
            f"{event_type}:{datetime.now(timezone.utc).isoformat()}:{json.dumps(event_data, sort_keys=True, default=str)}".encode()
    ).hexdigest()[:16]
    log_entry = {
        "event_id": event_id,
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "data": event_data,
        "chain_hash": self._compute_chain_hash(event_id, event_data),
}
self.assembly_logs.append(log_entry)
return event_id

    def _compute_chain_hash(self, event_id: str, event_data: dict) -> str:
        prev_hash = self.assembly_logs[-1]["chain_hash"] if self.assembly_logs else "genesis"
        # Full SHA-256 — no truncation for verification
        full_hash = hashlib.sha256(
            f"{prev_hash}:{event_id}:{json.dumps(event_data, sort_keys=True, default=str)}".encode()
    ).hexdigest()
    return full_hash

    def get_assembly_trace(self, context_id: str) -> dict:
        trace = [log for log in self.assembly_logs if log["data"].get("context_id") == context_id]
        trace.sort(key=lambda x: x["timestamp"])
        return {
        "context_id": context_id,
        "events": trace,
        "event_count": len(trace),
        "assembly_duration_ms": self._compute_duration(trace),
        "chain_integrity": self._verify_chain(trace),
}

    def _compute_duration(self, trace: list) -> float:
        if len(trace) < 2:
            return 0
        try:
            start = parse_ts(trace[0]["timestamp"])
            end = parse_ts(trace[-1]["timestamp"])
            return (end - start).total_seconds() * 1000
        except (ValueError, TypeError):
            return 0

    def _verify_chain(self, trace: list) -> bool:
        prev_hash = "genesis"
        for event in trace:
            stored_hash = event.get("chain_hash")
            # Recompute expected hash using the same full-length logic
            expected = hashlib.sha256(
                f"{prev_hash}:{event['event_id']}:{json.dumps(event['data'], sort_keys=True, default=str)}".encode()
        ).hexdigest()
        if stored_hash != expected:
            return False
        prev_hash = stored_hash
        return True

    def cleanup_old_logs(self):
        cutoff = datetime.now(timezone.utc) - timedelta(days=self.log_retention_days)
        self.assembly_logs = [log for log in self.assembly_logs if parse_ts(log["timestamp"]) >= cutoff]
