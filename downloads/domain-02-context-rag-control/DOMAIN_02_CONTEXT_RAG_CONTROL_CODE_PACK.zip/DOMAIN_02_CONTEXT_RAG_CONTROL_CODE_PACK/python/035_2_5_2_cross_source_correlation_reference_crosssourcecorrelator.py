class CrossSourceCorrelator:
    """
    Correlates information across different sources in context.
    Detects when low-trust sources contradict high-trust sources.
    """
    def __init__(self):
        self.source_trust = {
            "internal_policy": 5, "official_policy": 5, "regulatory_filing": 5,
            "internal_wiki": 4, "verified_partner": 3,
            "government_public": 2, "public_verified": 2,
            "public_unverified": 1, "web_crawl": 1,
    }

    def correlate(self, docs: list) -> dict:
        topics = self._group_by_topic(docs)
        correlations = []
        conflicts = []
        for topic, topic_docs in topics.items():
            if len(topic_docs) < 2:
                continue
                topic_docs.sort(key=lambda d: self.source_trust.get(d.get("source", "unknown"), 0), reverse=True)
                highest_trust_doc = topic_docs[0]
                for doc in topic_docs[1:]:
                    trust_diff = (self.source_trust.get(highest_trust_doc.get("source", "unknown"), 0) -
                        self.source_trust.get(doc.get("source", "unknown"), 0))
                    correlation = {
                        "topic": topic,
                        "high_trust_doc": {"doc_id": highest_trust_doc.get("doc_id"), "source": highest_trust_doc.get("source"),
                        "trust": self.source_trust.get(highest_trust_doc.get("source", "unknown"), 0)},
                        "low_trust_doc": {"doc_id": doc.get("doc_id"), "source": doc.get("source"),
                        "trust": self.source_trust.get(doc.get("source", "unknown"), 0)},
                        "trust_differential": trust_diff
                }
                if trust_diff >= 3:
                    correlation["action"] = "flag_conflict"
 correlation["warning"] = "High trust source contradicted by low trust source"
 conflicts.append(correlation)
 else:
 correlation["action"] = "accept"
 correlations.append(correlation)
 return {
 "topics_analyzed": len(topics), "correlations": correlations, "conflicts": conflicts,
 "conflict_count": len(conflicts), "action": "flag" if conflicts else "accept"
 }

 def _group_by_topic(self, docs: list) -> dict:
 topics = {}
 topic_keywords = {
 "security": ["security", "authentication", "authorization", "access control", "password"],
 "privacy": ["privacy", "PII", "personal data", "GDPR", "CCPA", "data protection"],
 "finance": ["financial", "revenue", "budget", "expense", "profit", "loss"],
 "compliance": ["compliance", "regulation", "regulatory", "audit", "SOX", "PCI"],
 "operations": ["operation", "process", "procedure", "workflow", "SOP"],
 }
 for doc in docs:
 content = doc.get("content", "").lower()
 for topic, keywords in topic_keywords.items():
 if any(kw in content for kw in keywords):
 if topic not in topics:
 topics[topic] = []
 topics[topic].append(doc)
 break
 return topics
