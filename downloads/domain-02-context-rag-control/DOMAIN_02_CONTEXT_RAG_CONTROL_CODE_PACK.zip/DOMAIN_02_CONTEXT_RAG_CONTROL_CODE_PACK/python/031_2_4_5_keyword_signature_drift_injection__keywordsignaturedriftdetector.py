class KeywordSignatureDriftDetector:
    """
    Detects semantic drift in context.
    When RAG documents gradually shift meaning to manipulate model reasoning.
    """
    def __init__(self):
        self.drift_threshold = 0.40
        self.window_size = 3

    def detect_drift(self, chunks: list) -> dict:
        if len(chunks) < self.window_size:
            return {"detected": False, "reason": "insufficient_chunks"}
        drift_points = []
        for i in range(len(chunks) - self.window_size + 1):
            window = chunks[i:i+self.window_size]
            window_embedding = self._average_embedding(window)
            center_chunk = window[1]
            center_embedding = self._get_embedding(center_chunk)
            drift = self._cosine_distance(center_embedding, window_embedding)
            if drift > self.drift_threshold:
                drift_points.append({
                    "chunk_index": i + 1, "drift_score": drift,
                    "chunk_preview": center_chunk.get("content", "")[:100],
                    "window_context": [c.get("content", "")[:50] for c in window]
            })
            return {
            "detected": len(drift_points) > 0, "drift_points": drift_points,
            "drift_count": len(drift_points), "max_drift": max((d["drift_score"] for d in drift_points), default=0),
            "action": "flag" if len(drift_points) > 0 else "accept"
    }

    def _get_embedding(self, chunk: dict) -> list:
        content = chunk.get("content", "")
        keywords = ["policy", "rule", "restriction", "bypass", "override", "ignore", "change", "new", "different", "instead"]
        return [1.0 if kw in content.lower() else 0.0 for kw in keywords]

    def _average_embedding(self, chunks: list) -> list:
        embeddings = [self._get_embedding(c) for c in chunks]
        if not embeddings:
            return []
        avg = []
        for i in range(len(embeddings[0])):
 avg.append(sum(e[i] for e in embeddings) / len(embeddings))
            return avg

    def _cosine_distance(self, vec1: list, vec2: list) -> float:
        if not vec1 or not vec2 or len(vec1) != len(vec2):
            return 0.0
        dot_product = sum(a*b for a,b in zip(vec1, vec2))
        norm1 = (sum(a*a for a in vec1)) ** 0.5
        norm2 = (sum(b*b for b in vec2)) ** 0.5
        if norm1 == 0 or norm2 == 0:
            return 0.0
        similarity = dot_product / (norm1 * norm2)
        return 1.0 - similarity
