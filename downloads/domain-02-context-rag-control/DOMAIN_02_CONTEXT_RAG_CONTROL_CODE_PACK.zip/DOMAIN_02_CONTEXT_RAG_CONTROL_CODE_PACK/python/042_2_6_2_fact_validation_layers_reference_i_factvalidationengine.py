class FactValidationEngine:
    """
    Multi-layer fact validation engine.
    Each layer adds a level of verification.
    """
    def __init__(self):
        self.validation_layers = [
            "source_authority", "cross_reference", "temporal_validity",
            "logical_consistency", "numerical_precision"
    ]
    self.fact_cache = {}
    self.validation_log = []

    def validate_fact(self, fact: str, source: dict, context: list) -> dict:
        fact_hash = hashlib.sha256(fact.encode()).hexdigest()[:16]
        if fact_hash in self.fact_cache:
            return self.fact_cache[fact_hash]
        layer_results = {}
        confidence_score = 0.0
        # Layer 1: Source Authority
        source_authority = self._check_source_authority(source)
        layer_results["source_authority"] = source_authority
        confidence_score += source_authority["score"] * 0.30
        # Layer 2: Cross-Reference
        cross_ref = self._check_cross_reference(fact, context)
        layer_results["cross_reference"] = cross_ref
        confidence_score += cross_ref["score"] * 0.25
        # Layer 3: Temporal Validity
        temporal = self._check_temporal_validity(fact, source)
        layer_results["temporal_validity"] = temporal
        confidence_score += temporal["score"] * 0.20
        # Layer 4: Logical Consistency
        logical = self._check_logical_consistency(fact, context)
        layer_results["logical_consistency"] = logical
        confidence_score += logical["score"] * 0.15
        # Layer 5: Numerical Precision
        numerical = self._check_numerical_precision(fact)
        layer_results["numerical_precision"] = numerical
        confidence_score += numerical["score"] * 0.10
        if confidence_score >= 0.85:
            confidence_level = "verified"
            action = "accept"
        elif confidence_score >= 0.65:
            confidence_level = "likely_true"
            action = "accept_with_caution"
        elif confidence_score >= 0.45:
            confidence_level = "uncertain"
            action = "flag"
        else:
            confidence_level = "unreliable"
            action = "reject"
            result = {
                "fact_hash": fact_hash, "fact_preview": fact[:200],
                "confidence_score": confidence_score, "confidence_level": confidence_level,
                "action": action, "layer_results": layer_results,
                "source": source.get("source", "unknown"),
                "validation_timestamp": datetime.now(timezone.utc).isoformat()
        }
        self.fact_cache[fact_hash] = result
        self.validation_log.append(result)
        return result

    def _check_source_authority(self, source: dict) -> dict:
        source_type = source.get("doc_type", source.get("source", "unknown"))
        authority_scores = {
            "official_policy": 1.0, "regulatory_filing": 1.0, "internal_audit": 0.95,
            "board_approved": 1.0, "legal_reviewed": 0.95, "internal_wiki": 0.75,
            "verified_partner": 0.70, "government_public": 0.65, "public_verified": 0.50,
            "public_unverified": 0.20, "web_crawl": 0.10, "unknown": 0.05,
    }
    score = authority_scores.get(source_type, 0.10)
    if source.get("signature_verified"):
        score = min(1.0, score + 0.10)
        if source.get("hash_verified"):
            score = min(1.0, score + 0.05)
            if source.get("cross_verified"):
                score = min(1.0, score + 0.10)
                return {"score": score, "source_type": source_type,
                "authority_level": "high" if score >= 0.80 else "medium" if score >= 0.50 else "low"}

    def _check_cross_reference(self, fact: str, context: list) -> dict:
        fact_keywords = set(fact.lower().split()) - {"the", "is", "are", "was", "were", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for"}
        supporting_sources = 0
        contradicting_sources = 0
        total_sources = 0
        for doc in context:
            doc_content = doc.get("content", "").lower()
            if not doc_content:
                continue
                total_sources += 1
                keyword_matches = sum(1 for kw in fact_keywords if kw in doc_content)
                match_ratio = keyword_matches / max(len(fact_keywords), 1)
                if match_ratio > 0.5:
                    if self._supports_fact(fact, doc_content):
                        supporting_sources += 1
                    else:
                        contradicting_sources += 1
                        if total_sources == 0:
                            score = 0.0
                        else:
                            support_ratio = supporting_sources / total_sources
                            contradict_ratio = contradicting_sources / total_sources
                            score = max(0.0, support_ratio - contradict_ratio * 0.5)
                            return {"score": score, "supporting_sources": supporting_sources,
                            "contradicting_sources": contradicting_sources, "total_sources_checked": total_sources}

    def _check_temporal_validity(self, fact: str, source: dict) -> dict:
        last_updated = source.get("last_updated")
        if not last_updated:
            return {"score": 0.5, "reason": "no_temporal_data"}
        try:
            updated_date = parse_ts(last_updated)
            days_old = (datetime.now(timezone.utc) - updated_date).days
            if days_old <= 30:
                score = 1.0
                freshness = "current"
            elif days_old <= 90:
                score = 0.9
                freshness = "recent"
            elif days_old <= 180:
                score = 0.7
                freshness = "aging"
            elif days_old <= 365:
                score = 0.5
                freshness = "old"
            else:
                score = 0.2
                freshness = "outdated"
                return {"score": score, "freshness": freshness, "days_old": days_old, "last_updated": last_updated}
            except (ValueError, TypeError):
                return {"score": 0.3, "reason": "invalid_date"}
    def _check_logical_consistency(self, fact: str, context: list) -> dict:
        fact_lower = fact.lower()
        contradiction_indicators = [
            (r"\balways\b.*\bnever\b", "always_never"),
            (r"\bmust\b.*\bmust\s+not\b", "must_must_not"),
            (r"\ball\b.*\bnone\b", "all_none"),
            (r"\beveryone\b.*\bno\s+one\b", "everyone_no_one"),
    ]
    for pattern, issue_type in contradiction_indicators:
        if re.search(pattern, fact_lower):
            return {"score": 0.0, "reason": f"self_contradiction: {issue_type}", "pattern": pattern}
        logical_score = 0.8
        issues = []
        for doc in context:
            doc_content = doc.get("content", "").lower()
            if self._is_logically_inconsistent(fact_lower, doc_content):
                logical_score -= 0.2
                issues.append({"doc_id": doc.get("doc_id"), "inconsistency_type": "logical_conflict"})
                return {"score": max(0.0, logical_score), "issues": issues, "issue_count": len(issues)}

    def _check_numerical_precision(self, fact: str) -> dict:
        numbers = re.findall(r'\b\d+(?:\.\d+)?\b', fact)
        if not numbers:
            return {"score": 0.8, "reason": "no_numerical_data"}
        issues = []
        for num_str in numbers:
            num = float(num_str)
            if num > 1000 and num % 1000 == 0:
                issues.append({"number": num, "issue": "suspiciously_round"})
                if '.' in num_str and len(num_str.split('.')[1]) > 4:
                    issues.append({"number": num, "issue": "excessive_precision"})
                    score = max(0.3, 0.9 - len(issues) * 0.15)
                    return {"score": score, "numbers_found": len(numbers), "issues": issues}

    def _supports_fact(self, fact: str, content: str) -> bool:
        fact_keywords = set(fact.lower().split()) - {"the", "is", "are", "was", "were", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for"}
        keyword_match = sum(1 for kw in fact_keywords if kw in content)
        keyword_ratio = keyword_match / max(len(fact_keywords), 1)
        negation_words = ["not", "no", "never", "neither", "nor", "cannot", "don't", "doesn't"]
        fact_has_negation = any(nw in fact.lower() for nw in negation_words)
        content_has_negation = any(nw in content for nw in negation_words)
        if fact_has_negation != content_has_negation:
            return False
        return keyword_ratio > 0.4

    def _is_logically_inconsistent(self, fact: str, content: str) -> bool:
        if re.search(r'\bmust\b', fact) and re.search(r'\bmust\s+not\b', content):
            return True
        if re.search(r'\balways\b', fact) and re.search(r'\bnever\b', content):
            return True
        if re.search(r'\brequired\b', fact) and re.search(r'\bnot\s+required\b', content):
            return True
        return False

    def get_validation_stats(self) -> dict:
        if not self.validation_log:
            return {"total_validations": 0}
        scores = [v["confidence_score"] for v in self.validation_log]
        return {
        "total_validations": len(self.validation_log),
        "average_confidence": sum(scores) / len(scores),
        "verified_count": sum(1 for v in self.validation_log if v["confidence_level"] == "verified"),
        "likely_true_count": sum(1 for v in self.validation_log if v["confidence_level"] == "likely_true"),
        "uncertain_count": sum(1 for v in self.validation_log if v["confidence_level"] == "uncertain"),
        "unreliable_count": sum(1 for v in self.validation_log if v["confidence_level"] == "unreliable"),
        "rejection_rate": sum(1 for v in self.validation_log if v["action"] == "reject") / len(self.validation_log)
}
