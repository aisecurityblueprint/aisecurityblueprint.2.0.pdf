class ContextPartitioner:
 def __init__(self):
 self.partitions = {
 "public": {"max_sensitivity": 1, "can_contain": [1]},
 "internal": {"max_sensitivity": 2, "can_contain": [1, 2]},
 "confidential": {"max_sensitivity": 3, "can_contain": [1, 2, 3]},
 "restricted": {"max_sensitivity": 4, "can_contain": [1, 2, 3, 4]},
 "secret": {"max_sensitivity": 5, "can_contain": [1, 2, 3, 4, 5]},
 }

 def partition_context(self, context_items: list) -> dict:
 partitions = {name: [] for name in self.partitions}
 quarantine = []
 for item in context_items:
 sensitivity = item.get("sensitivity_tier", 1)
 placed = False
 for name, config in self.partitions.items():
 if sensitivity in config["can_contain"]:
 partitions[name].append(item)
 placed = True
 break
 if not placed:
 quarantine.append(item)
 return {"partitions": partitions, "quarantine": quarantine, "quarantine_action": "blocked_unclassified" if quarantine else "none", "partition_counts": {name: len(items) for name, items in partitions.items()}, "total_items": len(context_items)}
