class EmbeddingBackend:
 """
 Contract for semantic operations. Implementations may use local
 sentence-transformers or an isolated embedding service behind the
 AI gateway. When absent, deterministic detectors continue to run.
 """
 def embed(self, text: str) -> list:
 raise NotImplementedError

 def cosine_similarity(self, vec_a: list, vec_b: list) -> float:
 dot = sum(a * b for a, b in zip(vec_a, vec_b))
 na = sum(a * a for a in vec_a) ** 0.5
 nb = sum(b * b for b in vec_b) ** 0.5
 if na == 0 or nb == 0:
 return 0.0
 return dot / (na * nb)

class SentenceTransformerBackend(EmbeddingBackend):
 """Local implementation; no data leaves the environment."""
 def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
 from sentence_transformers import SentenceTransformer
 self.model = SentenceTransformer(model_name)

 def embed(self, text: str) -> list:
 return self.model.encode(text, normalize_embeddings=True).tolist()
