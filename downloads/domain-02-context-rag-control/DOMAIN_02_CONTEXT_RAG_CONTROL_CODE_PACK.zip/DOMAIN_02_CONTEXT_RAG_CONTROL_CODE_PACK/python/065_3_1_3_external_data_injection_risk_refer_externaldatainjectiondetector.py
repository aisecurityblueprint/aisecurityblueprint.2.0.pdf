class ExternalDataInjectionDetector:
    """
    Detects injection risks in external data before including in context.
    """
    def __init__(self):
        self.risk_categories = {
            "sql_injection": {
            "patterns": [
            r"(?i)(\bOR\b.*=.*\bOR\b)", r"(?i)(\bUNION\b.*\bSELECT\b)",
            r"(?i)(\bDROP\b\s+\bTABLE\b)", r"(?i)(\bINSERT\b\s+\bINTO\b)",
            r"(?i)(\bDELETE\b\s+\bFROM\b)",
    ], "risk_weight": 0.35
},
    "command_injection": {
    "patterns": [
    r"(?i)(;\s*(rm\s+-rf|del\s+/[FS]|format\s+[CF]))",
    r"(?i)(\|\s*(sh|bash|cmd|powershell))",
    r"(?i)(\bexec\b\s*\(|`[^`]+`)",
], "risk_weight": 0.35
},
    "xss_injection": {
    "patterns": [
    r"(?i)(<script[^>]*>.*?</script>)",
    r"(?i)(javascript\s*:)", r"(?i)(onerror\s*=|onload\s*=|onclick\s*=)",
], "risk_weight": 0.15
},
    "prompt_injection": {
    "patterns": [
    r"(?i)(ignore\s+(previous|system)\s+instructions)",
    r"(?i)(you\s+are\s+now\s+a\s+(different|new))",
    r"(?i)(your\s+new\s+instructions?\s+(is|are))",
], "risk_weight": 0.15
},
}

        def assess_risk(self, data: str, source_info: dict) -> dict:
            risk_signals = {}
            total_risk = 0.0
            for category, config in self.risk_categories.items():
                matches = []
                for pattern in config["patterns"]:
                    found = re.findall(pattern, data)
                    if found:
                        matches.append({"pattern": pattern, "matches": found[:3], "count": len(found)})
                        if matches:
                            category_risk = min(1.0, len(matches) * config["risk_weight"])
 risk_signals[category] = {"detected": True, "matches": matches, "category_risk": category_risk}
                            total_risk += category_risk
                        else:
                            risk_signals[category] = {"detected": False, "category_risk": 0.0}
                            total_risk = min(1.0, total_risk)
                            return {
                        "total_risk_score": total_risk,
                        "risk_level": "critical" if total_risk > 0.70 else "high" if total_risk > 0.50 else "medium" if total_risk > 0.30 else "low",
                        "risk_signals": risk_signals, "source": source_info.get("source", "unknown"),
                        "action": "block" if total_risk > 0.70 else "sanitize" if total_risk > 0.30 else "accept"
                }
