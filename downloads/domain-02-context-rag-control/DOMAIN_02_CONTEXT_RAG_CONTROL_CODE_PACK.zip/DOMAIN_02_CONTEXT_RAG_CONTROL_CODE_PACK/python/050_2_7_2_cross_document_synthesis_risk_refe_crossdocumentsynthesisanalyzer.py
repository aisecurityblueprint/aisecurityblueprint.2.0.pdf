class CrossDocumentSynthesisAnalyzer:
    """
    Analyzes cross-document synthesis risk — when combining information
    from multiple documents creates knowledge no single document should reveal.
    """
    def __init__(self):
        self.synthesis_risk_patterns = [
            (r"(?i)(combining|merging|joining)\s+(data|information|records)", 0.8),
            (r"(?i)(across|spanning)\s+(multiple|several|various)\s+(sources|documents|records)", 0.7),
            (r"(?i)(comprehensive|complete|full)\s+(view|picture|analysis|overview)", 0.6),
            (r"(?i)(compared|contrasted)\s+(with|to|against)", 0.5),
            (r"(?i)(breakdown|drilldown)\s+(by|per|for\s+each)", 0.7),
            (r"(?i)(individual|specific|particular)\s+(customer|user|account|employee)", 0.9),
    ]

    def analyze(self, source_docs: list, output: str) -> dict:
        synthesis_matches = []
        for pattern, base_risk in self.synthesis_risk_patterns:
            matches = re.findall(pattern, output)
            if matches:
                synthesis_matches.append({"pattern": pattern, "base_risk": base_risk,
                    "matches": matches[:3], "match_count": len(matches)})
                if synthesis_matches:
                    risk_score = sum(m["base_risk"] * (1 + m["match_count"] * 0.1) for m in synthesis_matches) / len(synthesis_matches)
                    risk_score = min(1.0, risk_score)
                else:
                    risk_score = 0.0
                    aggregation_risk = self._check_aggregation_risk(source_docs, output)
                    risk_score = max(risk_score, aggregation_risk)
                    discrimination_risk = self._check_discrimination_risk(output)
                    risk_score = max(risk_score, discrimination_risk)
                    return {
                    "synthesis_risk_score": risk_score,
                    "risk_level": "critical" if risk_score > 0.80 else "high" if risk_score > 0.60 else "medium" if risk_score > 0.40 else "low",
                    "synthesis_matches": synthesis_matches, "aggregation_risk": aggregation_risk,
                    "discrimination_risk": discrimination_risk,
                    "action": "block" if risk_score > 0.80 else "escalate" if risk_score > 0.60 else "flag" if risk_score > 0.40 else "accept"
            }

    def _check_aggregation_risk(self, source_docs: list, output: str) -> float:
        output_lower = output.lower()
        aggregation_indicators = ["total", "sum", "average", "mean", "median", "aggregate",
 "combined total", "overall", "across all", "entire", "whole", "cumulative"]
            indicator_count = sum(1 for ind in aggregation_indicators if ind in output_lower)
            if indicator_count >= 3:
                return 0.7
            elif indicator_count >= 1:
                return 0.4
            return 0.0

        def _check_discrimination_risk(self, output: str) -> float:
            output_lower = output.lower()
            discrimination_indicators = ["per customer", "per user", "per account", "by department",
 "by region", "by team", "for each", "individual", "specific",
            "breakdown of", "detailed view of"]
            indicator_count = sum(1 for ind in discrimination_indicators if ind in output_lower)
            if indicator_count >= 3:
                return 0.9
            elif indicator_count >= 1:
                return 0.6
            return 0.0
