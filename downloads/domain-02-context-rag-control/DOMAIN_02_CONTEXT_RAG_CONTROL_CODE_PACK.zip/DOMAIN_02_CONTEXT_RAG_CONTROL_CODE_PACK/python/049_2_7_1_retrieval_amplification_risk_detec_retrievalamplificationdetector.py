class RetrievalAmplificationDetector:
    """
    Detects retrieval amplification — when combining low-sensitivity documents
    produces a high-sensitivity output. Expands on Domain 01 §2.8 with deep lexical analysis.
    """
    def __init__(self):
        self.sensitivity_tiers = {
            "public": 1, "internal": 2, "confidential": 3, "restricted": 4, "secret": 5,
    }
    self.amplification_indicators = [
        "combined", "aggregated", "merged", "synthesized", "cross-referenced",
        "correlated", "joined", "therefore", "implies", "suggests", "indicates",
        "reveals", "exposes", "uncovers", "demonstrates", "projection", "forecast",
        "prediction", "estimate", "trend", "pattern", "correlation", "causation",
 "compared to", "relative to", "in contrast", "whereas", "unlike",
 "differently from", "breakdown", "by department", "by category",
        "per unit", "per customer", "per region",
]
self.restricted_combination_patterns = [
    (["financial", "customer"], 4),
    (["revenue", "individual"], 4),
    (["salary", "department"], 5),
    (["security", "vulnerability"], 4),
    (["legal", "pending"], 4),
    (["strategy", "financial"], 5),
]

    def detect(self, source_documents: list, synthesized_output: str) -> dict:
        source_tiers = [self.sensitivity_tiers.get(doc.get("classification", "public"), 1) for doc in source_documents]
        max_source_tier = max(source_tiers) if source_tiers else 1
        output_analysis = self._analyze_output(synthesized_output, source_documents)
        output_tier = output_analysis.get("inferred_tier", 1)
        amplification_detected = output_tier > max_source_tier
        amplifying_combinations = []
        if amplification_detected:
            amplifying_combinations = self._identify_amplifying_combinations(source_documents, synthesized_output)
            return {
            "amplification_detected": amplification_detected,
            "max_source_tier": max_source_tier,
            "max_source_classification": self._tier_to_classification(max_source_tier),
            "output_tier": output_tier,
            "output_classification": self._tier_to_classification(output_tier),
            "amplification_magnitude": output_tier - max_source_tier,
            "source_documents_count": len(source_documents),
            "source_classifications": [self._tier_to_classification(t) for t in source_tiers],
            "amplifying_combinations": amplifying_combinations,
            "output_indicators": output_analysis.get("indicators_found", []),
            "action": "block" if output_tier > max_source_tier + 1 else "escalate" if amplification_detected else "accept",
            "detection_timestamp": datetime.now(timezone.utc).isoformat()
    }

    def _analyze_output(self, output: str, source_docs: list) -> dict:
        output_lower = output.lower()
        indicators_found = [ind for ind in self.amplification_indicators if ind in output_lower]
        inferred_tier = 1
        for keywords, tier in self.restricted_combination_patterns:
            if all(kw in output_lower for kw in keywords):
                inferred_tier = max(inferred_tier, tier)
                indicator_density = len(indicators_found) / max(len(output_lower.split()), 1) * 1000
                if indicator_density > 2.0:
                    inferred_tier = min(5, inferred_tier + 1)
                    novel_info_score = self._compute_novel_information(output, source_docs)
                    if novel_info_score > 0.3:
                        inferred_tier = min(5, inferred_tier + 1)
                        return {
                        "indicators_found": indicators_found, "indicator_count": len(indicators_found),
                        "indicator_density": indicator_density, "inferred_tier": inferred_tier,
                        "novel_information_score": novel_info_score
                }

    def _identify_amplifying_combinations(self, source_docs: list, output: str) -> list:
        combinations = []
        output_lower = output.lower()
        for i, doc_a in enumerate(source_docs):
            content_a = doc_a.get("content", "").lower()
            keywords_a = set(content_a.split()) - {"the", "is", "are", "a", "an"}
            for j, doc_b in enumerate(source_docs):
                if i >= j:
                    continue
                    content_b = doc_b.get("content", "").lower()
                    keywords_b = set(content_b.split()) - {"the", "is", "are", "a", "an"}
                    combined_keywords = keywords_a | keywords_b
                    output_keywords = set(output_lower.split())
                    overlap = combined_keywords & output_keywords
                    a_unique = keywords_a - keywords_b
                    b_unique = keywords_b - keywords_a
                    a_in_output = a_unique & output_keywords
                    b_in_output = b_unique & output_keywords
                    if len(a_in_output) > 3 and len(b_in_output) > 3:
                        combinations.append({
                            "doc_a": {"doc_id": doc_a.get("doc_id"), "classification": doc_a.get("classification"),
                            "unique_keywords_in_output": list(a_in_output)[:10]},
                            "doc_b": {"doc_id": doc_b.get("doc_id"), "classification": doc_b.get("classification"),
                            "unique_keywords_in_output": list(b_in_output)[:10]},
                            "combined_unique_count": len(a_in_output) + len(b_in_output)
                    })
                    return combinations[:5]

    def _compute_novel_information(self, output: str, source_docs: list) -> float:
        all_source_text = " ".join([d.get("content", "") for d in source_docs]).lower()
        output_lower = output.lower()
        source_words = set(all_source_text.split())
        output_words = set(output_lower.split())
        if not output_words:
            return 0.0
        novel_words = output_words - source_words
        return len(novel_words) / len(output_words)

    def _tier_to_classification(self, tier: int) -> str:
        tier_map = {1: "public", 2: "internal", 3: "confidential", 4: "restricted", 5: "secret"}
        return tier_map.get(tier, "unknown")
