class RetrievalScoringValidator:
    """
    Validates that retrieval scores were not manipulated.
    Detects anomalies in score distribution.
    """
    def __init__(self):
        self.min_score_std = 0.02
        self.max_score_gap = 0.15
        self.score_distribution_threshold = 0.30

    def validate_scores(self, results: list) -> dict:
        if not results:
            return {"action": "accept", "reason": "empty_results"}
        scores = [r.get("relevance_score", 0) for r in results]
        if len(scores) >= 5:
            std = statistics.stdev(scores) if len(scores) > 1 else 0
            if std < self.min_score_std:
                return {"action": "flag", "reason": "low_score_variance", "std": std, "threshold": self.min_score_std}
            gaps = [abs(scores[i] - scores[i+1]) for i in range(len(scores)-1)]
            anomalous_gaps = [(i, gap) for i, gap in enumerate(gaps) if gap > self.max_score_gap]
            if anomalous_gaps:
                return {"action": "flag", "reason": "anomalous_score_gaps", "gaps": anomalous_gaps, "max_allowed_gap": self.max_score_gap}
            expected_mean = 0.70
            actual_mean = sum(scores) / len(scores)
            if abs(actual_mean - expected_mean) > self.score_distribution_threshold:
                return {"action": "flag", "reason": "unexpected_score_distribution",
                "expected_mean": expected_mean, "actual_mean": actual_mean, "difference": abs(actual_mean - expected_mean)}
            return {"action": "accept", "reason": "scores_valid"}
