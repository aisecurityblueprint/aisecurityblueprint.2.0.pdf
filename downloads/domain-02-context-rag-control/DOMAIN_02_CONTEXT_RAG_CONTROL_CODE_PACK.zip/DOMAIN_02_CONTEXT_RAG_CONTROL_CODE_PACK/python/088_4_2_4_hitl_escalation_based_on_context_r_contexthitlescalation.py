class ContextHITLEscalation:
    """
    Manages Human-in-the-Loop escalation based on context risk.
    """
    def __init__(self):
        self.escalation_criteria = {
            "auto_escalate": {
            "conditions": [
            "context_risk_score >= 0.70", "amplification_detected == true",
            "cross_tenant_violation == true", "authoritative_source_contradicted == true"
    ],
        "sla_seconds": 120, "priority": "critical"
},
    "conditional_escalate": {
    "conditions": [
 "context_risk_score >= 0.50 AND context_risk_score < 0.70",
    "trust_deficit >= 0.60", "multiple_consistency_issues == true",
    "memory_poisoning_score >= 0.40"
],
    "sla_seconds": 300, "priority": "high"
},
}
self.escalation_queue = []
self.escalation_log = []

    def evaluate_escalation(self, context_risk_result: dict, context_metadata: dict) -> dict:
        signals = {
            "context_risk_score": context_risk_result.get("context_risk_score", 0),
            "amplification_detected": context_metadata.get("amplification_detected", False),
            "cross_tenant_violation": context_metadata.get("cross_tenant_violation", False),
            "authoritative_source_contradicted": context_metadata.get("authoritative_contradicted", False),
            "trust_deficit": context_risk_result.get("factor_scores", {}).get("trust_deficit", 0),
            "multiple_consistency_issues": context_metadata.get("consistency_issue_count", 0) >= 3,
            "memory_poisoning_score": context_metadata.get("memory_poisoning_score", 0),
    }
    for condition in self.escalation_criteria["auto_escalate"]["conditions"]:
        if self._evaluate_condition(condition, signals):
            escalation = self._create_escalation("auto_escalate", signals, condition)
            self.escalation_queue.append(escalation)
            return escalation
        for condition in self.escalation_criteria["conditional_escalate"]["conditions"]:
            if self._evaluate_condition(condition, signals):
                escalation = self._create_escalation("conditional_escalate", signals, condition)
                self.escalation_queue.append(escalation)
                return escalation
            return {"escalation_required": False, "action": "auto_process", "risk_score": signals["context_risk_score"]}

    def _evaluate_condition(self, condition: str, signals: dict) -> bool:
        """Evaluates simple boolean escalation rules, including AND / OR composites."""
        try:
            parts_or = re.split(r"\s+OR\s+", condition, flags=re.IGNORECASE)
            if len(parts_or) > 1:
                return any(self._evaluate_condition(part.strip(), signals) for part in parts_or)
            parts_and = re.split(r"\s+AND\s+", condition, flags=re.IGNORECASE)
            if len(parts_and) > 1:
                return all(self._evaluate_condition(part.strip(), signals) for part in parts_and)
            expr = condition.strip()
            for key in sorted(signals.keys(), key=len, reverse=True):
                value = signals[key]
                replacement = str(value).lower() if isinstance(value, bool) else str(value)
                expr = re.sub(rf"\b{re.escape(key)}\b", replacement, expr)
                for op in [">=", "<=", "==", ">", "<"]:
                    if op in expr:
 left, right = [x.strip() for x in expr.split(op, 1)]
 if op == "==":
 return left.lower() == right.lower()
 left_v, right_v = float(left), float(right)
 if op == ">=": return left_v >= right_v
 if op == "<=": return left_v <= right_v
 if op == ">": return left_v > right_v
 if op == "<": return left_v < right_v
 return False
 except (ValueError, TypeError):
 return False
 def _create_escalation(self, escalation_type: str, signals: dict, trigger_condition: str) -> dict:
 config = self.escalation_criteria[escalation_type]
 escalation = {
 "escalation_id": hashlib.sha256(f"{datetime.now(timezone.utc).isoformat()}:{trigger_condition}".encode()).hexdigest()[:16],
 "timestamp": datetime.now(timezone.utc).isoformat(), "type": escalation_type,
 "trigger_condition": trigger_condition, "priority": config["priority"],
 "sla_seconds": config["sla_seconds"], "signals": signals,
 "status": "pending", "escalation_required": True, "action": "escalate_to_hitl"
 }
 self.escalation_log.append(escalation)
 return escalation

 def get_queue_status(self) -> dict:
 pending = [e for e in self.escalation_queue if e["status"] == "pending"]
 return {
 "queue_length": len(pending), "pending": pending[:5],
 "oldest_pending": pending[0]["timestamp"] if pending else None,
 "by_priority": {"critical": len([e for e in pending if e["priority"] == "critical"]),
 "high": len([e for e in pending if e["priority"] == "high"])}
 }
