class KnowledgeHierarchy:
    """
    Defines and manages knowledge hierarchy.
    Higher-level knowledge always prevails over lower-level.
    """
    def __init__(self):
        self.hierarchy = {
            "constitutional": {
            "level": 5, "label": "Constitutional Knowledge",
            "description": "Fundamental truths that never change",
            "sources": ["laws_of_physics", "mathematical_axioms", "constitutional_policy"],
            "override_policy": "never_override",
            "examples": ["Organizational constitutional policies", "Laws of physics"]
    },
        "regulatory": {
        "level": 4, "label": "Regulatory Knowledge",
        "description": "Applicable regulations and laws",
        "sources": ["regulatory_filing", "legal_statute", "compliance_requirement"],
        "override_policy": "override_only_by_higher_level",
        "examples": ["GDPR", "PCI DSS", "SOX"]
},
    "policy": {
    "level": 3, "label": "Policy Knowledge",
    "description": "Approved organizational policies",
    "sources": ["official_policy", "board_approved", "internal_audit"],
    "override_policy": "override_with_approval",
    "examples": ["Security policy", "Code of conduct"]
},
    "procedural": {
    "level": 2, "label": "Procedural Knowledge",
    "description": "Standard operating procedures",
    "sources": ["internal_wiki", "sop_document", "process_manual"],
    "override_policy": "override_with_versioning",
    "examples": ["Deployment procedures", "Runbooks"]
},
    "informational": {
    "level": 1, "label": "Informational Knowledge",
    "description": "Reference information, general knowledge",
    "sources": ["verified_partner", "government_public", "industry_standard"],
    "override_policy": "override_freely_with_verification",
    "examples": ["Technical documentation", "White papers"]
},
    "unverified": {
    "level": 0, "label": "Unverified Knowledge",
    "description": "Unverified information",
    "sources": ["public_unverified", "web_crawl", "user_upload"],
    "override_policy": "always_override",
    "examples": ["Blogs", "Forums", "Unverified content"]
},
}

    def classify_knowledge(self, doc: dict) -> dict:
        source = doc.get("source", "unknown")
        doc_type = doc.get("doc_type", "unknown")
        for level_name, level_config in self.hierarchy.items():
            if source in level_config["sources"] or doc_type in level_config["sources"]:
                return {
                "doc_id": doc.get("doc_id"), "level": level_config["level"],
                "level_name": level_name, "label": level_config["label"],
                "override_policy": level_config["override_policy"],
                "classified_at": datetime.now(timezone.utc).isoformat()
        }
        return {
        "doc_id": doc.get("doc_id"), "level": 0, "level_name": "unverified",
        "label": "Unverified Knowledge", "override_policy": "always_override",
        "classified_at": datetime.now(timezone.utc).isoformat()
}

    def resolve_conflict(self, doc_a: dict, doc_b: dict) -> dict:
        level_a = self.classify_knowledge(doc_a)
        level_b = self.classify_knowledge(doc_b)
        if level_a["level"] > level_b["level"]:
            winner = doc_a
            loser = doc_b
            reason = f"{level_a['label']} (level {level_a['level']}) overrides {level_b['label']} (level {level_b['level']})"
        elif level_b["level"] > level_a["level"]:
            winner = doc_b
            loser = doc_a
            reason = f"{level_b['label']} (level {level_b['level']}) overrides {level_a['label']} (level {level_a['level']})"
        else:
            date_a = doc_a.get("last_updated", "2000-01-01")
            date_b = doc_b.get("last_updated", "2000-01-01")
            if date_a >= date_b:
                winner = doc_a
                loser = doc_b
                reason = f"Same level ({level_a['label']}), more recent document wins"
            else:
                winner = doc_b
                loser = doc_a
                reason = f"Same level ({level_a['label']}), more recent document wins"
                return {
                "winner": {"doc_id": winner.get("doc_id"), "level": max(level_a["level"], level_b["level"]), "source": winner.get("source")},
                "loser": {"doc_id": loser.get("doc_id"), "level": min(level_a["level"], level_b["level"]), "source": loser.get("source")},
                "reason": reason, "action": "override_loser_with_winner"
        }

    def get_hierarchy_summary(self) -> dict:
        return {
        "levels": len(self.hierarchy),
        "hierarchy": [{"level": config["level"], "label": config["label"],
        "override_policy": config["override_policy"], "source_count": len(config["sources"])}
        for config in sorted(self.hierarchy.values(), key=lambda x: x["level"], reverse=True)]
}
