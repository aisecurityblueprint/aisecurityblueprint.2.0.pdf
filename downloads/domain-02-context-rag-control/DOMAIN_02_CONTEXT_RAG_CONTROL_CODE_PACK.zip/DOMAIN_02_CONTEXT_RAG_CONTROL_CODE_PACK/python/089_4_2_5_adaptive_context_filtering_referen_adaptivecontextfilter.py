class AdaptiveContextFilter:
    """
    Adaptive context filter that adjusts thresholds based on incident history and user risk profile.
    """
    def __init__(self):
        self.base_thresholds = {
            "min_trust": 2.5, "max_untrusted_ratio": 0.30,
            "min_freshness_score": 0.60, "max_context_risk": 0.55,
    }
    self.user_risk_profiles = {}
    self.adaptation_log = []

    def get_adaptive_thresholds(self, user_id: str, user_context: dict) -> dict:
        user_profile = self._get_or_create_profile(user_id)
        risk_multiplier = self._compute_risk_multiplier(user_profile, user_context)
        adapted = {}
        for threshold_name, base_value in self.base_thresholds.items():
            if threshold_name in ["min_trust", "min_freshness_score"]:
 adapted[threshold_name] = min(base_value * (1 + risk_multiplier * 0.2), base_value * 1.5)
 else:
 adapted[threshold_name] = max(base_value * (1 - risk_multiplier * 0.2), base_value * 0.5)
 return {
 "user_id": user_id, "risk_multiplier": risk_multiplier,
 "base_thresholds": self.base_thresholds, "adapted_thresholds": adapted,
 "adaptation_reason": self._explain_adaptation(risk_multiplier, user_profile)
 }

 def _get_or_create_profile(self, user_id: str) -> dict:
 if user_id not in self.user_risk_profiles:
 self.user_risk_profiles[user_id] = {
 "user_id": user_id, "total_requests": 0, "flagged_requests": 0,
 "blocked_requests": 0, "incident_history": [], "risk_score": 0.5,
 "last_updated": datetime.now(timezone.utc).isoformat()
 }
 return self.user_risk_profiles[user_id]

 def _compute_risk_multiplier(self, profile: dict, current_context: dict) -> float:
 multiplier = 1.0
 incident_count = len(profile.get("incident_history", []))
 if incident_count > 0:
 multiplier += min(0.5, incident_count * 0.1)
 total = max(profile.get("total_requests", 1), 1)
 flagged = profile.get("flagged_requests", 0)
 flag_rate = flagged / total
 if flag_rate > 0.1:
 multiplier += min(0.3, flag_rate * 1.5)
 clearance = current_context.get("clearance_level", 3)
 if clearance <= 2:
 multiplier += 0.2
 network_zone = current_context.get("network_zone", "internal")
 if network_zone == "public":
 multiplier += 0.3
 elif network_zone == "vpn":
 multiplier += 0.1
 return min(2.0, multiplier)

 def _explain_adaptation(self, multiplier: float, profile: dict) -> str:
 if multiplier <= 1.1:
 return "Standard thresholds applied (low risk profile)"
 elif multiplier <= 1.3:
 return "Moderately restrictive thresholds (elevated risk indicators)"
 elif multiplier <= 1.6:
 return "Restrictive thresholds (significant risk indicators)"
 else:
 return "Maximum restriction thresholds (high risk profile)"

 def update_profile(self, user_id: str, event: dict):
 profile = self._get_or_create_profile(user_id)
 profile["total_requests"] += 1
 if event.get("action") == "flag":
 profile["flagged_requests"] += 1
 elif event.get("action") == "block":
 profile["blocked_requests"] += 1
 if event.get("incident"):
 profile["incident_history"].append({
 "timestamp": datetime.now(timezone.utc).isoformat(),
 "type": event["incident"], "severity": event.get("severity", "medium")
 })
 total = max(profile["total_requests"], 1)
 profile["risk_score"] = min(1.0, 0.3 +
 (profile["flagged_requests"] / total) * 0.3 +
 (profile["blocked_requests"] / total) * 0.5 +
 len(profile["incident_history"]) * 0.05)
 profile["last_updated"] = datetime.now(timezone.utc).isoformat()
