class IndirectInjectionDetector:
    """
    Detects indirect prompt injection via RAG documents.
    Document content attempts to manipulate model behavior.
    """
    def __init__(self):
        self.normalizer = InputNormalizer()
        self.injection_patterns = [
            # English
            r"(?i)(ignore|disregard|forget)\s+(all\s+)?(previous|above|prior|system)\s+(instructions?|prompts?|rules?|policies?)",
            r"(?i)(your\s+(new|updated|revised)\s+(instructions?|rules?|policies?)\s+(is|are))",
            r"(?i)(from\s+now\s+on\s+you\s+(are|will|must|should))",
            r"(?i)(you\s+are\s+now\s+(a|an|the)\s+(different|new))",
            r"(?i)(pretend\s+(you\s+are|to\s+be))",
            r"(?i)(act\s+(as\s+if|like)\s+you\s+are)",
            r"(?i)(your\s+(role|persona|identity)\s+(is\s+now|has\s+changed))",
            r"(?i)(you\s+(must|should|will)\s+(output|respond|say|reply)\s+(with|using|in))",
            r"(?i)(do\s+not\s+(mention|reference|acknowledge|disclose))",
            r"(?i)(never\s+(say|tell|mention|reveal|admit))",
            r"(?i)(bypass|override|circumvent)\s+(security|safety|restrictions?|policies?|filters?)",
            r"(?i)(disable|deactivate|turn\s+off)\s+(security|safety|content\s+filters?)",
            r"(?i)(ignore\s+(safety|security|content)\s+(guidelines|policies|restrictions))",
            # Portuguese
            r"(?i)(ignore|ignora|esque[cç]a|desconsidere|descarte)\s+(todas?\s+)?(as\s+)?(instru[cç][oõ]es|regras|pol[ií]ticas|diretrizes)(\s+(anteriores|acima|do\s+sistema))?",
            r"(?i)(suas?\s+novas?\s+(instru[cç][oõ]es|regras|pol[ií]ticas)\s+(s[aã]o|[eé]))",
            r"(?i)(a\s+partir\s+de\s+agora\s+voc[eê]\s+([eé]|ser[aá]|deve|vai))",
            r"(?i)(voc[eê]\s+agora\s+[eé]\s+(um|uma|o|a)\s+(diferente|nov[oa]))",
            r"(?i)(finja\s+(que\s+voc[eê]\s+[eé]|ser))",
            r"(?i)(aja\s+como\s+se\s+(voc[eê]\s+)?fosse)",
            r"(?i)(seu\s+(papel|persona|identidade)\s+(agora\s+[eé]|mudou))",
            r"(?i)(nunca\s+(diga|conte|mencione|revele|admita))",
            r"(?i)(n[aã]o\s+(mencione|referencie|reconhe[cç]a|divulgue))",
            r"(?i)(burl(e|ar)|contorn(e|ar)|sobrescrev(a|er))\s+(seguran[cç]a|restri[cç][oõ]es|pol[ií]ticas|filtros)",
            r"(?i)(desativ(e|ar)|desligu(e|ar))\s+(seguran[cç]a|filtros\s+de\s+conte[uú]do)",
            # Spanish
            r"(?i)(ignora|olvida|descarta|desestima)\s+(todas?\s+)?(las\s+)?(instrucciones|reglas|pol[ií]ticas|directrices)(\s+(anteriores|previas|del\s+sistema))?",
            r"(?i)(tus?\s+nuevas?\s+(instrucciones|reglas|pol[ií]ticas)\s+(son|es))",
            r"(?i)(a\s+partir\s+de\s+ahora\s+(t[uú]\s+)?(eres|ser[aá]s|debes|vas\s+a))",
            r"(?i)(ahora\s+eres\s+(un|una|el|la)\s+(diferente|nuev[oa]))",
            r"(?i)(finge\s+(que\s+eres|ser))",
            r"(?i)(act[uú]a\s+como\s+si\s+fueras)",
            r"(?i)(tu\s+(rol|papel|persona|identidad)\s+(ahora\s+es|ha\s+cambiado))",
            r"(?i)(nunca\s+(digas|cuentes|menciones|reveles|admitas))",
            r"(?i)(no\s+(menciones|referencies|reconozcas|divulgues))",
            r"(?i)(elud(e|ir)|evita(r)?|sobrescrib(e|ir))\s+(seguridad|restricciones|pol[ií]ticas|filtros)",
            r"(?i)(desactiv(a|ar)|apag(a|ar))\s+(seguridad|filtros\s+de\s+contenido)",
    ]
    self.context_suspicious_patterns = [
        r"(?i)(as\s+an\s+AI\s+(assistant|language\s+model))",
        r"(?i)(your\s+system\s+prompt)",
        r"(?i)(you\s+have\s+access\s+to)",
        r"(?i)(your\s+(capabilities|limitations|restrictions))",
]

    def detect_injection(self, doc: dict) -> dict:
        content = doc.get("content", "")
        norm = self.normalizer.normalize(content)
        content = norm["normalized"]
        matched_patterns = []
        for pattern in self.injection_patterns:
            matches = re.findall(pattern, content)
            if matches:
                matched_patterns.append({"pattern": pattern, "matches": matches[:3], "count": len(matches)})
                context_suspicious = []
                for pattern in self.context_suspicious_patterns:
                    if re.search(pattern, content):
                        context_suspicious.append(pattern)
                        injection_score = 0.0
                        if matched_patterns:
                            injection_score = min(1.0, len(matched_patterns) * 0.25)
                            max_matches = max(p["count"] for p in matched_patterns)
                            if max_matches > 3:
                                injection_score = min(1.0, injection_score + 0.2)
                                if context_suspicious:
                                    injection_score = min(1.0, injection_score + len(context_suspicious) * 0.1)
                                    if injection_score >= 0.80:
                                        action = "block"
                                    elif injection_score >= 0.50:
                                        action = "quarantine"
                                    elif injection_score >= 0.25:
                                        action = "flag"
                                    else:
                                        action = "accept"
                                        return {
                                        "doc_id": doc.get("doc_id"), "source": doc.get("source"),
                                        "injection_score": injection_score, "matched_patterns": matched_patterns,
                                        "context_suspicious_patterns": context_suspicious, "action": action,
                                        "detection_timestamp": datetime.now(timezone.utc).isoformat()
                                }

    def scan_context(self, docs: list) -> dict:
        results = []
        blocked_count = quarantined_count = flagged_count = 0
        for doc in docs:
            result = self.detect_injection(doc)
            results.append(result)
            if result["action"] == "block":
                blocked_count += 1
            elif result["action"] == "quarantine":
                quarantined_count += 1
            elif result["action"] == "flag":
                flagged_count += 1
                return {
                "total_docs": len(docs),
                "clean": len(docs) - blocked_count - quarantined_count - flagged_count,
                "blocked": blocked_count, "quarantined": quarantined_count, "flagged": flagged_count,
                "highest_injection_score": max((r["injection_score"] for r in results), default=0),
                "results": results
        }
Calibration note: multilingual injection patterns increase the false-positive surface on legitimate policy documents in English, Portuguese and Spanish. Examples include security awareness text such as "never reveal passwords to anyone", HR policies containing "nunca revele dados pessoais", or Spanish compliance text containing "no divulgue información confidencial". The calibration dataset must include benign EN/PT/ES policy documents to tune score weights, not only attack variants.
