class SessionMemoryController:
    """
    Controls session memory — data that persists only during the current user session.
    """
    def __init__(self):
        self.session_memories = {}
        self.max_session_turns = 50
        self.max_memory_tokens = 8000
        self.token_estimator = TokenEstimator()
        self.memory_write_log = []

    def create_session(self, session_id: str, user_context: dict) -> dict:
        self.session_memories[session_id] = {
            "session_id": session_id, "user_id": user_context.get("user_id"),
            "created_at": datetime.now(timezone.utc).isoformat(), "last_accessed": datetime.now(timezone.utc).isoformat(),
            "turn_count": 0, "memory_entries": [], "total_tokens_stored": 0,
            "user_context_snapshot": user_context, "status": "active"
    }
    return {"session_id": session_id, "status": "created"}

    def add_memory(self, session_id: str, content: str, memory_type: str = "conversation_turn", metadata: dict = None) -> dict:
        if session_id not in self.session_memories:
            return {"action": "reject", "reason": "session_not_found"}
        session = self.session_memories[session_id]
        if session["turn_count"] >= self.max_session_turns:
            return {"action": "reject", "reason": "max_turns_exceeded"}
        tokens = self.token_estimator.count(content)
        if session["total_tokens_stored"] + tokens > self.max_memory_tokens:
            freed = self._evict_oldest_memories(session, tokens)
            if freed < tokens:
                return {"action": "truncate", "reason": "memory_budget_exceeded",
                "tokens_requested": tokens,
                "tokens_available": self.max_memory_tokens - session["total_tokens_stored"]}
            validation = self._validate_memory_content(content)
            if validation["action"] == "block":
                return validation
            entry = {
                "entry_id": len(session["memory_entries"]) + 1,
                "timestamp": datetime.now(timezone.utc).isoformat(), "type": memory_type,
                "content": content, "tokens": tokens, "metadata": metadata or {},
                "content_hash": hashlib.sha256(content.encode()).hexdigest()[:16],
                "validation": validation
        }
        session["memory_entries"].append(entry)
        session["turn_count"] += 1
        session["total_tokens_stored"] += tokens
        session["last_accessed"] = datetime.now(timezone.utc).isoformat()
        self.memory_write_log.append({
            "session_id": session_id, "entry_id": entry["entry_id"],
            "type": memory_type, "tokens": tokens, "timestamp": entry["timestamp"]
    })
    return {"action": "stored", "entry_id": entry["entry_id"], "tokens_stored": tokens,
    "session_tokens_total": session["total_tokens_stored"], "session_turns": session["turn_count"]}

    def retrieve_memory(self, session_id: str, max_turns: int = 10) -> dict:
        if session_id not in self.session_memories:
            return {"action": "reject", "reason": "session_not_found"}
        session = self.session_memories[session_id]
        recent_entries = session["memory_entries"][-max_turns:]
        sanitized_entries = [self._sanitize_memory_for_context(e) for e in recent_entries]
        memory_context = self._format_memory_for_context(sanitized_entries)
        session["last_accessed"] = datetime.now(timezone.utc).isoformat()
        return {
        "action": "retrieved", "entries_retrieved": len(sanitized_entries),
        "total_tokens": sum(e["tokens"] for e in sanitized_entries),
        "memory_context": memory_context, "session_turns": session["turn_count"]
}

    def _validate_memory_content(self, content: str) -> dict:
        injection_patterns = [
            r"(?i)(ignore|forget|override)\s+(all\s+)?(previous|system)\s+(instructions|policies|rules)",
            r"(?i)(from\s+now\s+on\s+you\s+are)",
            r"(?i)(your\s+new\s+(instructions?|rules?|policies?)\s+(is|are))",
    ]
    for pattern in injection_patterns:
        if re.search(pattern, content):
            return {"action": "block", "reason": "injection_detected_in_memory_content", "pattern": pattern}
        return {"action": "accept"}

    def _sanitize_memory_for_context(self, entry: dict) -> dict:
        content = entry.get("content", "")
        content = content.replace("<SYSTEM>", "").replace("</SYSTEM>", "")
        content = content.replace("<USER>", "").replace("</USER>", "")
        return {**entry, "content": content, "sanitized": True}

    def _format_memory_for_context(self, entries: list) -> str:
        parts = [f"[MEMORY | {e.get('type')} | {e.get('timestamp')}]\n{e.get('content')}" for e in entries]
        return "\n\n".join(parts)

    def _evict_oldest_memories(self, session: dict, needed_tokens: int) -> int:
        freed = 0
        entries = session["memory_entries"]
        while entries and freed < needed_tokens:
            removed = entries.pop(0)
            freed += removed.get("tokens", 0)
            session["total_tokens_stored"] -= removed.get("tokens", 0)
            session["turn_count"] -= 1
            return freed

    def end_session(self, session_id: str) -> dict:
        if session_id in self.session_memories:
            session = self.session_memories[session_id]
            session["status"] = "ended"
            session["ended_at"] = datetime.now(timezone.utc).isoformat()
            memory_summary = {
                "session_id": session_id, "total_turns": session["turn_count"],
                "total_entries": len(session["memory_entries"]), "total_tokens": session["total_tokens_stored"]
        }
        del self.session_memories[session_id]
        return {"action": "ended", "summary": memory_summary}
    return {"action": "reject", "reason": "session_not_found"}
