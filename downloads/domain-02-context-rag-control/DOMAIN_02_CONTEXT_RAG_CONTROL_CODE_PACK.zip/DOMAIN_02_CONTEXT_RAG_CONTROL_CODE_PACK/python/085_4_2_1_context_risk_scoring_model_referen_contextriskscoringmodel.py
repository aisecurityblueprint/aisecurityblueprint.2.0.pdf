class ContextRiskScoringModel:
    """
    Risk scoring model for the entire context.
    Integrates signals from all Domain 02 - Context & RAG Control validators.
    """
    def __init__(self):
        self.risk_factors = {
            "injection_risk": 0.25, "trust_deficit": 0.20, "freshness_decay": 0.10,
            "consistency_issues": 0.10, "amplification_risk": 0.15, "source_mix_risk": 0.05,
            "memory_poisoning_risk": 0.05, "tool_output_risk": 0.05,
            "isolation_breach_risk": 0.03, "anomaly_score": 0.02,
    }
    self.risk_thresholds = {"critical": 0.75, "high": 0.60, "medium": 0.40, "low": 0.20}
    self.scoring_history = []

    def compute_risk_score(self, signals: dict) -> dict:
        factor_scores = {}
        injection_data = signals.get("injection", {})
        factor_scores["injection_risk"] = min(1.0,
            injection_data.get("highest_injection_score", 0) * 1.0 +
            injection_data.get("cross_chunk_findings", 0) * 0.2 +
            injection_data.get("indirect_injection_score", 0) * 0.8)
        trust_data = signals.get("trust", {})
        avg_trust = trust_data.get("average_trust", 3.5)
 factor_scores["trust_deficit"] = max(0.0, 1.0 - (avg_trust / 5.0))
        freshness_data = signals.get("freshness", {})
        factor_scores["freshness_decay"] = 1.0 - freshness_data.get("freshness_score", 1.0)
        consistency_data = signals.get("consistency", {})
 factor_scores["consistency_issues"] = min(1.0, consistency_data.get("issue_count", 0) * 0.1 + consistency_data.get("contradiction_count", 0) * 0.2)
 amplification_data = signals.get("amplification", {})
 factor_scores["amplification_risk"] = (0.8 if amplification_data.get("amplification_detected") else 0.0) + min(0.2, amplification_data.get("amplification_magnitude", 0) * 0.2)
 sources_data = signals.get("sources", {})
 untrusted_ratio = sources_data.get("external_unverified_ratio", 0)
 factor_scores["source_mix_risk"] = min(1.0, untrusted_ratio * 2.0)
 memory_data = signals.get("memory", {})
 factor_scores["memory_poisoning_risk"] = memory_data.get("poisoning_score", 0)
 tool_data = signals.get("tools", {})
 factor_scores["tool_output_risk"] = 1.0 - tool_data.get("average_trust_score", 1.0)
 isolation_data = signals.get("isolation", {})
 factor_scores["isolation_breach_risk"] = min(1.0, isolation_data.get("violations_today", 0) * 0.2)
 anomaly_data = signals.get("anomaly", {})
 factor_scores["anomaly_score"] = anomaly_data.get("overall_anomaly_score", 0)
 composite = sum(factor_scores[f] * w for f, w in self.risk_factors.items())
 composite = min(1.0, composite)
 risk_level = self._determine_risk_level(composite)
 result = {
 "context_risk_score": composite, "risk_level": risk_level,
 "factor_scores": factor_scores, "action": self._determine_action(composite, risk_level),
 "scoring_timestamp": datetime.now(timezone.utc).isoformat(), "thresholds_used": self.risk_thresholds
 }
 self.scoring_history.append(result)
 return result

 def _determine_risk_level(self, score: float) -> str:
 if score >= self.risk_thresholds["critical"]:
 return "critical"
 elif score >= self.risk_thresholds["high"]:
 return "high"
 elif score >= self.risk_thresholds["medium"]:
 return "medium"
 elif score >= self.risk_thresholds["low"]:
 return "low"
 else:
 return "minimal"

 def _determine_action(self, score: float, risk_level: str) -> str:
 if risk_level == "critical":
 return "block"
 elif risk_level == "high":
 return "escalate_to_hitl"
 elif risk_level == "medium":
 return "flag_for_review"
 elif risk_level == "low":
 return "accept_with_monitoring"
 else:
 return "accept"

 def get_scoring_trend(self, window_hours: int = 24) -> dict:
 cutoff = datetime.now(timezone.utc) - timedelta(hours=window_hours)
 recent_scores = [s for s in self.scoring_history if parse_ts(s["scoring_timestamp"]) >= cutoff]
 if len(recent_scores) < 2:
 return {"trend": "insufficient_data", "data_points": len(recent_scores)}
 scores = [s["context_risk_score"] for s in recent_scores]
 first_score = scores[0]
 last_score = scores[-1]
 avg_score = sum(scores) / len(scores)
 trend_direction = "increasing" if last_score > first_score * 1.1 else "decreasing" if last_score < first_score * 0.9 else "stable"
 return {
 "trend": trend_direction, "data_points": len(scores), "first_score": first_score,
 "last_score": last_score, "average_score": avg_score, "min_score": min(scores),
 "max_score": max(scores), "volatility": max(scores) - min(scores)
 }
