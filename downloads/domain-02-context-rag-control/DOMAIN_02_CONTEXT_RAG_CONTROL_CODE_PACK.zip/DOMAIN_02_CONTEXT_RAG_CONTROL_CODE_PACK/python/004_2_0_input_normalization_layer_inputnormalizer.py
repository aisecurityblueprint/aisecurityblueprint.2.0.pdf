import hashlib
import re
import unicodedata

class InputNormalizer:
 """
 Canonicalizes text before any detection layer runs.
 Pipeline: NFKC -> strip zero-width/control -> homoglyph fold ->
 collapse whitespace.
 The raw original is retained for forensic reconstruction.
 """
 ZERO_WIDTH = [
 "\u200b", "\u200c", "\u200d", "\u2060", "\ufeff",
 "\u00ad", "\u034f",
 ]
 HOMOGLYPHS = {
 "а": "a", "е": "e", "о": "o", "р": "p", "с": "c",
 "х": "x", "у": "y", "і": "i", "ѕ": "s",
 "Α": "A", "Β": "B", "Ε": "E", "Ο": "O", "Ρ": "P",
 "ı": "i", "ℓ": "l", "⁄": "/",
 }

 def normalize(self, text: str) -> dict:
 if not text:
 return {"normalized": "", "signals": [], "evasion_score": 0.0, "raw_hash": None, "action": "accept"}
 signals = []
 raw_hash = hashlib.sha256(text.encode()).hexdigest()

 normalized = unicodedata.normalize("NFKC", text)
 if normalized != text:
 signals.append("nfkc_changed_content")

 zw_found = sum(normalized.count(z) for z in self.ZERO_WIDTH)
 if zw_found:
 signals.append(f"zero_width_chars_removed:{zw_found}")
 for z in self.ZERO_WIDTH:
 normalized = normalized.replace(z, "")

 cleaned = "".join(
 ch for ch in normalized
 if ch == "\n" or ch == "\t" or not unicodedata.category(ch).startswith("C")
 )
 if cleaned != normalized:
 signals.append("control_chars_removed")
 normalized = cleaned

 hg_count = sum(normalized.count(h) for h in self.HOMOGLYPHS)
 if hg_count:
 signals.append(f"homoglyphs_folded:{hg_count}")
 for src, dst in self.HOMOGLYPHS.items():
 normalized = normalized.replace(src, dst)

 normalized = re.sub(r"[ \t]{2,}", " ", normalized)
 evasion_score = min(1.0, (zw_found * 0.15) + (hg_count * 0.10))
 return {
 "normalized": normalized,
 "signals": signals,
 "evasion_score": evasion_score,
 "raw_hash": raw_hash,
 "action": "flag" if evasion_score >= 0.30 else "accept",
 }
