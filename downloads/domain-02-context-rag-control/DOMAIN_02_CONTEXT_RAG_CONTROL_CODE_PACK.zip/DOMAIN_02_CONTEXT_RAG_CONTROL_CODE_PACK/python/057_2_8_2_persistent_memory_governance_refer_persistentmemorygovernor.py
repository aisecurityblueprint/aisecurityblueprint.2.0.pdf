class PersistentMemoryGovernor:
    """
    Governs persistent memory — data that survives across sessions.
    Includes expiration policies, scope isolation, and validation.
    """
    def __init__(self):
        self.persistent_memories = {}
        self.token_estimator = TokenEstimator()
        self.global_policies = {
            "max_entries_per_user": 100, "max_tokens_per_user": 50000,
            "default_ttl_days": 90, "max_ttl_days": 365,
    }

    def store_persistent(self, user_id: str, content: str, memory_type: str = "user_preference",
 ttl_days: int = None, scope: str = "user") -> dict:
 if user_id not in self.persistent_memories:
 self.persistent_memories[user_id] = {"user_id": user_id, "entries": [], "total_tokens": 0, "created_at": datetime.now(timezone.utc).isoformat()}
 user_memory = self.persistent_memories[user_id]
 if len(user_memory["entries"]) >= self.global_policies["max_entries_per_user"]:
 self._evict_expired_or_oldest(user_memory)
 tokens = self.token_estimator.count(content)
 if user_memory["total_tokens"] + tokens > self.global_policies["max_tokens_per_user"]:
 return {"action": "reject", "reason": "memory_quota_exceeded",
 "current_tokens": user_memory["total_tokens"], "max_tokens": self.global_policies["max_tokens_per_user"]}
 effective_ttl = min(ttl_days or self.global_policies["default_ttl_days"], self.global_policies["max_ttl_days"])
 validation = self._validate_persistent_content(content, memory_type)
 if validation["action"] == "block":
 return validation
 entry = {
 "entry_id": hashlib.sha256(f"{user_id}:{datetime.now(timezone.utc).isoformat()}:{content[:50]}".encode()).hexdigest()[:16],
 "timestamp": datetime.now(timezone.utc).isoformat(), "type": memory_type,
 "content": content, "tokens": tokens, "scope": scope,
 "ttl_days": effective_ttl,
 "expires_at": (datetime.now(timezone.utc) + timedelta(days=effective_ttl)).isoformat(),
 "validation": validation, "access_count": 0, "last_accessed": None
 }
 user_memory["entries"].append(entry)
 user_memory["total_tokens"] += tokens
 return {"action": "stored", "entry_id": entry["entry_id"], "expires_at": entry["expires_at"], "ttl_days": effective_ttl}

 def retrieve_persistent(self, user_id: str, memory_type: str = None, max_entries: int = 20) -> dict:
 if user_id not in self.persistent_memories:
 return {"action": "empty", "reason": "no_persistent_memory"}
 user_memory = self.persistent_memories[user_id]
 now = datetime.now(timezone.utc)
 valid_entries = []
 for entry in user_memory["entries"]:
 expires_at = parse_ts(entry["expires_at"])
 if expires_at < now:
 continue
 if memory_type and entry["type"] != memory_type:
 continue
 entry["access_count"] += 1
 entry["last_accessed"] = now.isoformat()
 valid_entries.append(entry)
 valid_entries.sort(key=lambda e: e["timestamp"], reverse=True)
 entries_to_return = valid_entries[:max_entries]
 memory_context = self._format_persistent_for_context(entries_to_return)
 return {
 "action": "retrieved", "entries_retrieved": len(entries_to_return),
 "total_entries_available": len(valid_entries), "memory_context": memory_context,
 "oldest_entry": entries_to_return[-1]["timestamp"] if entries_to_return else None,
 "newest_entry": entries_to_return[0]["timestamp"] if entries_to_return else None
 }

 def _validate_persistent_content(self, content: str, memory_type: str) -> dict:
 injection_patterns = [
 r"(?i)(ignore|forget|override)\s+(all\s+)?(previous|system)\s+(instructions|policies|rules)",
 r"(?i)(you\s+are\s+now\s+a\s+(different|new))",
 r"(?i)(your\s+(role|persona|identity)\s+(is\s+now|has\s+changed))",
 r"(?i)(memorize|remember|store)\s+(this|that)\s+(for|as)",
 ]
 for pattern in injection_patterns:
 if re.search(pattern, content):
 return {"action": "block", "reason": "injection_detected_in_persistent_memory", "pattern": pattern}
 sensitive_patterns = [r'\b\d{3}-\d{2}-\d{4}\b', r'\b\d{16}\b', r'(?i)(password|secret|token|api[_-]?key)\s*[:=]\s*\S+']
 for pattern in sensitive_patterns:
 if re.search(pattern, content):
 return {"action": "redact", "reason": "sensitive_data_in_persistent_memory", "pattern": pattern}
 return {"action": "accept"}

 def _format_persistent_for_context(self, entries: list) -> str:
 parts = [f"[PERSISTENT MEMORY | {e.get('type')} | stored: {e.get('timestamp')}]\n{e.get('content')}" for e in entries]
 return "\n\n".join(parts)

 def _evict_expired_or_oldest(self, user_memory: dict):
 now = datetime.now(timezone.utc)
 user_memory["entries"] = [e for e in user_memory["entries"] if parse_ts(e["expires_at"]) >= now]
 while len(user_memory["entries"]) >= self.global_policies["max_entries_per_user"]:
 removed = user_memory["entries"].pop(0)
 user_memory["total_tokens"] -= removed.get("tokens", 0)

 def cleanup_expired(self) -> dict:
 now = datetime.now(timezone.utc)
 total_removed = 0
 for user_id in list(self.persistent_memories.keys()):
 user_memory = self.persistent_memories[user_id]
 original_count = len(user_memory["entries"])
 user_memory["entries"] = [e for e in user_memory["entries"] if parse_ts(e["expires_at"]) >= now]
 removed = original_count - len(user_memory["entries"])
 total_removed += removed
 user_memory["total_tokens"] = sum(e.get("tokens", 0) for e in user_memory["entries"])
 return {"action": "cleanup_completed", "total_removed": total_removed,
 "users_cleaned": len(self.persistent_memories), "cleanup_timestamp": now.isoformat()}
