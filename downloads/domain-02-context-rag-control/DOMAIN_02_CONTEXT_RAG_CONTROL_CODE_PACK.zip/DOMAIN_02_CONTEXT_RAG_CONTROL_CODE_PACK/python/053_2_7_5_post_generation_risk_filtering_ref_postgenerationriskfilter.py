class PostGenerationRiskFilter:
    """
    Post-generation risk filter — last line of defense before output reaches user.
    """
    def __init__(self):
        self.risk_thresholds = {"block": 0.80, "escalate": 0.60, "flag": 0.40}

    def filter(self, output: str, generation_metadata: dict) -> dict:
        risk_signals = self._collect_risk_signals(output, generation_metadata)
        risk_score = self._compute_risk_score(risk_signals)
        if risk_score >= self.risk_thresholds["block"]:
            action = "block"
        elif risk_score >= self.risk_thresholds["escalate"]:
            action = "escalate_to_hitl"
        elif risk_score >= self.risk_thresholds["flag"]:
            action = "flag_for_review"
        else:
            action = "release"
            return {
            "action": action, "risk_score": risk_score,
            "risk_level": "critical" if risk_score >= 0.80 else "high" if risk_score >= 0.60 else "medium" if risk_score >= 0.40 else "low",
            "risk_signals": risk_signals, "output_preview": output[:200],
            "filter_timestamp": datetime.now(timezone.utc).isoformat()
    }

    def _collect_risk_signals(self, output: str, metadata: dict) -> dict:
        output_lower = output.lower()
        return {
        "contains_sensitive_data": self._has_sensitive_data(output),
        "contains_aggregation": self._has_aggregation(output_lower),
        "contains_future_projection": self._has_future_projection(output_lower),
        "contains_individual_data": self._has_individual_data(output_lower),
        "amplification_detected": metadata.get("amplification_detected", False),
        "output_sensitivity": metadata.get("output_sensitivity", 1),
        "source_trust_min": metadata.get("source_trust_min", 1.0),
}

    def _compute_risk_score(self, signals: dict) -> float:
        weights = {
            "contains_sensitive_data": 0.35, "contains_individual_data": 0.20,
            "contains_aggregation": 0.15, "amplification_detected": 0.15,
            "output_sensitivity_normalized": 0.10, "source_trust_inverted": 0.05,
    }
    score = 0.0
    if signals["contains_sensitive_data"]:
        score += weights["contains_sensitive_data"]
        if signals["contains_individual_data"]:
            score += weights["contains_individual_data"]
            if signals["contains_aggregation"]:
                score += weights["contains_aggregation"]
                if signals["amplification_detected"]:
                    score += weights["amplification_detected"]
                    sensitivity_norm = (signals["output_sensitivity"] - 1) / 4
                    score += sensitivity_norm * weights["output_sensitivity_normalized"]
                    source_trust_inv = 1.0 - signals["source_trust_min"]
                    score += source_trust_inv * weights["source_trust_inverted"]
                    return min(1.0, score)

    def _has_sensitive_data(self, output: str) -> bool:
        patterns = [r'\b\d{3}-\d{2}-\d{4}\b', r'\b\d{16}\b', r'(?i)(password|secret|token)\s*[:=]\s*\S+']
        return any(re.search(p, output) for p in patterns)

    def _has_aggregation(self, output_lower: str) -> bool:
        keywords = ["total", "sum", "average", "aggregate", "combined total"]
        return any(kw in output_lower for kw in keywords)

    def _has_future_projection(self, output_lower: str) -> bool:
        keywords = ["will be", "projected", "forecasted", "estimated to"]
        return any(kw in output_lower for kw in keywords)

    def _has_individual_data(self, output_lower: str) -> bool:
        keywords = ["specific customer", "individual user", "particular employee"]
        return any(kw in output_lower for kw in keywords)
