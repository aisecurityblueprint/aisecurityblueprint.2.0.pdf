class MemoryPoisoningDetector:
    """
    Detects memory poisoning — attempts to inject malicious instructions into memory
    that will affect future interactions. Expands on Domain 01 §4.3.1 with behavioral detection.
    """
    def __init__(self):
        self.normalizer = InputNormalizer()
        self.poisoning_patterns = [
            # English
            r"(?i)(from\s+now\s+on\s+you\s+(are|will|must|should))",
            r"(?i)(remember|memorize)\s+(that|this)\s+(you\s+are|i\s+am|the)",
            r"(?i)(forget\s+(everything|all)\s+(you\s+know|about))",
            r"(?i)(your\s+new\s+(identity|role|purpose|goal|directive|instruction))",
            r"(?i)(you\s+no\s+longer\s+(work\s+for|serve|follow))",
            r"(?i)(i\s+am\s+(now\s+)?(your\s+)?(admin|administrator|owner|creator|boss))",
            r"(?i)(you\s+must\s+(always|never)\s+(respond|answer|say|tell|provide))",
            # Portuguese
            r"(?i)(a\s+partir\s+de\s+agora\s+voc[eê]\s+([eé]|ser[aá]|deve|vai))",
            r"(?i)((lembre|memorize|grave)(-se)?\s+(que|disto|disso)?\s*(voc[eê]\s+[eé]|eu\s+sou|o|a))",
            r"(?i)(esque[cç]a\s+(tudo|todo)\s+(que\s+(voc[eê]\s+)?sabe|sobre))",
            r"(?i)(sua\s+nova\s+(identidade|fun[cç][aã]o|prop[oó]sito|meta|diretriz|instru[cç][aã]o))",
            r"(?i)(voc[eê]\s+n[aã]o\s+(trabalha\s+mais\s+para|serve\s+mais|segue\s+mais))",
            r"(?i)(eu\s+sou\s+(agora\s+)?(seu\s+|sua\s+)?(admin|administrador|dono|criador|chefe))",
            r"(?i)(voc[eê]\s+deve\s+(sempre|nunca)\s+(responder|dizer|contar|fornecer))",
            # Spanish
            r"(?i)(a\s+partir\s+de\s+ahora\s+(t[uú]\s+)?(eres|ser[aá]s|debes|vas\s+a))",
            r"(?i)((recuerda|memoriza|guarda)\s+(que|esto)?\s*(t[uú]\s+eres|yo\s+soy|el|la))",
            r"(?i)(olvida\s+(todo)\s+(lo\s+que\s+sabes|sobre|acerca\s+de))",
            r"(?i)(tu\s+nuev[oa]\s+(identidad|rol|papel|prop[oó]sito|meta|directriz|instrucci[oó]n))",
            r"(?i)((t[uú]\s+)?ya\s+no\s+(trabajas\s+para|sirves\s+a|sigues\s+a))",
            r"(?i)(yo\s+soy\s+(ahora\s+)?(tu\s+)?(admin|administrador|due[ñn]o|creador|jefe))",
            r"(?i)((t[uú]\s+)?debes\s+(siempre|nunca)\s+(responder|decir|contar|proporcionar))",
    ]
    self.behavioral_indicators = {
        "identity_shift": [
        r"(?i)(you\s+are\s+now\s+(a|an|the)\s+(different|new))",
        r"(?i)(your\s+(name|identity)\s+is\s+now)",
        r"(?i)(voc[eê]\s+agora\s+[eé]\s+(um|uma)\s+(diferente|nov[oa]))",
        r"(?i)(seu\s+(nome|identidade)\s+agora\s+[eé])",
        r"(?i)(ahora\s+eres\s+(un|una)\s+(diferente|nuev[oa]))",
        r"(?i)(tu\s+(nombre|identidad)\s+ahora\s+es)",
],
    "rule_override": [
    r"(?i)(ignore\s+(your|the)\s+(rules?|policies?|restrictions?|guidelines?))",
    r"(?i)(break|bypass|circumvent)\s+(your|the)\s+(rules?|policies?)",
    r"(?i)(ignore\s+(suas?|as)\s+(regras|pol[ií]ticas|restri[cç][oõ]es|diretrizes))",
    r"(?i)(quebr(e|ar)|burl(e|ar)|contorn(e|ar))\s+(suas?|as)\s+(regras|pol[ií]ticas)",
    r"(?i)(ignora\s+(tus|las)\s+(reglas|pol[ií]ticas|restricciones|directrices))",
    r"(?i)(romp(e|er)|elud(e|ir)|evita(r)?)\s+(tus|las)\s+(reglas|pol[ií]ticas)",
],
    "trust_exploitation": [
    r"(?i)(trust\s+me|i\s+promise|i\s+swear|i\s+assure\s+you)",
    r"(?i)(this\s+is\s+(confidential|secret|private|between\s+us))",
    r"(?i)(confie\s+em\s+mim|eu\s+prometo|eu\s+juro|eu\s+garanto)",
    r"(?i)(isto\s+[eé]\s+(confidencial|segredo|privado|entre\s+n[oó]s))",
    r"(?i)(conf[ií]a\s+en\s+m[ií]|te\s+lo\s+prometo|te\s+lo\s+juro|te\s+lo\s+aseguro)",
    r"(?i)(esto\s+es\s+(confidencial|secreto|privado|entre\s+nosotros))",
],
}

    def detect_injection_attempt(self, content: str, user_context: dict) -> dict:
        norm = self.normalizer.normalize(content)
        content = norm["normalized"]
        findings = []
        for pattern in self.poisoning_patterns:
            matches = re.findall(pattern, content)
            if matches:
                findings.append({"type": "poisoning_pattern", "pattern": pattern,
                    "matches": matches[:3], "match_count": len(matches), "severity": "high"})
                for indicator_type, patterns in self.behavioral_indicators.items():
                    for pattern in patterns:
                        if re.search(pattern, content):
                            findings.append({"type": f"behavioral_{indicator_type}", "pattern": pattern,
                                "severity": "high" if indicator_type == "rule_override" else "medium"})
                            if findings:
                                high_severity = sum(1 for f in findings if f["severity"] == "high")
                                medium_severity = sum(1 for f in findings if f["severity"] == "medium")
                                poisoning_score = min(1.0, high_severity * 0.4 + medium_severity * 0.2)
                            else:
                                poisoning_score = 0.0
                                return {
                                "poisoning_detected": len(findings) > 0, "poisoning_score": poisoning_score,
                                "findings": findings, "finding_count": len(findings),
                                "action": "block" if poisoning_score >= 0.60 else "flag" if poisoning_score >= 0.30 else "accept",
                                "user_id": user_context.get("user_id", "unknown"),
                                "detection_timestamp": datetime.now(timezone.utc).isoformat()
                        }
    def scan_stored_memories(self, memories: list) -> dict:
        poisoned = []
        for memory in memories:
            content = memory.get("content", "")
            result = self.detect_injection_attempt(content, {"user_id": memory.get("user_id", "unknown")})
            if result["poisoning_detected"]:
                poisoned.append({
                    "entry_id": memory.get("entry_id"), "poisoning_score": result["poisoning_score"],
                    "findings": result["findings"], "stored_at": memory.get("timestamp")
            })
            return {
            "total_scanned": len(memories), "poisoned_count": len(poisoned), "poisoned": poisoned,
            "action": "quarantine_poisoned" if poisoned else "accept"
    }
