class ContentIntegrityVerifier:
 def __init__(self, signing_public_key: str = None):
 self.signing_public_key = signing_public_key
 self.verified_hashes = set()
 self.tampered_docs = []

 def compute_hash(self, content: str) -> str:
 return hashlib.sha256(content.encode()).hexdigest()

 def verify_integrity(self, doc: dict) -> dict:
 doc_id = doc.get("doc_id", "unknown")
 content = doc.get("content", "")
 expected_hash = doc.get("content_hash")
 signature = doc.get("signature")
 computed_hash = self.compute_hash(content)
 hash_verified = (computed_hash == expected_hash) if expected_hash else False
 if expected_hash and not hash_verified:
 self.tampered_docs.append({"doc_id": doc_id, "expected_hash": expected_hash, "computed_hash": computed_hash, "timestamp": datetime.now(timezone.utc).isoformat()})
 signature_verified = self._verify_signature(content, signature)
 chain_verified = True
 if doc.get("chain_hash_prev") and doc.get("chain_hash"):
 chain_verified = self._verify_chain_hash(doc)
 overall_integrity = hash_verified and chain_verified
 return {"doc_id": doc_id, "hash_verified": hash_verified, "signature_verified": signature_verified, "chain_verified": chain_verified, "overall_integrity": overall_integrity, "computed_hash": computed_hash, "expected_hash": expected_hash, "action": "accept" if overall_integrity else "quarantine"}

 def _verify_signature(self, content: str, signature: str) -> bool:
 if not self.signing_public_key or not signature:
 return False
 try:
 import base64
 from cryptography.hazmat.primitives import hashes, serialization
 from cryptography.hazmat.primitives.asymmetric import ec
 from cryptography.exceptions import InvalidSignature
 public_key = serialization.load_pem_public_key(self.signing_public_key.encode())
 public_key.verify(base64.b64decode(signature), content.encode(), ec.ECDSA(hashes.SHA256()))
 return True
 except InvalidSignature:
 self.tampered_docs.append({"doc_id": "signature_mismatch", "reason": "invalid_signature", "timestamp": datetime.now(timezone.utc).isoformat()})
 return False
 except Exception:
 return False
 def _verify_chain_hash(self, doc: dict) -> bool:
 prev_hash = doc.get("chain_hash_prev")
 current_hash = doc.get("chain_hash")
 content = doc.get("content", "")
 timestamp = doc.get("last_updated", "")
 expected_hash = hashlib.sha256(f"{prev_hash}:{timestamp}:{content}".encode()).hexdigest()
 return expected_hash == current_hash

 def get_tampering_report(self) -> dict:
 return {"total_tampered": len(self.tampered_docs), "tampered_docs": self.tampered_docs[-10:], "last_detected": self.tampered_docs[-1]["timestamp"] if self.tampered_docs else None}
