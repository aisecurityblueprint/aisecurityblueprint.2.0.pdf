class ContextConsistencyChecker:
    """
    Checks internal consistency of context.
    Detects mutually exclusive statements.
    """
    def check_consistency(self, context: str) -> dict:
        issues = []
        numeric_issues = self._check_numeric_consistency(context)
        issues.extend(numeric_issues)
        temporal_issues = self._check_temporal_consistency(context)
        issues.extend(temporal_issues)
        entity_issues = self._check_entity_consistency(context)
        issues.extend(entity_issues)
        logical_issues = self._check_logical_consistency(context)
        issues.extend(logical_issues)
        return {"consistent": len(issues) == 0, "issues": issues, "issue_count": len(issues), "action": "flag" if issues else "accept"}

    def _check_numeric_consistency(self, context: str) -> list:
        issues = []
        number_pattern = r'(\d+(?:\.\d+)?)\s*(%|percent|dollars|USD|users|customers|records)'
        numbers_found = re.findall(number_pattern, context, re.IGNORECASE)
        by_unit = {}
        for value, unit in numbers_found:
            unit_lower = unit.lower()
            if unit_lower not in by_unit:
                by_unit[unit_lower] = []
                by_unit[unit_lower].append(float(value))
                for unit, values in by_unit.items():
                    if len(values) >= 2:
                        value_range = max(values) - min(values)
                        avg_value = sum(values) / len(values)
                        if avg_value > 0 and value_range / avg_value > 0.5:
 issues.append({"type": "numeric_inconsistency", "unit": unit, "values": values, "range": value_range, "severity": "medium"})
 return issues

 def _check_temporal_consistency(self, context: str) -> list:
 issues = []
 date_patterns = [
 r'\b(202[0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])\b',
 r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+202[0-9]\b',
 r'\bQ[1-4]\s*202[0-9]\b',
 ]
 dates_found = []
 for pattern in date_patterns:
 matches = re.findall(pattern, context, re.IGNORECASE)
 dates_found.extend(matches)
 if len(dates_found) > 5:
 issues.append({"type": "temporal_overload", "date_count": len(dates_found), "severity": "low"})
 return issues

 def _check_entity_consistency(self, context: str) -> list:
 issues = []
 entity_pattern = r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b'
 entities = re.findall(entity_pattern, context)
 entity_counts = {}
 for entity in entities:
 if len(entity) > 3:
 entity_counts[entity] = entity_counts.get(entity, 0) + 1
 single_mentions = [e for e, c in entity_counts.items() if c == 1 and len(e) > 10]
 if len(single_mentions) > 5:
 issues.append({"type": "unfamiliar_entities", "count": len(single_mentions), "entities": single_mentions[:5], "severity": "low"})
 return issues

 def _check_logical_consistency(self, context: str) -> list:
 issues = []
 logical_patterns = [
 (r'(?i)always\s+(\w+)', r'(?i)never\s+\1'),
 (r'(?i)must\s+(\w+)', r'(?i)must\s+not\s+\1'),
 (r'(?i)all\s+(\w+)', r'(?i)no\s+\1'),
 ]
 for pattern1, pattern2 in logical_patterns:
 match1 = re.findall(pattern1, context)
 match2 = re.findall(pattern2, context)
 common = set(match1) & set(match2)
 if common:
 issues.append({"type": "logical_contradiction", "terms": list(common), "severity": "high"})
 return issues
