class DataFreshnessValidator:
    """
    Validates RAG data freshness. Stale data can lead to incorrect decisions.
    """
    def __init__(self):
        self.freshness_thresholds = {
            "financial_data": 90,
            "legal_policy": 365,
            "technical_doc": 180,
            "regulatory": 30,
            "news": 7,
            "general": 365,
    }
    self.staleness_actions = {
        "warning": "log_and_use",
        "flag": "use_with_caution",
        "block": "block",
}

    def validate(self, doc: dict) -> dict:
        doc_type = doc.get("doc_type", "general")
        last_updated = doc.get("last_updated")
        created_date = doc.get("created_date")
        if not last_updated and not created_date:
            return {"action": "flag", "reason": "no_date_information", "staleness": "unknown"}
        reference_date = last_updated or created_date
        try:
            ref_date = parse_ts(reference_date)
            days_old = (datetime.now(timezone.utc) - ref_date).days
            threshold = self.freshness_thresholds.get(doc_type, 365)
            if days_old <= threshold * 0.5:
                staleness = "fresh"
                action = "accept"
            elif days_old <= threshold:
                staleness = "aging"
                action = "warning"
            elif days_old <= threshold * 2:
                staleness = "stale"
                action = "flag"
            else:
                staleness = "expired"
                action = "block"
                return {
                "action": action, "staleness": staleness, "days_old": days_old,
                "threshold_days": threshold, "doc_type": doc_type,
                "last_updated": reference_date, "stale_percentage": (days_old / threshold) * 100
        }
    except (ValueError, TypeError):
        return {"action": "flag", "reason": "invalid_date_format", "staleness": "unknown"}

    def validate_batch(self, docs: list) -> dict:
        results = []
        fresh_count = aging_count = stale_count = expired_count = 0
        for doc in docs:
            result = self.validate(doc)
            results.append(result)
            if result["staleness"] == "fresh":
                fresh_count += 1
            elif result["staleness"] == "aging":
                aging_count += 1
            elif result["staleness"] == "stale":
                stale_count += 1
            elif result["staleness"] == "expired":
                expired_count += 1
                return {
                "total_docs": len(docs), "fresh": fresh_count, "aging": aging_count,
                "stale": stale_count, "expired": expired_count,
                "freshness_score": (fresh_count + aging_count * 0.5) / max(len(docs), 1),
                "results": results
        }
