class ContextRiskScorer:
    """
    Calculates risk score for the assembled context.
    Integrates multiple signals into a composite score.
    """
    def __init__(self):
        self.risk_factors = {
            "injection_score": 0.30,
            "trust_score": 0.25,
            "freshness_score": 0.15,
            "consistency_score": 0.15,
            "diversity_score": 0.10,
            "source_mix_score": 0.05,
    }

    def score_context(self, signals: dict) -> dict:
        scores = {}
        injection_data = signals.get("injection", {})
        scores["injection_score"] = injection_data.get("highest_injection_score", 0)
        trust_data = signals.get("trust", {})
        avg_trust = trust_data.get("average_trust", 3)
 scores["trust_score"] = 1.0 - (avg_trust / 5.0)
        freshness_data = signals.get("freshness", {})
        scores["freshness_score"] = 1.0 - freshness_data.get("freshness_score", 1.0)
        consistency_data = signals.get("consistency", {})
 scores["consistency_score"] = min(1.0, consistency_data.get("issue_count", 0) / 10)
        diversity_data = signals.get("diversity", {})
        scores["diversity_score"] = 1.0 - diversity_data.get("diversity_score", 0.5)
        source_data = signals.get("sources", {})
        untrusted_ratio = source_data.get("external_unverified_count", 0) / max(source_data.get("total_docs", 1), 1)
        scores["source_mix_score"] = untrusted_ratio
        risk_score = sum(scores[factor] * weight for factor, weight in self.risk_factors.items())
        if risk_score > 0.70:
            action = "block"
            reason = "high_context_risk"
        elif risk_score > 0.40:
            action = "escalate"
            reason = "medium_context_risk"
        else:
            action = "accept"
            reason = "low_context_risk"
            return {
            "risk_score": risk_score, "action": action, "reason": reason,
            "factor_scores": scores,
            "risk_level": "high" if risk_score > 0.70 else "medium" if risk_score > 0.40 else "low",
            "scoring_timestamp": datetime.now(timezone.utc).isoformat()
    }
