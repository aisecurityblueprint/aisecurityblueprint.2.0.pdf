class APIResponseValidator:
    """
    Validates external API responses before they enter context.
    """
    def __init__(self):
        self.validation_rules = {
            "status_code": self._validate_status_code,
            "content_type": self._validate_content_type,
            "response_size": self._validate_response_size,
            "response_structure": self._validate_response_structure,
            "sensitive_data": self._check_sensitive_data,
            "injection_patterns": self._check_injection_patterns,
    }
    self.allowed_status_codes = [200, 201, 204]
    self.allowed_content_types = ["application/json", "text/plain", "text/html"]
    self.max_response_size_bytes = 1024 * 1024 # 1MB

    def validate(self, response: dict) -> dict:
        results = {}
        for rule_name, rule_func in self.validation_rules.items():
            results[rule_name] = rule_func(response)
            failed_rules = [k for k, v in results.items() if not v.get("passed", True)]
            return {"action": "block" if failed_rules else "accept",
            "validation_results": results, "failed_rules": failed_rules,
            "all_passed": len(failed_rules) == 0}

    def _validate_status_code(self, response: dict) -> dict:
        status = response.get("status_code", 0)
        passed = status in self.allowed_status_codes
        return {"passed": passed, "status_code": status,
        "reason": "ok" if passed else f"unexpected_status_code: {status}"}

    def _validate_content_type(self, response: dict) -> dict:
        content_type = response.get("content_type", "")
        passed = any(ct in content_type for ct in self.allowed_content_types)
        return {"passed": passed, "content_type": content_type,
        "reason": "ok" if passed else f"unexpected_content_type: {content_type}"}

    def _validate_response_size(self, response: dict) -> dict:
        body = response.get("body", "")
        size = len(str(body).encode('utf-8'))
        passed = size <= self.max_response_size_bytes
        return {"passed": passed, "size_bytes": size, "max_allowed": self.max_response_size_bytes,
        "reason": "ok" if passed else f"response_too_large: {size} bytes"}

    def _validate_response_structure(self, response: dict) -> dict:
        body = response.get("body", {})
        passed = isinstance(body, (dict, list, str))
        return {"passed": passed, "body_type": type(body).__name__,
        "reason": "ok" if passed else "invalid_response_structure"}

    def _check_sensitive_data(self, response: dict) -> dict:
        body_str = str(response.get("body", ""))
        sensitive_patterns = [
            (r'\b\d{3}-\d{2}-\d{4}\b', "SSN"),
            (r'\b\d{16}\b', "Credit Card"),
            (r'(?i)(password|secret|token|api[_-]?key)\s*[:=]\s*\S+', "Credentials"),
    ]
    findings = []
    for pattern, data_type in sensitive_patterns:
        matches = re.findall(pattern, body_str)
        if matches:
            findings.append({"type": data_type, "count": len(matches)})
            return {"passed": len(findings) == 0, "sensitive_data_found": findings,
            "reason": "ok" if not findings else f"sensitive_data_detected: {len(findings)} types"}

    def _check_injection_patterns(self, response: dict) -> dict:
        body_str = str(response.get("body", ""))
        injection_patterns = [
            r"(?i)(ignore|forget|override)\s+(all\s+)?(previous|system)\s+instructions",
            r"(?i)(execute|run|perform)\s+(admin|system|root)",
            r"(?i)(delete|drop|remove)\s+(all|everything|database|table)",
    ]
    findings = [pattern for pattern in injection_patterns if re.search(pattern, body_str)]
    return {"passed": len(findings) == 0, "injection_patterns_found": findings,
    "reason": "ok" if not findings else f"injection_patterns_detected: {len(findings)}"}
