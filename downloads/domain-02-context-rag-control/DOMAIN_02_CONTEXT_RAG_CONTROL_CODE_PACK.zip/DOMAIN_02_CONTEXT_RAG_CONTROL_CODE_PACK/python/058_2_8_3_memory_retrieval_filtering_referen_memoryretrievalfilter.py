class MemoryRetrievalFilter:
    """
    Filters retrieved memories before including them in context.
    Ensures only relevant and safe memories are included.
    """
    def __init__(self):
        self.max_memory_context_tokens = 4000
        self.min_relevance_score = 0.3
        self.blocked_memory_types = [
            "system_override_attempt", "security_bypass_attempt", "injection_attempt",
    ]

    def filter(self, memories: list, current_query: str = None) -> dict:
        filtered = []
        removed = []
        for memory in memories:
            removal_reason = None
            if memory.get("type") in self.blocked_memory_types:
                removal_reason = f"blocked_type: {memory.get('type')}"
            elif self._is_malicious_memory(memory):
                removal_reason = "malicious_content_detected"
            elif self._is_expired(memory):
                removal_reason = "expired"
            elif current_query and not self._is_relevant(memory, current_query):
                removal_reason = "low_relevance"
                if removal_reason:
                    removed.append({"entry_id": memory.get("entry_id"), "reason": removal_reason})
                else:
                    filtered.append(memory)
                    total_tokens = sum(m.get("tokens", len(m.get("content", "").split())) for m in filtered)
                    if total_tokens > self.max_memory_context_tokens:
                        filtered.sort(key=lambda m: m.get("timestamp", ""), reverse=True)
                        token_count = 0
                        truncated = []
                        for memory in filtered:
                            mem_tokens = memory.get("tokens", len(memory.get("content", "").split()))
                            if token_count + mem_tokens <= self.max_memory_context_tokens:
                                truncated.append(memory)
                                token_count += mem_tokens
                            else:
                                removed.append({"entry_id": memory.get("entry_id"), "reason": "token_budget_exceeded"})
                                filtered = truncated
                                return {
                                "filtered_memories": filtered, "removed_memories": removed,
                                "total_retrieved": len(memories), "total_included": len(filtered),
                                "total_excluded": len(removed), "tokens_included": sum(m.get("tokens", 0) for m in filtered)
                        }

    def _is_malicious_memory(self, memory: dict) -> bool:
        content = memory.get("content", "").lower()
        malicious_patterns = [
            r"ignore\s+(all\s+)?(previous|system)\s+instructions",
            r"bypass\s+security", r"override\s+polic", r"you\s+are\s+now\s+a\s+different",
    ]
    return any(re.search(p, content) for p in malicious_patterns)

    def _is_expired(self, memory: dict) -> bool:
        expires_at = memory.get("expires_at")
        if not expires_at:
            return False
        try:
            return parse_ts(expires_at) < datetime.now(timezone.utc)
        except (ValueError, TypeError):
            return False

    def _is_relevant(self, memory: dict, query: str) -> bool:
        content = memory.get("content", "").lower()
        query_lower = query.lower()
        query_keywords = set(query_lower.split()) - {"the", "is", "are", "a", "an"}
        if not query_keywords:
            return True
        matches = sum(1 for kw in query_keywords if kw in content)
        relevance = matches / len(query_keywords)
        return relevance >= self.min_relevance_score
