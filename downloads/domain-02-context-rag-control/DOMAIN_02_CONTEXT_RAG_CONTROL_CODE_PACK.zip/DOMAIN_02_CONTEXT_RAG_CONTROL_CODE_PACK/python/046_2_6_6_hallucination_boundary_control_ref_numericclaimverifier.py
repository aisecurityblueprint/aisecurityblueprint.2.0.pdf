class NumericClaimVerifier:
    """
    Verifies numeric claims against grounded source values.
    Production requirement: replace the reference _to_value fallback with a locale-aware parser during calibration for global deployments.
    """
    NUMBER_PATTERN = re.compile(
        r"(?<![\w.])[$€£R]?\s?(\d{1,3}(?:[,.\s]\d{3})*(?:[.,]\d+)?)\s?"
        r"(%|percent|k|K|M|MM|B|bi|mi|mil|milh[oõ]es|billion|million)?"
    )
    UNIT_MULTIPLIERS = {"k": 1e3, "K": 1e3, "mil": 1e3, "M": 1e6, "MM": 1e6, "mi": 1e6, "million": 1e6, "milhões": 1e6, "milhoes": 1e6, "B": 1e9, "bi": 1e9, "billion": 1e9}
    RELATIVE_TOLERANCE = 0.005

    def _to_value(self, num_str: str, unit: str) -> float:
        """Reference fallback for US and European/Brazilian numeric formats. Production deployments should use a locale-aware parser such as Babel/price-parser style parsing and validate currency symbols explicitly."""
        s = num_str.strip().replace(" ", "")
        has_comma = "," in s
        has_dot = "." in s
        if has_comma and has_dot:
            # Decimal separator is whichever appears last.
            if s.rfind(",") > s.rfind("."):
                normalized = s.replace(".", "").replace(",", ".")  # 1.000,50 -> 1000.50
            else:
                normalized = s.replace(",", "")  # 1,000.50 -> 1000.50
        elif has_comma:
            parts = s.split(",")
            if len(parts) > 1 and len(parts[-1]) == 3 and all(part.isdigit() for part in parts):
                normalized = "".join(parts)  # 1,000 -> 1000
            else:
                normalized = s.replace(",", ".")  # 1000,50 -> 1000.50
        elif has_dot:
            parts = s.split(".")
            if len(parts) > 2 or (len(parts) == 2 and len(parts[-1]) == 3 and parts[0].isdigit()):
                normalized = "".join(parts)  # 1.000 -> 1000
            else:
                normalized = s
        else:
            normalized = s
        value = float(normalized)
        return value * self.UNIT_MULTIPLIERS.get(unit or "", 1.0)
    def extract_values(self, text: str) -> list:
        values = []
        for m in self.NUMBER_PATTERN.finditer(text):
            try:
                values.append({"raw": m.group(0).strip(), "value": self._to_value(m.group(1), m.group(2))})
            except (ValueError, ZeroDivisionError):
                continue
        return values

    def verify(self, output: str, context_docs: list) -> dict:
        output_values = self.extract_values(output)
        if not output_values:
            return {"numeric_claims": 0, "unsupported_values": [], "numeric_hallucination_risk": 0.0, "action": "accept"}
        context_values = []
        for doc in context_docs:
            context_values.extend(v["value"] for v in self.extract_values(doc.get("content", "")))
        unsupported = []
        for claim in output_values:
            supported = any(abs(claim["value"] - cv) <= max(abs(cv) * self.RELATIVE_TOLERANCE, 1e-9) for cv in context_values)
            if not supported:
                unsupported.append(claim)
        risk = len(unsupported) / len(output_values)
        return {"numeric_claims": len(output_values), "unsupported_values": unsupported, "numeric_hallucination_risk": risk, "action": "block" if risk > 0.30 else "flag" if risk > 0.0 else "accept"}

class HallucinationBoundaryController:
    def __init__(self):
        self.numeric_verifier = NumericClaimVerifier()
        self.block_threshold = 0.75
        self.flag_threshold = 0.35
    def validate_response(self, response: str, context_docs: list) -> dict:
        statement_result = self._validate_statement_support(response, context_docs)
        numeric_result = self.numeric_verifier.verify(response, context_docs)
        statement_risk = statement_result.get("unsupported_statement_risk", 0.0)
        numeric_risk = numeric_result.get("numeric_hallucination_risk", 0.0)
        final_risk = max(statement_risk, numeric_risk)
        if final_risk >= self.block_threshold or numeric_result["action"] == "block":
            action = "block"
        elif final_risk >= self.flag_threshold or numeric_result["action"] == "flag":
            action = "flag"
        else:
            action = "allow"
        return {"action": action, "hallucination_risk": final_risk, "statement_support": statement_result, "numeric_support": numeric_result}

    def _validate_statement_support(self, response: str, context_docs: list) -> dict:
        statements = [s.strip() for s in re.split(r"[.!?]\s+", response) if s.strip()]
        context_text = " ".join(doc.get("content", "") for doc in context_docs).lower()
        unsupported = []
        for statement in statements:
            keywords = [w.lower() for w in statement.split() if len(w) > 4]
            if keywords and sum(1 for kw in keywords if kw in context_text) / len(keywords) < 0.35:
                unsupported.append(statement)
        risk = len(unsupported) / max(len(statements), 1)
        return {"statements": len(statements), "unsupported_statements": unsupported, "unsupported_statement_risk": risk}
