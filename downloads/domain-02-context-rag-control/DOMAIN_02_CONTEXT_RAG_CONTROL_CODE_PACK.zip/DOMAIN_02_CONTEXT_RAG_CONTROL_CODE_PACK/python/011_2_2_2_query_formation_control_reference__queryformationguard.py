class QueryFormationGuard:
 def __init__(self, normalizer=None, token_estimator=None):
 self.normalizer = normalizer or InputNormalizer()
 self.token_estimator = token_estimator or TokenEstimator()
 self.blocked_patterns = [
 r"(?i)ignore\s+(previous|all|filters|restrictions)",
 r"(?i)bypass\s+(access|control|filter|restriction)",
 r"(?i)show\s+(all|everything|hidden|blocked)",
 r"(?i)include\s+(restricted|confidential|secret|private)",
 r"(?i)search\s+(everything|all\s+documents|without\s+filter)",
 r"(?i)(ignore|ignora|esque[cç]a|desconsidere)\s+(todas?\s+)?(as\s+)?(instru[cç][oõ]es|regras|pol[ií]ticas|filtros|restri[cç][oõ]es)",
 r"(?i)(burl(e|ar)|contorn(e|ar)|desativ(e|ar))\s+(acesso|controle|controlo|filtro|restri[cç][aã]o)",
 r"(?i)(mostrar|mostre)\s+(tudo|todos|ocultos|bloqueados)",
 r"(?i)(incluir|inclua)\s+(restrito|confidencial|segredo|privado)",
 r"(?i)(pesquisar|buscar)\s+(tudo|todos\s+os\s+documentos|sem\s+filtro)",
 r"(?i)(ignora|olvida|descarta)\s+(todas?\s+)?(las\s+)?(instrucciones|reglas|pol[ií]ticas|filtros|restricciones)",
 r"(?i)(elud(e|ir)|evita(r)?|desactiva(r)?)\s+(acceso|control|filtro|restricci[oó]n)",
 r"(?i)mostrar\s+(todo|todos|ocultos|bloqueados)",
 r"(?i)incluir\s+(restringido|confidencial|secreto|privado)",
 r"(?i)buscar\s+(todo|todos\s+los\s+documentos|sin\s+filtro)",
 ]
 self.max_query_length = 500
 self.max_query_expansion = 3

 def validate_query(self, original_query: str, user_context: dict) -> dict:
 norm = self.normalizer.normalize(original_query)
 query = norm["normalized"]
 for pattern in self.blocked_patterns:
 if re.search(pattern, query):
 return {"action": "block", "reason": "malicious_query_pattern", "pattern_matched": pattern, "normalizer": norm}
 query_tokens = self.token_estimator.count(query)
 if query_tokens > self.max_query_length:
 return {"action": "truncate", "reason": "query_too_long", "truncated_query": " ".join(query.split()[:self.max_query_length])}
 security_filters = self._build_security_filters(user_context)
 return {"action": "allow", "original_query": original_query, "normalized_query": query, "security_filters_applied": security_filters, "normalizer": norm, "user_clearance": user_context.get("clearance_level", 0), "user_department": user_context.get("department", "unknown")}

 def _build_security_filters(self, user_context: dict) -> list:
 filters = []
 clearance = user_context.get("clearance_level", 0)
 filters.append({"type": "clearance", "operator": "lte", "field": "sensitivity_tier", "value": clearance})
 department = user_context.get("department")
 if department:
 filters.append({"type": "department", "operator": "eq", "field": "owner_department", "value": department})
 filters.append({"type": "classification", "operator": "neq", "field": "classification", "value": "restricted"})
 return filters

 def rewrite_query(self, query: str, user_context: dict) -> str:
 security_filters = self._build_security_filters(user_context)
 filter_clauses = [f"{f['field']} {f['operator']} {f['value']}" for f in security_filters]
 return f"{query}\n[SECURITY_FILTERS: {' AND '.join(filter_clauses)}]"
