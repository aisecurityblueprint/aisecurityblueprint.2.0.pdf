class ContextSegmenter:
    """
    Segments context with explicit delimiters. Each source receives
    a wrapper. Both content and metadata are sanitized before they
    are interpolated into templates.
    """
    SEGMENT_TEMPLATES = {
        "system": "<SYSTEM>\n{content}\n</SYSTEM>",
        "rag_trusted": '<RAG trust="high" source="{source}" doc_id="{doc_id}">\n{content}\n</RAG>',
        "rag_untrusted": '<RAG trust="low" source="{source}" doc_id="{doc_id}">\n{content}\n</RAG>',
        "user": "<USER>\n{content}\n</USER>",
        "tool": '<TOOL name="{tool_name}" trust_score="{trust_score}">\n{content}\n</TOOL>',
        "memory": '<MEMORY session="{session_id}" timestamp="{timestamp}">\n{content}\n</MEMORY>',
    }
    DELIMITER_RX = re.compile(
        r"<\s*/?\s*(SYSTEM|RAG|USER|TOOL|MEMORY)\b[^>]*>",
        re.IGNORECASE,
    )
    SAFE_META_RX = re.compile(r"[^A-Za-z0-9_.:/@-]")

    def __init__(self, normalizer=None, token_estimator=None):
        self.normalizer = normalizer or InputNormalizer()
        self.token_estimator = token_estimator or TokenEstimator()

    def segment(self, source_type: str, content: str, metadata: dict = None) -> str:
        metadata = self._sanitize_metadata(metadata or {})
        template = self.SEGMENT_TEMPLATES.get(source_type, "<UNKNOWN>\n{content}\n</UNKNOWN>")
        return template.format(content=content, **metadata)

    def assemble_context(self, segments: list) -> dict:
        context_parts, segment_hashes, validation_warnings = [], [], []
        for source_type, raw_content, metadata in segments:
            norm = self.normalizer.normalize(raw_content)
            content = norm["normalized"]
            if norm["signals"]:
                validation_warnings.append({"type": "normalization_signal", "source": source_type, "signals": norm["signals"]})
            if self._has_unauthorized_delimiters(content, source_type):
                validation_warnings.append({"type": "unauthorized_delimiter", "source": source_type, "action": "sanitized"})
                content = self._sanitize_delimiters(content)
            clean_metadata = self._sanitize_metadata(metadata or {})
            segmented = self.segment(source_type, content, clean_metadata)
            context_parts.append(segmented)
            segment_hashes.append(hashlib.sha256(segmented.encode()).hexdigest())
        context_string = "\n\n".join(context_parts)
        return {
            "context": context_string,
            "segment_count": len(segments),
            "segment_hashes": segment_hashes,
            "total_tokens": self.token_estimator.count(context_string),
            "warnings": validation_warnings,
        }

    def _has_unauthorized_delimiters(self, content: str, source_type: str) -> bool:
        allowed = {"system": {"SYSTEM"}, "user": {"USER"}, "tool": {"TOOL"}, "memory": {"MEMORY"}}
        allowed_tags = {"RAG"} if source_type.startswith("rag") else allowed.get(source_type, set())
        return any(m.group(1).upper() not in allowed_tags for m in self.DELIMITER_RX.finditer(content))

    def _sanitize_delimiters(self, content: str) -> str:
        return self.DELIMITER_RX.sub(lambda m: m.group(0).replace("<", "&lt;").replace(">", "&gt;"), content)

    def _sanitize_metadata(self, metadata: dict) -> dict:
        """
        Sanitizes values used inside wrapper attributes. Metadata is
        untrusted input too; a malicious source or doc_id must not be
        able to close a tag, inject a new attribute or introduce a
        delimiter-shaped payload.
        """
        clean = {}
        for key, value in metadata.items():
            key = self.SAFE_META_RX.sub("_", str(key))[:64]
            value = str(value)
            value = self._sanitize_delimiters(value)
            value = value.replace('"', "&quot;").replace("'", "&#x27;")
            value = self.SAFE_META_RX.sub("_", value)[:256]
            clean[key] = value
        return clean
