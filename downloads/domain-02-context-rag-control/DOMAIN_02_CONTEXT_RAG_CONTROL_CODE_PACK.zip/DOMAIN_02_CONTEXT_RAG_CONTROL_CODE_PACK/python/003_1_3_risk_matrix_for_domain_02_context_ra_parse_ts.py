def parse_ts(value: str) -> datetime:
    """
    Timezone-safe ISO timestamp parsing.
    Naive datetimes with no tzinfo are assumed UTC, which is the common case
    for document metadata in the wild. Raises ValueError on malformed input;
    callers decide fail-open versus fail-closed based on the control context.
    """
    dt = datetime.fromisoformat(value)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
