class SourceAttributor:
    """
    Attributes each part of the output to the sources that influenced it.
    """
    def __init__(self):
        self.attribution_log = []

    def attribute_output(self, output: str, context_docs: list) -> dict:
        attributions = []
        output_sentences = re.split(r'[.!?]+', output)
        for sentence in output_sentences:
            sentence = sentence.strip()
            if len(sentence) < 30:
                continue
                influencing_docs = self._find_influencing_docs(sentence, context_docs)
                if influencing_docs:
                    attributions.append({
                        "sentence": sentence[:150],
                        "influenced_by": [{"doc_id": doc.get("doc_id"), "source": doc.get("source"), "influence_score": score} for doc, score in influencing_docs],
                        "primary_source": influencing_docs[0][0].get("source") if influencing_docs else "unknown"
                })
                return {
                "total_sentences_analyzed": len(output_sentences),
                "sentences_with_attribution": len(attributions),
                "attributions": attributions,
                "sources_cited": list(set(a["primary_source"] for a in attributions))
        }
    def _find_influencing_docs(self, sentence: str, context_docs: list) -> list:
        sentence_words = set(sentence.lower().split()) - {"the", "is", "are", "a", "an", "in", "on", "at"}
        doc_scores = []
        for doc in context_docs:
            content = doc.get("content", "").lower()
            if not content:
                continue
                content_words = set(content.split())
                overlap = sentence_words & content_words
                if overlap:
                    score = len(overlap) / len(sentence_words)
                    if score > 0.2:
                        doc_scores.append((doc, score))
                        doc_scores.sort(key=lambda x: x[1], reverse=True)
                        return doc_scores[:5]
