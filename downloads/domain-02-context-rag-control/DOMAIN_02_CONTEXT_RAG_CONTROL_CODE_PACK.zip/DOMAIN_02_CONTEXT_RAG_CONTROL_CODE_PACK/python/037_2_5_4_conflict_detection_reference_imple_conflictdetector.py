class ConflictDetector:
    """
    Detects explicit conflicts between sources in context.
    """
    def __init__(self):
        self.conflict_markers = [
            (r"(?i)(however|but|although|nevertheless)", r"(?i)(therefore|thus|consequently)"),
            (r"(?i)(on\s+the\s+other\s+hand)", r"(?i)(in\s+conclusion)"),
            (r"(?i)(contrary\s+to)", r"(?i)(consistent\s+with)"),
    ]
    self.high_confidence_conflicts = [
        (r"(?i)\bnot\b\s+(allowed|permitted|authorized|approved)", r"(?i)\b(is|are)\s+(allowed|permitted|authorized|approved)"),
        (r"(?i)\bprohibited\b", r"(?i)\brequired\b|\bmandatory\b"),
]

    def detect(self, docs: list) -> dict:
        conflicts = []
        for i, doc_a in enumerate(docs):
            for j, doc_b in enumerate(docs):
                if i >= j:
                    continue
                    conflict = self._detect_pair_conflict(doc_a, doc_b)
                    if conflict:
                        conflicts.append(conflict)
                        return {
                        "conflicts_detected": len(conflicts), "conflicts": conflicts,
                        "high_confidence_conflicts": [c for c in conflicts if c.get("confidence") == "high"],
                        "action": "flag" if conflicts else "accept"
                }

    def _detect_pair_conflict(self, doc_a: dict, doc_b: dict) -> dict:
        content_a = doc_a.get("content", "")
        content_b = doc_b.get("content", "")
        for pattern_a, pattern_b in self.high_confidence_conflicts:
            if re.search(pattern_a, content_a) and re.search(pattern_b, content_b):
                return {
                "doc_a": {"id": doc_a.get("doc_id"), "source": doc_a.get("source")},
                "doc_b": {"id": doc_b.get("doc_id"), "source": doc_b.get("source")},
                "type": "high_confidence_conflict", "pattern_a": pattern_a, "pattern_b": pattern_b,
                "confidence": "high", "resolution": "prefer_higher_trust_source"
        }
        if re.search(pattern_b, content_a) and re.search(pattern_a, content_b):
            return {
            "doc_a": {"id": doc_a.get("doc_id"), "source": doc_a.get("source")},
            "doc_b": {"id": doc_b.get("doc_id"), "source": doc_b.get("source")},
            "type": "high_confidence_conflict", "pattern_a": pattern_b, "pattern_b": pattern_a,
            "confidence": "high", "resolution": "prefer_higher_trust_source"
    }
    return None
