class DomainRiskIntegrator:
 """
 Integrates risk scores from Domain 01 (Input), Domain 02 - Context & RAG Control (Context)
 and Domain 03 (Output) into a unified enforcement decision.
 """
 def __init__(self):
 self.composite_weights = {"input_risk": 0.40, "context_risk": 0.35, "output_risk": 0.25}
 self.action_thresholds = {"block": 0.75, "escalate": 0.55, "flag": 0.35}

 def integrate_risks(self, domain_scores: dict) -> dict:
 available = {d: v for d, v in domain_scores.items() if d in self.composite_weights and "score" in v}
 if not available:
 return {"integrated_risk_score": 1.0, "enforcement_basis": "fail_closed_no_signals", "action": "block", "risk_level": "critical", "integration_timestamp": datetime.now(timezone.utc).isoformat()}
 max_domain = max(available, key=lambda d: available[d]["score"])
 enforcement_score = available[max_domain]["score"]
 total_weight = sum(self.composite_weights[d] for d in available)
 composite_score = sum(available[d]["score"] * self.composite_weights[d] for d in available) / total_weight
 if enforcement_score >= self.action_thresholds["block"]:
 action = "block"
 elif enforcement_score >= self.action_thresholds["escalate"]:
 action = "escalate"
 elif enforcement_score >= self.action_thresholds["flag"]:
 action = "flag"
 else:
 action = "allow"
 return {"integrated_risk_score": enforcement_score, "enforcement_basis": f"max_floor:{max_domain}", "composite_score": composite_score, "composite_is_enforcing": False, "dominant_domain": max_domain, "action": action, "domain_scores": domain_scores, "risk_level": "critical" if enforcement_score >= 0.75 else "high" if enforcement_score >= 0.55 else "medium" if enforcement_score >= 0.35 else "low", "integration_timestamp": datetime.now(timezone.utc).isoformat()}

 def explain_decision(self, integrated_result: dict) -> dict:
 domain_scores = integrated_result.get("domain_scores", {})
 domain_names = {"input_risk": "Input Security (Domain 01)", "context_risk": "Context Security (Domain 02 - Context & RAG Control)", "output_risk": "Output Security (Domain 03)"}
 explanations = [{"domain": domain_names.get(d, d), "score": v.get("score", 0), "level": v.get("risk_level", "unknown"), "is_enforcement_driver": f"max_floor:{d}" == integrated_result.get("enforcement_basis")} for d, v in domain_scores.items()]
 return {"decision": integrated_result.get("action"), "enforcement_score": integrated_result.get("integrated_risk_score"), "enforcement_basis": integrated_result.get("enforcement_basis"), "composite_trend_signal": integrated_result.get("composite_score"), "rationale": explanations, "top_contributor": max(explanations, key=lambda x: x["score"]) if explanations else None}
