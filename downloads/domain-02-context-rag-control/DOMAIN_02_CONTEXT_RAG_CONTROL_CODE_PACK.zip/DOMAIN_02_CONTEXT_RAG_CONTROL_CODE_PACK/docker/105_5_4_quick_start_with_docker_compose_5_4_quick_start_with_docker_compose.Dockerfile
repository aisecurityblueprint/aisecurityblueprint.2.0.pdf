# docker-compose.yml
version: '3.8'
services:
 domain02-validator:
build:
  context: .
  dockerfile: Dockerfile
 container_name: domain02-validator
 environment:
 - MODEL_API_KEY=${MODEL_API_KEY:-dummy}
 - CALIBRATION_MODE=conservative
 - LOG_LEVEL=INFO
 - MAX_CONTEXT_TOKENS=128000
 volumes:
 - ./test_payloads:/payloads
 - ./logs:/var/log/domain02
 ports:
 - "8080:8080"
 command: ["python", "-m", "domain02.validator", "--host", "0.0.0.0", "--port", "8080"]

# Dockerfile
FROM python:3.11-slim
WORKDIR /app
